# Tail-risk crane–vehicle scheduling: experiment data and code

Data release: **2026-10-21**, based on the frozen `tailrisk-v3.0` study.

This repository contains the synthetic instances, fixed reference schedules, optimization plans, paired replay summaries, analysis outputs and source code for **Tail-Sensitivity-Guided Search for Risk-Aware Crane–Vehicle Scheduling in Automated Container Terminals**. The methods are TS-JS, independent-chain GA, ALNS and critical-block tabu search (CB-TS), with three TS-JS ablations. All valid archived results are retained, including comparisons and ablations that do not favor TS-JS. This data package does not assert publication or acceptance.

## Two complementary downloads

* **`TailRisk_GitHub_Repository_20261021.zip`**: extract its contents as a Git repository. It contains all inputs, plans, summaries, frozen configuration, source and analysis, but omits the bulky scenario CSV blocks.
* **`TailRisk_Experiment_Data_Full_20261021.zip`**: the complete data release, including every original compressed scenario CSV block. Attach this archive to GitHub Releases. It can also be extracted into a separate empty directory for direct use.

The complete release is self-contained for the archived numerical study. The manuscript, author correspondence, local software installations and invalidated partial development runs are outside its scope. `PACKAGING_NOTES.md` explains these boundaries. No public repository address, DOI or reuse license has been assigned by this packaging step.

## What is included

| Path | Contents |
|---|---|
| `reproducibility/data/development/` | 40 development instances and shared reference schedules |
| `reproducibility/data/test/` | 120 confirmation instances and shared reference schedules |
| `reproducibility/configs/` | Development grid, selected settings, protocol, timing limits and original source freeze |
| `reproducibility/results/` | Complete resource-chain plans, convergence records, provenance, replay summaries and completion manifests |
| `reproducibility/src/`, `TailRisk.csproj` | Original .NET 8 generator, event model, solvers, replay and validation |
| `analysis/` | Original statistical scripts, versioned independent auditor and archived analysis results |
| `reports/` | Exact small cases, validation, analysis protocol and audit history |
| `scripts/` | Data verification, safe release restoration and analysis reproduction helpers |
| `DATA_MANIFEST.json` | SHA-256 and byte count for every package file except the manifest itself |
| `INVENTORY.csv`, `DATA_DICTIONARY.md` | Counts, joins, metric definitions and sampling units |

There are **3100 confirmation optimization runs**: 2400 main, 300 ablation and 400 equal-time runs. Different runs may return identical resource chains. Correlated stress testing reuses the plans from 400 main runs. Confirmation replay contains **6,600,000 plan–scenario evaluations**. The valid development replay archive contains a further **1,920,000**, for **8,520,000** archived plan–scenario rows in **420 compressed CSV blocks**. Reference-plan replay arrays are stored separately and are not counted in these totals. The ablation analysis also reuses 100 full TS-JS plans from main; these are not additional optimization runs or additional ablation replay evaluations.

## Verify and restore

Python **3.10 or later** is sufficient for the standard-library packaging helpers. Run commands from the extracted repository root; quote paths containing spaces.

```powershell
python scripts/verify_data.py
python scripts/restore_release.py "C:/Downloads/TailRisk_Experiment_Data_Full_20261021.zip"
python scripts/verify_data.py --require-raw
```

The first command permits the 420 raw replay blocks to be absent from the small repository. The restoration command checks the exact member list and hashes, installs missing files, and refuses to overwrite differing local files. The final command requires the complete release. All 25 entries in the original scientific freeze are checked independently. Keep `.gitattributes`: it prevents Git line-ending conversion from changing archived file hashes. `.gitignore` keeps restored raw replay blocks out of normal Git commits.

## Reproduce the analysis

The original analysis dependency versions are recorded in `analysis/requirements.txt`. Use a separate Python environment compatible with those versions:

```powershell
python -m pip install -r analysis/requirements.txt
python -X utf8 scripts/reproduce_analysis.py
```

This verifies the complete data, reruns the four confirmation analyses using the archived plan summaries, and runs the independent full-replay auditor. It does not launch new optimization. Run it on a working copy if you want to preserve the delivered archive byte for byte; audit reports include fresh execution metadata. The operation reads millions of rows and is substantially slower than a checksum check.

For a quick model check with the **.NET 8 SDK** installed:

```powershell
dotnet build reproducibility/TailRisk.csproj -c Release
dotnet reproducibility/bin/Release/net8.0/TailRisk.dll selftest --root . --output build/reproduced_validation
dotnet reproducibility/bin/Release/net8.0/TailRisk.dll exact --root . --output build/reproduced_exact
python -X utf8 analysis/analyze.py --self-test
python -X utf8 analysis/package_audit_v1_1.py --self-test --fixture build/reproduced_validation/interpreter_fixture.json
```

To rerun or integrity-resume the confirmation optimization with the archived inputs and frozen settings, use a separate complete working copy and run the commands below sequentially. Existing results are verified and skipped; a new empty results directory is needed for new executions. New wall times and provenance need not be byte-identical. The timed experiment requires the same CPU conditions for a direct comparison of elapsed-time outcomes.

```powershell
dotnet reproducibility/bin/Release/net8.0/TailRisk.dll main --root . --workers 4
dotnet reproducibility/bin/Release/net8.0/TailRisk.dll ablation --root . --workers 4
dotnet reproducibility/bin/Release/net8.0/TailRisk.dll replay --root . --phase main --workers 3
dotnet reproducibility/bin/Release/net8.0/TailRisk.dll replay --root . --phase ablation --workers 3
dotnet reproducibility/bin/Release/net8.0/TailRisk.dll replay --root . --phase correlated --workers 3
dotnet reproducibility/bin/Release/net8.0/TailRisk.dll timing --root .
dotnet reproducibility/bin/Release/net8.0/TailRisk.dll replay --root . --phase timing --workers 3
```

## Interpretation

The primary response is empirical CVaR95 of a task's cumulative AGV waiting at the quay and yard interfaces, pooling tasks and replay scenarios within each plan. It is not waiting P95 or scenario total waiting. The sole primary method comparison is TS-JS versus ALNS at CV 0.20. Seeds are averaged within each instance before paired, size-stratified inference; neither tasks nor replay scenarios are independent experimental instances. See the data dictionary and `reports/statistical_analysis_protocol.md` before interpreting columns or recalculating statistics.

The data are synthetic and use abstract consistent time and distance units. They assume fixed QC and YC service points, earliest feasible execution and nonempty active resources, with no traffic conflicts or charging model. Waiting occupancy describes this event model, not measured terminal queues or a proof of queue stability. GTV is a diagnostic, not the optimized objective.

OpenAI Codex assisted with study design, method and code development, verification, analysis implementation, writing and packaging. Numerical claims must be checked against the archived experiments. Authors should select code and data licenses and add verified citation/publication metadata before making a public release.
