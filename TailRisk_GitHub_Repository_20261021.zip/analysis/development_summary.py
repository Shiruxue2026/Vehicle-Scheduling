"""Describe completed development stages without selecting or retuning anything.

All required phases must pass a metadata-only completeness gate before this
script reads any optimization scores, ranking scores, or replay outcomes.
K=64 reuses the already selected configurations and seed indices 1 and 2 from
the selection stage. Its observations are development evidence, not unseen
confirmation evidence. No optimization, replay, hypothesis test or selection is
performed here. --selftest fake uses artificial values and no study artifacts.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
import statistics
import tempfile
from datetime import datetime, timezone

SIZES = (24, 48, 96, 192)
METHODS = ("ALNS", "CB-TS", "GA", "TS-JS")
METRICS = ("WaitCVaRNorm", "CmaxCVaRExcessNorm", "Seconds", "Work", "WorkFraction")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def seed(name):
    return int.from_bytes(hashlib.sha256(("tailrisk-v3|" + name).encode()).digest()[:4], "little") & 0x7fffffff


def close(actual, expected, label):
    require(math.isfinite(float(actual)) and math.isfinite(float(expected)) and math.isclose(float(actual), float(expected), rel_tol=1e-9, abs_tol=1e-9), label)


class Sources:
    def __init__(self, root):
        self.root = root.resolve()
        self.hashes = {}

    def key(self, path):
        return path.resolve().relative_to(self.root).as_posix()

    def record(self, path, digest):
        key = self.key(path)
        require(key not in self.hashes or self.hashes[key] == digest, "Source changed during reporting: " + key)
        self.hashes[key] = digest

    def sha(self, path):
        h = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                h.update(block)
        digest = h.hexdigest()
        self.record(path, digest)
        return digest

    def text(self, path):
        raw = path.read_bytes()
        self.record(path, hashlib.sha256(raw).hexdigest())
        return raw.decode("utf-8-sig")

    def json(self, path):
        return json.loads(self.text(path))

    def csv(self, path):
        reader = csv.DictReader(io.StringIO(self.text(path)))
        require(reader.fieldnames and len(reader.fieldnames) == len(set(reader.fieldnames)), "Invalid CSV header: " + str(path))
        rows = list(reader)
        require(rows and all(None not in row and None not in row.values() for row in rows), "Empty or malformed CSV: " + str(path))
        return rows


def expected_ids(first, last):
    return {f"development_N{n}_I{i:02}" for n in SIZES for i in range(first, last + 1)}


def config_set(configs, per_method, label):
    require(len(configs) == 4 * per_method and len({c["Id"] for c in configs}) == len(configs), label + " count/IDs")
    require({c["Method"] for c in configs} == set(METHODS), label + " methods")
    require(all(sum(c["Method"] == m for c in configs) == per_method for m in METHODS), label + " configurations per method")


def phase_metadata(root, sources, phase, configs, instances, seeds, training, fraction, replay_cvs):
    """Read declarations only; never open run JSON, ranking JSON or metric CSV."""
    folder = root / "reproducibility" / "results" / phase
    expected_count = len(instances) * len(configs) * seeds
    complete = sources.json(folder / "completion.json")
    require(complete.get("Phase") == phase and complete.get("Expected") == expected_count and complete.get("Files") == expected_count, "Incomplete optimization phase: " + phase)
    manifest = sources.json(folder / "runset_manifest.json")
    spec = manifest["Specification"]
    require(spec["Schema"] == 1 and spec["Phase"] == phase and spec["TrainingCount"] == training and spec["TrainingCV"] == .2 and spec["TrainingRho"] == 0 and not spec["NominalOnly"], "Training contract mismatch: " + phase)
    require({x["InstanceId"] for x in spec["Inputs"]} == instances and len(spec["Inputs"]) == len(instances), "Instance contract mismatch: " + phase)
    require(sorted(spec["Configurations"], key=lambda x: x["Id"]) == sorted(configs, key=lambda x: x["Id"]), "Configuration contract mismatch: " + phase)
    expected = {(i, c["Id"], seed(f"algorithm|{i}|{k}")) for i in instances for c in configs for k in range(1, seeds + 1)}
    recorded = spec["Runs"]
    require(len(recorded) == expected_count and {(r["InstanceId"], r["ConfigId"], r["Seed"]) for r in recorded} == expected, "Incomplete paired run contract: " + phase)
    sizes = {x["InstanceId"]: x["N"] for x in spec["Inputs"]}
    for run in recorded:
        n = sizes[run["InstanceId"]]
        require(run["Limit"] == int(15 * n * (32768 + 1024 * n) * fraction) and run["TimeLimit"] == 0, "Incorrect event-work budget: " + phase)
        require(1 <= run["SeedIndex"] <= seeds and run["Seed"] == seed(f"algorithm|{run['InstanceId']}|{run['SeedIndex']}"), "Incorrect seed index: " + phase)
    require({p.name for p in (folder / "runs").glob("*.json")} == {r["FileName"] for r in recorded}, "Missing/extra optimization files: " + phase)
    require({p.name for p in (folder / "provenance" / "runs").glob("*.json")} == {r["FileName"] for r in recorded}, "Missing/extra optimization receipts: " + phase)
    replay = None
    if replay_cvs:
        done = sources.json(folder / "replay_completion.json")
        require(done.get("Phase") == phase and done.get("PlanConditionRows") == expected_count * len(replay_cvs) and done.get("ScenariosPerPlan") == 1000 and done.get("TotalDecodings") == expected_count * len(replay_cvs) * 1000, "Incomplete independent replay: " + phase)
        replay = sources.json(folder / "replay" / "runset.json")
        require(hashlib.sha256(replay["Specification"].encode()).hexdigest() == replay["Digest"], "Replay specification digest: " + phase)
        replay_spec = json.loads(replay["Specification"])
        require(replay_spec["Phase"] == phase and replay_spec["CV"] == list(replay_cvs) and replay_spec["Rho"] == 0 and replay_spec["Scenarios"] == 1000, "Replay condition contract: " + phase)
        require(set(replay_spec["Plans"]) == {r["FileName"] for r in recorded}, "Replay plan contract: " + phase)
        expected_summaries = set()
        for input_id in instances:
            for cv in replay_cvs:
                stem = f"{input_id}_cv{cv*100:02.0f}_rho00"
                expected_summaries.add(stem + "_summary.csv")
                for suffix in ("_manifest.json", "_summary.csv", "_reference.json", ".csv.gz"):
                    require((folder / "replay" / (stem + suffix)).is_file(), "Missing replay chunk: " + phase + "/" + stem + suffix)
        require({p.name for p in (folder / "replay").glob("*_summary.csv")} == expected_summaries, "Missing/extra replay chunks: " + phase)
        require((folder / "replay_plan.csv").is_file(), "Missing merged replay: " + phase)
    return {"phase": phase, "folder": folder, "manifest": manifest, "spec": spec, "replay": replay, "cvs": replay_cvs}


def preflight(root, sources):
    """No metric-bearing file is opened until every phase has passed this gate."""
    config_dir = root / "reproducibility" / "configs"
    audit = sources.json(config_dir / "selection_audit.json")
    round_number = int(audit["Round"])
    require(1 <= round_number <= 3, "Invalid selected development round")
    stage = audit["Stage"]
    phase = stage if stage.startswith("dev_") else "dev_" + stage if stage.startswith(f"r{round_number}_") else f"dev_r{round_number}_" + stage
    require(phase.startswith(f"dev_r{round_number}_") and phase != f"dev_r{round_number}_tune", "Invalid selection phase")
    grid = sources.json(config_dir / f"grid_r{round_number}.json")
    shortlist = sources.json(config_dir / f"shortlist_r{round_number}.json")
    selected = sources.json(config_dir / "selected.json")
    config_set(grid, 8, "grid"); config_set(shortlist, 2, "shortlist"); config_set(selected, 1, "selected")
    require(all(c in grid for c in shortlist) and all(c in shortlist for c in selected), "Selected settings do not originate from the archived grid/shortlist")
    phases = {}
    declarations = [(f"dev_r{round_number}_tune", grid, expected_ids(1, 5), 2, 64, .5, ()),
                    (phase, shortlist, expected_ids(6, 10), 5, 64, 1, (.1, .2)),
                    ("dev_trainingK32", selected, expected_ids(6, 10), 2, 32, 1, (.2,)),
                    ("dev_trainingK128", selected, expected_ids(6, 10), 2, 128, 1, (.2,))]
    for name, configs, instances, seeds, training, fraction, cvs in declarations:
        phases[name] = phase_metadata(root, sources, name, configs, instances, seeds, training, fraction, cvs)
    for name in (f"dev_r{round_number}_tune", phase):
        require((phases[name]["folder"] / "ranking.json").is_file(), "Missing completed stage ranking: " + name)
    return {"round": round_number, "selection_phase": phase, "grid": grid, "shortlist": shortlist, "selected": selected, "selection_audit": audit, "phases": phases}


def load_runs(root, sources, meta):
    folder, spec = meta["folder"], meta["spec"]
    for relative, expected_hash in spec["NumericalCore"].items():
        require(sources.sha(root / relative) == expected_hash, "Numerical core changed since development: " + relative)
    for item in spec["Inputs"]:
        for path_name, hash_name in (("InstancePath", "InstanceHash"), ("ReferencePath", "ReferenceHash")):
            require(sources.sha(root / item[path_name]) == item[hash_name], "Development input/reference changed")
    runs = {}
    for expected in spec["Runs"]:
        path = folder / "runs" / expected["FileName"]
        run = sources.json(path)
        receipt = sources.json(folder / "provenance" / "runs" / expected["FileName"])
        require(receipt["SpecificationHash"] == meta["manifest"]["SpecificationHash"] and receipt["FileHash"] == sources.hashes[sources.key(path)], "Archived run receipt mismatch: " + path.name)
        session = sources.json(folder / "provenance" / "sessions" / (receipt["SessionId"] + ".json"))
        require(receipt["AssemblyHash"] == session["AssemblyHash"], "Run execution assembly mismatch")
        for field in ("InstanceId", "ConfigId", "Method", "Seed", "Limit", "TimeLimit"):
            require(run[field] == expected[field], "Run identity/contract mismatch: " + path.name + "/" + field)
        require(run["Phase"] == meta["phase"] and run["TrainingScenarios"] == spec["TrainingCount"], "Run phase/training mismatch")
        require(run["Evaluation"]["Complete"] and run["Evaluation"]["Feasible"] and 0 <= run["Work"] <= run["Limit"], "Incomplete/infeasible/overspent development run")
        require(run["ReferenceCmax"] > 0 and all(math.isfinite(run[x]) and run[x] >= 0 for x in ("Seconds", "Work", "ReferenceCmax")), "Invalid development run scalars")
        run["SeedIndex"] = expected["SeedIndex"]
        run["SourceRunFile"] = sources.key(path)
        runs[(run["InstanceId"], run["ConfigId"], run["Seed"])] = run
    return runs


def load_replay(root, sources, meta, runs):
    folder, phase = meta["folder"], meta["phase"]
    spec = json.loads(meta["replay"]["Specification"])
    for name, expected in spec["Core"].items():
        require(sources.sha(root / "reproducibility" / "src" / name) == expected, "Replay source changed: " + name)
    for name, expected in spec["Inputs"].items():
        require(sources.sha(root / Path(name.replace("\\", "/"))) == expected, "Replay input hash mismatch")
    for name, expected in spec["Plans"].items():
        require(sources.sha(folder / "runs" / name) == expected, "Replay plan hash mismatch")
    parts = folder / "replay"
    summaries = []
    for item in sorted(meta["spec"]["Inputs"], key=lambda x: x["InstanceId"]):
        for cv in meta["cvs"]:
            stem = f"{item['InstanceId']}_cv{cv*100:02.0f}_rho00"
            chunk = sources.json(parts / (stem + "_manifest.json"))
            expected_seed = seed(f"replay|{item['InstanceId']}|cv{cv:.2f}|rho0.00")
            require(chunk["RunSetDigest"] == meta["replay"]["Digest"] and int(chunk["ScenarioSeed"]) == expected_seed and expected_seed != item["TrainingSeed"], "Replay chunk/scenario independence mismatch")
            chunk_plans = sum(run["InstanceId"] == item["InstanceId"] for run in runs.values())
            require(chunk["Instance"] == item["InstanceId"] and chunk["Phase"] == phase and float(chunk["CV"]) == cv and float(chunk["Rho"]) == 0 and int(chunk["Scenarios"]) == 1000 and int(chunk["Plans"]) == chunk_plans and int(chunk["Decodings"]) == chunk_plans * 1000, "Replay chunk contract mismatch")
            for suffix, field in (("_summary.csv", "SummarySha256"), ("_reference.json", "ReferenceSha256"), (".csv.gz", "RawSha256")):
                require(sources.sha(parts / (stem + suffix)) == chunk[field], "Replay chunk checksum mismatch: " + stem + suffix)
            summaries.append(parts / (stem + "_summary.csv"))
    merged_lines = sources.text(folder / "replay_plan.csv").splitlines()
    combined = []
    for path in sorted(summaries):
        lines = sources.text(path).splitlines()
        if not combined:
            combined.append(lines[0])
        require(combined[0] == lines[0], "Replay CSV schema mismatch")
        combined.extend(lines[1:])
    require(merged_lines == combined, "Merged replay differs from its verified chunks")
    rows = sources.csv(folder / "replay_plan.csv")
    result = {}
    for row in rows:
        key = (row["InstanceId"], row["ConfigId"], int(row["Seed"]))
        require(key in runs, "Replay contains an unknown plan")
        run = runs[key]
        cv = float(row["CV"])
        require(cv in meta["cvs"] and float(row["Rho"]) == 0 and int(row["Scenarios"]) == 1000, "Wrong development replay conditions")
        require(row["Phase"] == phase and row["Method"] == run["Method"] and row["ScheduleId"] == run["ScheduleId"], "Replay identity mismatch")
        require((key, cv) not in result, "Duplicate development replay row")
        close(row["ReferenceCmax"], run["ReferenceCmax"], "Replay/reference mismatch")
        for field in ("WaitCVaR", "CmaxCVaR", "ReferenceReplayCvarCmax"):
            require(math.isfinite(float(row[field])) and float(row[field]) >= 0, "Invalid independent development metric")
        result[(key, cv)] = row
    require(len(result) == len(runs) * len(meta["cvs"]), "Incomplete development replay plan/condition grid")
    return result


def mean(values):
    values = list(values)
    require(values and all(math.isfinite(float(x)) for x in values), "Invalid mean inputs")
    return math.fsum(values) / len(values)


def stage_rankings(sources, meta, runs, replay, shortlist_ids, selected_ids, stage):
    recorded = sources.json(meta["folder"] / "ranking.json")
    configs = {c["Id"]: c for c in meta["spec"]["Configurations"]}
    require(len(recorded) == len(configs) and {r["ConfigId"] for r in recorded} == set(configs), "Incomplete stage rankings")
    output = []
    for item in recorded:
        plans = [r for r in runs.values() if r["ConfigId"] == item["ConfigId"]]
        require(item["Count"] == len(plans) and item["Method"] == configs[item["ConfigId"]]["Method"], "Stage ranking identities/counts")
        grouped = {}
        for run in plans:
            grouped.setdefault(run["InstanceId"], []).append(run)
        def score(run):
            return (run["Evaluation"]["Risk"] if stage == "tune" else float(replay[((run["InstanceId"], run["ConfigId"], run["Seed"]), .2)]["WaitCVaR"])) / run["ReferenceCmax"]
        actual = mean(mean(score(run) for run in group) for group in grouped.values())
        close(item["Score"], actual, "Archived stage score does not match its declared observations")
        guard_mean = 0
        if stage == "selection":
            def guard(run):
                row = replay[((run["InstanceId"], run["ConfigId"], run["Seed"]), .2)]
                return (float(row["CmaxCVaR"]) - float(row["ReferenceReplayCvarCmax"])) / run["ReferenceCmax"]
            guard_mean = mean(mean(guard(run) for run in group) for group in grouped.values())
        close(item["GuardExcess"], max(0, guard_mean - .01), "Archived development safeguard score mismatch")
        require(item["Eligible"] == (guard_mean <= .01), "Archived development safeguard eligibility mismatch")
        close(item["Seconds"], mean(r["Seconds"] for r in plans), "Archived elapsed mean mismatch")
        close(item["Work"], mean(r["Work"] for r in plans), "Archived work mean mismatch")
        output.append({"Stage": stage, "Method": item["Method"], "ConfigId": item["ConfigId"], "Plans": item["Count"], "ScoreMetric": "training WaitCVaR/Cref" if stage == "tune" else "independent CV0.20 WaitCVaR/Cref", "Score": item["Score"], "GuardExcess": item["GuardExcess"], "Eligible": item["Eligible"], "Seconds": item["Seconds"], "Work": item["Work"], "Shortlisted": item["ConfigId"] in shortlist_ids, "Selected": item["ConfigId"] in selected_ids})
    output.sort(key=lambda x: (x["Method"], x["GuardExcess"], x["Score"], x["ConfigId"]))
    for method in METHODS:
        method_rows = [r for r in output if r["Method"] == method]
        for rank, row in enumerate(method_rows, 1):
            row["RankWithinMethod"] = rank
        archived_choice = shortlist_ids if stage == "tune" else selected_ids
        take = 2 if stage == "tune" else 1
        require({r["ConfigId"] for r in method_rows[:take]} == {r["ConfigId"] for r in method_rows if r["ConfigId"] in archived_choice}, "Archived choice does not match its archived ranking")
    return output


def sensitivity_plans(context, all_runs, all_replay):
    selected = {c["Method"]: c["Id"] for c in context["selected"]}
    plans = []
    for k in (32, 64, 128):
        phase = context["selection_phase"] if k == 64 else f"dev_trainingK{k}"
        for key, run in all_runs[phase].items():
            if run["ConfigId"] != selected[run["Method"]] or run["SeedIndex"] not in (1, 2):
                continue
            row = all_replay[phase][(key, .2)]
            reference = float(row["ReferenceCmax"])
            plans.append({"N": run["N"], "InstanceId": run["InstanceId"], "Method": run["Method"], "ConfigId": run["ConfigId"], "K": k, "Seed": run["Seed"], "SeedIndex": run["SeedIndex"], "ScheduleId": run["ScheduleId"], "SourcePhase": phase, "SourceRunFile": run["SourceRunFile"], "ReusedSelectionPlan": k == 64, "CV": .20, "Scenarios": 1000, "ReferenceCmax": reference, "WaitCVaR": float(row["WaitCVaR"]), "CmaxCVaR": float(row["CmaxCVaR"]), "ReferenceReplayCvarCmax": float(row["ReferenceReplayCvarCmax"]), "WaitCVaRNorm": float(row["WaitCVaR"]) / reference, "CmaxCVaRExcessNorm": (float(row["CmaxCVaR"]) - float(row["ReferenceReplayCvarCmax"])) / reference, "Seconds": run["Seconds"], "Work": run["Work"], "Limit": run["Limit"], "WorkFraction": run["Work"] / run["Limit"]})
    return sorted(plans, key=lambda x: (x["N"], x["Method"], x["K"], x["InstanceId"], x["SeedIndex"]))


def aggregate_sensitivity(plans):
    require(len(plans) == 480, "Expected 480 plans across K=32/64/128")
    groups = {}
    for row in plans:
        groups.setdefault((row["N"], row["InstanceId"], row["Method"], row["ConfigId"], row["K"]), []).append(row)
    require(len(groups) == 240, "Expected 240 instance/method/K cells")
    instances = []
    for key, rows in sorted(groups.items()):
        n, instance, method, config, k = key
        require(len(rows) == 2 and {x["SeedIndex"] for x in rows} == {1, 2}, "Missing paired seed indices")
        require({x["Seed"] for x in rows} == {seed(f"algorithm|{instance}|{i}") for i in (1, 2)}, "Unpaired search seeds")
        require(len({x["SourcePhase"] for x in rows}) == 1, "Mixed source phase within cell")
        close(rows[0]["ReferenceCmax"], rows[1]["ReferenceCmax"], "Nonshared common reference")
        instances.append({"N": n, "InstanceId": instance, "Method": method, "ConfigId": config, "K": k, "SearchSeeds": 2, "SourcePhase": rows[0]["SourcePhase"], "ReferenceCmax": rows[0]["ReferenceCmax"], **{metric: mean(x[metric] for x in rows) for metric in METRICS}})
    cells = {}
    for row in instances:
        cells.setdefault((row["N"], row["Method"], row["ConfigId"], row["K"]), []).append(row)
    require(len(cells) == 48 and {(n, m, k) for n, m, _, k in cells} == {(n, m, k) for n in SIZES for m in METHODS for k in (32, 64, 128)}, "Incomplete size/method/K grid")
    summary = []
    for (n, method, config, k), rows in sorted(cells.items()):
        require(len(rows) == 5 and {x["InstanceId"] for x in rows} == {f"development_N{n}_I{i:02}" for i in range(6, 11)}, "Incorrect development instance set")
        summary.append({"N": n, "Method": method, "ConfigId": config, "K": k, "Instances": 5, "SearchSeedsPerInstance": 2, **{metric: mean(x[metric] for x in rows) for metric in METRICS}, "WaitCVaRNorm_SD": statistics.stdev(x["WaitCVaRNorm"] for x in rows), "CmaxCVaRExcessNorm_SD": statistics.stdev(x["CmaxCVaRExcessNorm"] for x in rows)})
    for instance in expected_ids(6, 10):
        references = [x["ReferenceCmax"] for x in instances if x["InstanceId"] == instance]
        require(max(references) - min(references) <= 1e-9 * max(1, max(references)), "Reference differs across K/method")
    return instances, summary


def csv_text(rows):
    require(rows, "Cannot export an empty table")
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader(); writer.writerows(rows)
    return buffer.getvalue()


def escape(value):
    return str(value).replace("\\", r"\textbackslash{}").replace("_", r"\_").replace("%", r"\%").replace("&", r"\&")


def settings(config):
    keys = {"TS-JS": ("Pool", "Shortlist", "Tenure", "GuidedProbability"), "GA": ("Population", "MutationProbability"), "ALNS": ("RemovalFraction", "Reaction", "RepairTrials", "InitialTemperature"), "CB-TS": ("Pool", "Tenure")}[config["Method"]]
    labels = {"Pool": "pool", "Shortlist": "shortlist", "Tenure": "tenure", "GuidedProbability": "guided", "Population": "population", "MutationProbability": "mutation", "RemovalFraction": "removal", "Reaction": "reaction", "RepairTrials": "repair trials", "InitialTemperature": "temperature fraction"}
    return "; ".join(f"{labels[key]}={config[key]}" for key in keys)


def tex_table(columns, headers, rows, long=False):
    environment = "longtable" if long else "tabular"
    lines = [f"\\begin{{{environment}}}{{{columns}}}", r"\toprule", " & ".join(headers) + r" \\", r"\midrule"]
    if long:
        lines += [r"\endhead"]
    lines += [" & ".join(map(str, row)) + r" \\" for row in rows]
    return "\n".join(lines + [r"\bottomrule", f"\\end{{{environment}}}", ""])


def outputs(context, rankings, plans, instances, summary):
    grid = [{**c, "Shortlisted": c in context["shortlist"], "Selected": c in context["selected"], "EffectiveParameters": settings(c)} for c in context["grid"]]
    selected = [{**c, "EffectiveParameters": settings(c)} for c in context["selected"]]
    result = {"development_grid.csv": csv_text(grid), "development_rankings.csv": csv_text(rankings), "selected_parameters.csv": csv_text(selected), "training_sensitivity_plan.csv": csv_text(plans), "training_sensitivity_instance.csv": csv_text(instances), "training_sensitivity_summary.csv": csv_text(summary)}
    result["development_grid.tex"] = tex_table("llp{8.5cm}", ["Method", "Configuration", "Parameters varied (other settings archived)"], [[escape(c["Method"]), escape(c["Id"]), escape(settings(c))] for c in context["grid"]], True)
    result["selected_parameters.tex"] = tex_table("llp{8.5cm}", ["Method", "Selected configuration", "Effective parameters"], [[escape(c["Method"]), escape(c["Id"]), escape(settings(c))] for c in context["selected"]])
    result["development_rankings.tex"] = tex_table("llrrrrcc", ["Stage", "Configuration", "Rank", "Score", "Guard excess", "Work/$10^6$", "Shortlist", "Selected"], [["Screen" if r["Stage"] == "tune" else "Selection", escape(r["ConfigId"]), r["RankWithinMethod"], f"{r['Score']:.6f}", f"{r['GuardExcess']:.6f}", f"{r['Work']/1e6:.3f}", "Yes" if r["Shortlisted"] else "No", "Yes" if r["Selected"] else "No"] for r in rankings], True)
    result["training_sensitivity.tex"] = tex_table("rlrrrrr", ["$N$", "Method", "$K$", "$R/C^0_{ref}$", "$(H-H_{ref})/C^0_{ref}$", "Seconds", "Work/$10^6$"], [[r["N"], escape(r["Method"]), r["K"], f"{r['WaitCVaRNorm']:.6f}", f"{r['CmaxCVaRExcessNorm']:.6f}", f"{r['Seconds']:.3f}", f"{r['Work']/1e6:.3f}"] for r in summary], True)
    result["development_notes.tex"] = ("These are descriptive development results. Screening scores use training risk; selection scores use independent replay at CV 0.20. Configuration eligibility and any fallback remain as recorded in the original selection audit. No configuration is selected again by this reporting script.\n\n"
        "For training-bank sensitivity, each table cell first averages the two paired search seeds within each instance and then the five development instances of that size. All entries use 1000 independent replay scenarios at CV 0.20. The $K=64$ plans reuse the selected configurations and seed indices 1 and 2 from the selection stage. The $K=32$ and $K=128$ banks are nested prefixes from the same training seed, under the same event-work budget. $H_{ref}$ is the common reference plan's CVaR under the same independent replay scenarios; its signed difference is not truncated at zero. Seconds are archived development elapsed times, not the dedicated single-core timing confirmation. The selection instances are development data, not the held-out confirmation sample.\n")
    return result


def run(root):
    root = root.resolve()
    sources = Sources(root)
    context = preflight(root, sources)  # No outcome files may be opened above this line.
    all_runs = {name: load_runs(root, sources, meta) for name, meta in context["phases"].items()}
    all_replay = {name: load_replay(root, sources, meta, all_runs[name]) for name, meta in context["phases"].items() if meta["cvs"]}
    shortlist_ids = {c["Id"] for c in context["shortlist"]}; selected_ids = {c["Id"] for c in context["selected"]}
    rankings = []
    for phase, stage in ((f"dev_r{context['round']}_tune", "tune"), (context["selection_phase"], "selection")):
        rankings += stage_rankings(sources, context["phases"][phase], all_runs[phase], all_replay.get(phase), shortlist_ids, selected_ids, stage)
    plans = sensitivity_plans(context, all_runs, all_replay)
    instances, summary = aggregate_sensitivity(plans)
    artifacts = outputs(context, rankings, plans, instances, summary)
    sources.sha(Path(__file__))
    manifest = {"Status": "complete", "GeneratedUtc": datetime.now(timezone.utc).isoformat(), "Purpose": "Descriptive reporting of completed development only; no new tuning, selection or confirmation inference.", "SelectionRound": context["round"], "SelectionPhase": context["selection_phase"], "SelectedConfigurations": context["selected"], "DevelopmentGuardFallbackMethods": context["selection_audit"].get("FallbackMethods", []), "RequiredOptimizationPlans": {p: len(m["spec"]["Runs"]) for p, m in context["phases"].items()}, "SensitivityPlans": len(plans), "SensitivityInstanceCells": len(instances), "SensitivitySummaryCells": len(summary), "Aggregation": "Two paired seed values per instance, followed by five equally weighted development instances per size; independent CV=.20 replay, 1000 scenarios per plan.", "K64Reuse": "Selection-stage plans for final configurations, seed indices 1 and 2; no additional plans.", "SourceSha256": dict(sorted(sources.hashes.items())), "OutputSha256": {name: hashlib.sha256(text.encode("utf-8")).hexdigest() for name, text in artifacts.items()}}
    destination = root / "supplement" / "generated" / "development"
    # No report directory or metric table is created until all inputs validate.
    destination.mkdir(parents=True, exist_ok=True)
    for name, text in artifacts.items():
        temporary = destination / (name + ".tmp")
        temporary.write_text(text, encoding="utf-8", newline="")
        os.replace(temporary, destination / name)
    temporary = destination / "source_manifest.json.tmp"
    temporary.write_text(json.dumps(manifest, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temporary, destination / "source_manifest.json")
    print(f"Completed development summary: {len(plans)} sensitivity plans, {len(instances)} instance cells, {len(summary)} summary cells; {destination}")


def selftest():
    """Artificial hierarchy/normalization and fail-before-read tests only."""
    plans = []
    for n in SIZES:
        for method_index, method in enumerate(METHODS):
            for k in (32, 64, 128):
                for i in range(6, 11):
                    instance = f"development_N{n}_I{i:02}"
                    for s in (1, 2):
                        plans.append({"N": n, "InstanceId": instance, "Method": method, "ConfigId": method + "_fake", "K": k, "Seed": seed(f"algorithm|{instance}|{s}"), "SeedIndex": s, "SourcePhase": "fake-selection" if k == 64 else f"fake-K{k}", "ReferenceCmax": 100 + n, "WaitCVaRNorm": (k + n + i + method_index + s) / 1000, "CmaxCVaRExcessNorm": (s - 2) / 1000, "Seconds": s, "Work": 100*s, "WorkFraction": s/3})
    instances, summary = aggregate_sensitivity(plans)
    first = next(x for x in summary if x["N"] == 24 and x["Method"] == "ALNS" and x["K"] == 32)
    close(first["WaitCVaRNorm"], (32 + 24 + 8 + 1.5) / 1000, "Artificial seed/instance hierarchy")
    close(first["CmaxCVaRExcessNorm"], -.0005, "Negative completion-risk differences must remain")
    close(first["Seconds"], 1.5, "Paired elapsed mean")
    grid = [{"Id": method + f"_c{i:02}", "Method": method, "Pool": 128, "Shortlist": 24, "Tenure": 7, "GuidedProbability": .8, "Population": 16, "MutationProbability": .5, "RemovalFraction": .04, "Reaction": .1, "RepairTrials": 6, "InitialTemperature": .05} for method in METHODS for i in range(8)]
    shortlist = [c for c in grid if c["Id"].endswith(("00", "01"))]
    selected = [c for c in grid if c["Id"].endswith("00")]
    context = {"grid": grid, "shortlist": shortlist, "selected": selected}
    rankings = [{"Stage": stage, "Method": c["Method"], "ConfigId": c["Id"], "Plans": 40 if stage == "tune" else 100, "ScoreMetric": "fake", "Score": .1, "GuardExcess": 0, "Eligible": True, "Seconds": 1, "Work": 100, "Shortlisted": c in shortlist, "Selected": c in selected, "RankWithinMethod": int(c["Id"][-2:]) + 1} for stage, configs in (("tune", grid), ("selection", shortlist)) for c in configs]
    rendered = outputs(context, rankings, plans, instances, summary)
    require(len(list(csv.DictReader(io.StringIO(rendered["development_grid.csv"])))) == 32, "Artificial grid export")
    require(len(list(csv.DictReader(io.StringIO(rendered["development_rankings.csv"])))) == 40, "Artificial rank export")
    require(len(list(csv.DictReader(io.StringIO(rendered["training_sensitivity_summary.csv"])))) == 48, "Artificial sensitivity export")
    require(rendered["training_sensitivity.tex"].count(r" \\") == 49 and rendered["training_sensitivity.tex"].endswith("\\end{longtable}\n"), "Artificial LaTeX row/environment export")
    rejected = False
    try:
        aggregate_sensitivity(plans[:-1])
    except ValueError:
        rejected = True
    require(rejected, "Missing paired seed was accepted")
    with tempfile.TemporaryDirectory(prefix="tailrisk-dev-summary-fake-") as directory:
        root = Path(directory)
        outcome = root / "reproducibility" / "results" / "dev_r1_tune" / "runs" / "poison.json"
        outcome.parent.mkdir(parents=True)
        outcome.write_text("This must never be parsed as an outcome.", encoding="utf-8")
        source = Sources(root)
        try:
            preflight(root, source)
            raise AssertionError("Incomplete study accepted")
        except FileNotFoundError:
            pass
        require(not any("/runs/" in path or path.endswith("replay_plan.csv") or path.endswith("ranking.json") for path in source.hashes), "Outcome read before completeness gate")
        require(not (root / "supplement" / "generated" / "development").exists(), "Partial output directory created")
    print("PASS artificial selftest: 480 plans -> 240 paired instance cells -> 48 summaries; CSV/TeX exports; missing seed rejected; incomplete phases read no outcomes and write no performance files.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--selftest", "--self-test", nargs="?", const="fake", choices=["fake"])
    args = parser.parse_args()
    if args.selftest:
        selftest()
    else:
        run(args.root)


if __name__ == "__main__":
    main()
