"""Generate traced paper/SI assets only after every formal analysis is complete.

This script formats archived outputs. It does not change endpoints, estimate new
hypotheses, select algorithms, or modify the frozen statistical analysis.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

PHASES = ("main", "ablation", "timing", "correlated")
METHODS = ("GA", "ALNS", "CB-TS", "TS-JS")
ENDPOINTS = {
    "WaitCVaR": ("Total AGV wait CVaR95", "time"),
    "WaitMean": ("Total AGV wait mean", "time"), "WaitP95": ("Total AGV wait P95", "time"),
    "QAgvWaitMean": ("Quay AGV wait mean", "time"), "QAgvWaitP95": ("Quay AGV wait P95", "time"),
    "YAgvWaitMean": ("Yard AGV wait mean", "time"), "YAgvWaitP95": ("Yard AGV wait P95", "time"),
    "QCraneWaitMean": ("QC wait mean", "time"), "QCraneWaitP95": ("QC wait P95", "time"),
    "YCraneWaitMean": ("YC wait mean", "time"), "YCraneWaitP95": ("YC wait P95", "time"),
    "CmaxMean": ("Makespan mean", "time"), "CmaxCVaR": ("Makespan CVaR95", "time"),
    "CapExceedance": ("Nominal-cap exceedance", "probability"),
    "RelativeCmaxChange": ("Relative makespan change", "percent"),
    "QOccupancyMean": ("Quay occupancy mean", "AGVs"), "QOccupancyP95": ("Quay occupancy P95", "AGVs"), "QOccupancyMax": ("Quay occupancy maximum", "AGVs"),
    "YOccupancyMean": ("Yard occupancy mean", "AGVs"), "YOccupancyP95": ("Yard occupancy P95", "AGVs"), "YOccupancyMax": ("Yard occupancy maximum", "AGVs"),
    "BothOccupancyMean": ("Total occupancy mean", "AGVs"), "BothOccupancyP95": ("Total occupancy P95", "AGVs"), "BothOccupancyMax": ("Total occupancy maximum", "AGVs"),
    "PhaseMean": ("Signed-gap absolute magnitude", "time"), "GTVMean": ("Crane-chain variation", "time"),
    "NominalCmax": ("Nominal makespan", "time"), "Empty": ("Nominal empty travel including initial approach", "time"),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tex(value):
    return str(value).replace("_", r"\_").replace("%", r"\%")


def number(value, digits=3):
    if pd.isna(value):
        return "--"
    if not np.isfinite(value):
        return r"$\infty$" if value > 0 else r"$-\infty$"
    return f"{value:.{digits}f}"


def tabular(path, columns, headers, rows):
    lines = ["\\begin{tabular}{"+columns+"}", r"\toprule", " & ".join(headers)+r" \\", r"\midrule"]
    lines.extend(" & ".join(map(str, row))+r" \\" for row in rows)
    lines += [r"\bottomrule", r"\end{tabular}"]
    path.write_text("\n".join(lines)+"\n", encoding="utf-8")


class AssetBuilder:
    def __init__(self, root):
        self.root = root
        self.output = root / "manuscript" / "generated" / "paper_assets"
        self.output.mkdir(parents=True, exist_ok=True)
        self.sources = {}

    def source(self, relative):
        path = self.root / relative
        require(path.is_file(), "Missing required source: "+str(relative))
        self.sources[str(path.relative_to(self.root)).replace("\\", "/")] = digest(path)
        return path

    def metadata(self):
        selected = json.loads(self.source("reproducibility/configs/selected.json").read_text(encoding="utf-8-sig"))
        by_method = {item["Method"]: item for item in selected}
        require(set(by_method) == set(METHODS), "Expected four selected configurations")
        parameters = {"GA": ("Population", "MutationProbability"), "ALNS": ("RemovalFraction", "Reaction", "RepairTrials", "InitialTemperature"), "CB-TS": ("Pool", "Tenure"), "TS-JS": ("Pool", "Shortlist", "Tenure", "GuidedProbability")}
        names = {"Population": "Population size", "MutationProbability": "Mutation probability", "RemovalFraction": "Removal fraction", "Reaction": "Adaptation rate", "RepairTrials": "Repair trials", "InitialTemperature": "Initial-temperature fraction", "Pool": "Candidate-pool size", "Shortlist": "Fully evaluated shortlist", "Tenure": "Tabu tenure", "GuidedProbability": "Guided-proposal probability"}
        records, rows = [], []
        for method in METHODS:
            config = by_method[method]
            for parameter in parameters[method]:
                value = config[parameter]
                records.append({"Method": method, "ConfigId": config["Id"], "Parameter": parameter, "Value": value})
                rows.append([tex(method), names[parameter], f"{value:g}"])
        pd.DataFrame(records).to_csv(self.output / "selected_parameters.csv", index=False)
        tabular(self.output / "selected_parameters.tex", "llr", ["Method", "Parameter", "Selected value"], rows)
        audit = pd.read_csv(self.source("reports/exact/exact_summary.csv"))
        require(len(audit) == 6 and set(zip(audit.N, audit.Index)) == {(n,i) for n in (4,5,6) for i in (1,2)}, "Incomplete six-case exact audit")
        audit.to_csv(self.output / "exact_audit.csv", index=False)
        rows = [[row.N, row.Index, f"{row.Candidates:,}", f"{row.EventFeasible:,}", f"{row.PriorityRepresentable:,}", row.AllConstraintsFeasible, number(row.FullRisk), number(row.PriorityRisk)] for row in audit.itertuples(index=False)]
        tabular(self.output / "exact_audit.tex", "rrrrrrrr", ["$N$", "Case", "Candidates", "Event-feas.", "Priority", "Cap-feas.", "Full risk", "Priority risk"], rows)
        budgets = json.loads(self.source("reproducibility/configs/timing.json").read_text(encoding="utf-8-sig"))
        tabular(self.output / "timing_budgets.tex", "rr", ["$N$", "Time budget (s)"], [[int(n), number(float(value), 0)] for n, value in sorted(budgets.items(), key=lambda item:int(item[0]))])

    def require_complete(self):
        metadata = json.loads(self.source("analysis/results/main/acceptance.json").read_text(encoding="utf-8-sig"))
        require(metadata.get("strict_complete") and metadata["optimization_plans"] == 2400 and metadata["replay_rows"] == 4800 and metadata["instances"] == 120, "Main analysis is not complete")
        expected = {"main": 960, "ablation": 160, "timing": 160, "correlated": 80}
        frames = {}
        for phase in PHASES:
            frame = pd.read_csv(self.source(f"analysis/results/{phase}/instance_metrics.csv"))
            require(len(frame) == expected[phase], f"Incomplete {phase} instance-level analysis")
            require(frame.SearchSeeds.eq(5).all(), f"Incorrect {phase} search-seed means")
            require(set(ENDPOINTS) <= set(frame.columns), f"Missing {phase} endpoints")
            require(not frame[list(ENDPOINTS)].isna().any().any(), f"Missing {phase} values")
            frames[phase] = frame
        return frames

    def auxiliary_tables(self):
        for phase, expected in (("ablation", 6), ("timing", 6), ("correlated", 3)):
            comparisons = pd.read_csv(self.source(f"analysis/results/{phase}/secondary_comparisons.csv"))
            chosen = comparisons[(comparisons.Metric == "WaitCVaR") & (comparisons.N == 0)].sort_values(["CV", "Comparator"])
            require(len(chosen) == expected, f"Missing predefined {phase} comparison")
            chosen.to_csv(self.output / f"{phase}_waiting_effects.csv", index=False)
            rows = []
            for row in chosen.itertuples(index=False):
                rows.append([tex(row.Comparator), number(row.CV,2), number(row.Rho,2), number(row.estimate,5), f"[{number(row.ci_low,5)}, {number(row.ci_high,5)}]", "<0.001" if row.p_holm < .001 else number(row.p_holm,3)])
            tabular(self.output / f"{phase}_waiting_effects.tex", "lrrrrr", ["Comparator", "CV", r"$\rho$", "Difference", "95\\% CI", "Holm $p$"], rows)

    def endpoint_archive(self, frames):
        long = []
        for phase, frame in frames.items():
            for (n, label, cv, rho, source), group in frame.groupby(["N", "Label", "CV", "Rho", "SourcePhase"], sort=True):
                for metric, (display, unit) in ENDPOINTS.items():
                    values = group[metric].to_numpy()
                    long.append({"AnalysisPhase": phase, "SourcePhase": source, "N": n, "Method": label, "CV": cv, "Rho": rho, "Metric": metric, "Description": display, "Unit": unit, "Mean": float(values.mean()), "InstanceSD": float(values.std(ddof=1)), "Instances": len(values), "SearchSeedsPerInstance": 5})
        pd.DataFrame(long).to_csv(self.output / "si_all_endpoints.csv", index=False, encoding="utf-8-sig")
        rows = [[tex(metric), display, unit] for metric, (display, unit) in ENDPOINTS.items()]
        tabular(self.output / "si_endpoint_index.tex", "lll", ["CSV field", "Endpoint", "Unit"], rows)

    def archived_runs(self, phase):
        folder = self.root / "reproducibility" / "results" / phase / "runs"
        runs = []
        for path in sorted(folder.glob("*.json")):
            runs.append(json.loads(self.source(path.relative_to(self.root)).read_text(encoding="utf-8-sig")))
        require(len(runs) == (2400 if phase == "main" else 400), f"Incomplete {phase} archived runs")
        return runs

    def convergence(self, runs, *, fixture=False):
        plan_rows = []
        for run in runs:
            require(run["Limit"] > 0 and run["ReferenceCmax"] > 0, "Invalid convergence reference/budget")
            for name, fraction in (("quarter", .25), ("half", .5), ("termination", None)):
                carried = False
                if fraction is None:
                    point = {"Work": run["Work"], "Seconds": run["Seconds"], "Risk": run["Evaluation"]["Risk"]}
                else:
                    candidates = [point for point in run["Checkpoints"] if abs(point["Fraction"]-fraction) < 1e-12]
                    if candidates:
                        point = min(candidates, key=lambda item:item["Work"])
                    else:
                        require(run["Work"] < fraction*run["Limit"], "Unexplained missing work checkpoint")
                        point = {"Work": run["Work"], "Seconds": run["Seconds"], "Risk": run["Evaluation"]["Risk"]}
                        carried = True
                plan_rows.append({"N": run["N"], "InstanceId": run["InstanceId"], "Method": run["Method"], "Seed": run["Seed"], "Checkpoint": name, "TargetFraction": fraction, "ActualWorkFraction": point["Work"]/run["Limit"], "Work": point["Work"], "Seconds": point["Seconds"], "TrainingRisk": point["Risk"], "RiskOverCref": point["Risk"]/run["ReferenceCmax"], "CarriedAfterTermination": carried})
        plans = pd.DataFrame(plan_rows)
        plans.to_csv(self.output / "convergence_plans.csv", index=False)
        keys = ["N", "InstanceId", "Method", "Checkpoint"]
        instance = plans.groupby(keys, as_index=False).agg(ActualWorkFraction=("ActualWorkFraction", "mean"), Work=("Work", "mean"), Seconds=("Seconds", "mean"), TrainingRisk=("TrainingRisk", "mean"), RiskOverCref=("RiskOverCref", "mean"), CarriedSeeds=("CarriedAfterTermination", "sum"), Seeds=("Seed", "size"))
        require(instance.Seeds.eq(5).all(), "Unpaired convergence seeds")
        instance.to_csv(self.output / "convergence_instances.csv", index=False)
        summary = instance.groupby(["N", "Method", "Checkpoint"], as_index=False).agg(ActualWorkFraction=("ActualWorkFraction", "mean"), Work=("Work", "mean"), Seconds=("Seconds", "mean"), TrainingRisk=("TrainingRisk", "mean"), RiskOverCref=("RiskOverCref", "mean"), Instances=("InstanceId", "size"), CarriedSeeds=("CarriedSeeds", "sum"))
        require(summary.Instances.eq(30).all(), "Incomplete convergence instances")
        summary.to_csv(self.output / "convergence_summary.csv", index=False)
        plot_convergence(summary, self.output, extensions=("png",) if fixture else ("pdf", "png"), fixture=fixture)

    def monte_carlo_stability(self):
        frame = pd.read_csv(self.source("reproducibility/results/main/replay_plan.csv"))
        keys = ["InstanceId", "Method", "Seed", "CV", "Rho"]
        prefixes = (250, 500)
        metrics = ("WaitCVaR", "CmaxCVaR")
        required = keys + ["N", "ReferenceCmax", "Scenarios"] + [metric+"First"+str(prefix) for metric in metrics for prefix in prefixes] + list(metrics)
        require(set(required) <= set(frame.columns), "Missing frozen Monte Carlo prefix summaries")
        require(len(frame) == 4800 and not frame.duplicated(keys).any(), "Incomplete/duplicate Monte Carlo plan summaries")
        require(frame.Scenarios.eq(1000).all() and frame.Rho.eq(0).all() and set(frame.CV) == {.1,.2}, "Incorrect Monte Carlo test scenarios")
        require(np.isfinite(frame[["ReferenceCmax"] + required[-6:]].to_numpy()).all() and frame.ReferenceCmax.gt(0).all(), "Nonfinite Monte Carlo summary")
        records = []
        for metric in metrics:
            for prefix in prefixes:
                subset = frame[keys + ["N"]].copy()
                subset["Metric"] = metric
                subset["Prefix"] = prefix
                subset["AbsoluteDifferenceOverCref"] = (frame[metric+"First"+str(prefix)]-frame[metric]).abs()/frame.ReferenceCmax
                records.append(subset)
        plans = pd.concat(records, ignore_index=True)
        plans.to_csv(self.output / "monte_carlo_prefix_plans.csv", index=False)
        instance = plans.groupby(["N", "InstanceId", "Method", "CV", "Rho", "Metric", "Prefix"], as_index=False).agg(AbsoluteDifferenceOverCref=("AbsoluteDifferenceOverCref", "mean"), Seeds=("Seed", "size"))
        require(instance.Seeds.eq(5).all(), "Incomplete Monte Carlo search-seed pairing")
        instance.to_csv(self.output / "monte_carlo_prefix_instances.csv", index=False)
        summary = instance.groupby(["N", "Method", "CV", "Rho", "Metric", "Prefix"], as_index=False).agg(MeanAbsoluteDifferenceOverCref=("AbsoluteDifferenceOverCref", "mean"), MaximumInstanceMeanAbsoluteDifferenceOverCref=("AbsoluteDifferenceOverCref", "max"), Instances=("InstanceId", "size"))
        require(len(summary) == 128 and summary.Instances.eq(30).all(), "Incomplete Monte Carlo size/method/prefix cells")
        summary.to_csv(self.output / "monte_carlo_prefix_summary.csv", index=False)
        for metric in metrics:
            rows = [[row.N, tex(row.Method), number(row.CV,2), row.Prefix, number(row.MeanAbsoluteDifferenceOverCref,6), number(row.MaximumInstanceMeanAbsoluteDifferenceOverCref,6)] for row in summary[summary.Metric.eq(metric)].itertuples(index=False)]
            tabular(self.output / ("monte_carlo_"+metric+".tex"), "rlrrrr", ["$N$", "Method", "CV", "Prefix", "Mean abs. diff.", "Max. instance diff."], rows)

    def runtimes(self, main_runs, timing_runs):
        raw = []
        for phase, runs in (("main", main_runs), ("timing", timing_runs)):
            for run in runs:
                raw.append({"Phase": phase, "N": run["N"], "InstanceId": run["InstanceId"], "Method": run["Method"], "Seed": run["Seed"], "Seconds": run["Seconds"], "TimeLimit": run["TimeLimit"], "WorkMillions": run["Work"]/1e6, "BudgetUse": run["Work"]/run["Limit"] if phase == "main" else run["Seconds"]/run["TimeLimit"], "Evaluations": run["Evaluations"], "StopReason": run["StopReason"]})
        plans = pd.DataFrame(raw)
        plans.to_csv(self.output / "runtime_plans.csv", index=False)
        instance = plans.groupby(["Phase", "N", "InstanceId", "Method"], as_index=False)[["Seconds", "TimeLimit", "WorkMillions", "BudgetUse", "Evaluations"]].mean()
        instance.to_csv(self.output / "runtime_instances.csv", index=False)
        summary = instance.groupby(["Phase", "N", "Method"], as_index=False).agg(MeanSeconds=("Seconds", "mean"), MedianInstanceSeconds=("Seconds", "median"), TimeLimit=("TimeLimit", "mean"), WorkMillions=("WorkMillions", "mean"), BudgetUse=("BudgetUse", "mean"), Evaluations=("Evaluations", "mean"), Instances=("InstanceId", "size"))
        summary.to_csv(self.output / "runtime_summary.csv", index=False)
        rows = [[tex(row.Phase), row.N, tex(row.Method), "--" if row.TimeLimit == 0 else number(row.TimeLimit,0), number(row.MeanSeconds,3), number(row.WorkMillions,2), number(100*row.BudgetUse,2)] for row in summary.itertuples(index=False)]
        tabular(self.output / "runtime_summary.tex", "lrlrrrr", ["Phase", "$N$", "Method", "Limit (s)", "Elapsed (s)", "Work ($10^6$)", "Budget use (\\%)"], rows)

    def manifest(self, metadata_only=False):
        notes = {"effect_direction": "Comparator minus full/proposed, normalized by each instance's common Cref; positive means lower proposed waiting risk.", "confidence_intervals": "Copied from frozen analysis; 20,000 paired instance bootstrap draws; pointwise 95% intervals.", "convergence": "Training-risk checkpoints only. Five seeds are averaged within an instance before instance means are averaged. The x coordinate is actual recorded work, including the actual termination point; it is not forced to 100%.", "early_termination": "If a run ends before a target checkpoint, its returned plan is reused with the actual termination work and explicitly marked CarriedAfterTermination.", "timing": "Main elapsed times arise from concurrent work-limited jobs; they are descriptive. Timing jobs use a common isolated-core wall-clock limit. Budget use means work/limit for main and elapsed/time limit for timing.", "occupancy": "Each occupancy mean/P95/maximum is calculated within a scenario on [0,Cmax] and then averaged across scenarios. This differs from pooled waiting quantiles.", "auxiliary": "Ablation full-method values reuse matching main plans; correlated replay reuses main plans. Neither adds independent main instances.", "exact": "Small-case audit only. Very few plans remain after three caps; equality of domain optima does not prove general domain completeness or search superiority."}
        notes["monte_carlo_prefixes"] = "All 2,400 main plans and both CVs are included. For each plan, compare each fixed prefix (first 250 or 500 scenarios) with the full 1,000-scenario CVaR, take the absolute difference divided by Cref, then average five search seeds within each instance. Tables give the mean and maximum of the 30 instance means in each size/method/CV cell. Prefixes share scenarios; these are descriptive diagnostics, not independent replications, hypothesis tests, or proofs of convergence."
        (self.output / "asset_notes.json").write_text(json.dumps(notes, indent=2)+"\n", encoding="utf-8")
        metadata_names = {"selected_parameters.csv", "selected_parameters.tex", "exact_audit.csv", "exact_audit.tex", "timing_budgets.tex", "asset_notes.json"}
        outputs = {path.name: digest(path) for path in sorted(self.output.iterdir()) if path.is_file() and path.name != "manifest.json" and (not metadata_only or path.name in metadata_names)}
        manifest = {"CreatedUTC": datetime.now(timezone.utc).isoformat(), "MetadataOnly": metadata_only, "Generator": str(Path(__file__).resolve()), "GeneratorSha256": digest(Path(__file__).resolve()), "Sources": self.sources, "Outputs": outputs, "Notes": notes}
        (self.output / "manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")


def plot_convergence(summary, output, extensions=("pdf", "png"), fixture=False):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "pdf.fonttype": 42, "ps.fonttype": 42, "axes.spines.top": False, "axes.spines.right": False, "savefig.dpi": 300})
    colors = {"GA": "#7A7D82", "ALNS": "#0072B2", "CB-TS": "#D55E00", "TS-JS": "#009E73"}
    fig, axes = plt.subplots(2, 2, figsize=(7.0, 4.5), constrained_layout=True)
    for axis, n in zip(axes.flat, (24,48,96,192)):
        for method in METHODS:
            group = summary[(summary.N == n) & (summary.Method == method)].copy()
            group["Order"] = group.Checkpoint.map({"quarter": 0, "half": 1, "termination": 2})
            group = group.sort_values("Order")
            axis.plot(100*group.ActualWorkFraction, group.RiskOverCref, marker="o", markersize=3, linewidth=1.1, label=method, color=colors[method])
        axis.set_title(f"{n} tasks");axis.set_xlabel("Actual event-work budget used (%)")
        axis.set_ylabel("Training waiting CVaR95 / Cref")
        axis.set_xlim(0, 103);axis.grid(alpha=.18)
    axes[0,0].legend(frameon=False, fontsize=7, ncol=2)
    if fixture:
        fig.suptitle("Artificial data: layout check only", fontsize=10)
    for extension in extensions:
        fig.savefig(output / ("convergence_training_risk."+extension), bbox_inches="tight")
    plt.close(fig)


def self_test(output):
    output.mkdir(parents=True, exist_ok=True)
    require(len(ENDPOINTS) == 28, "Complete endpoint index")
    rows = []
    for n in (24,48,96,192):
        for index, method in enumerate(METHODS):
            for position, checkpoint in enumerate(("quarter", "half", "termination")):
                rows.append({"N": n, "Method": method, "Checkpoint": checkpoint, "ActualWorkFraction": (.251,.502,.982)[position], "RiskOverCref": .08 + n*.00005 + .003*index - .009*position})
    plot_convergence(pd.DataFrame(rows), output, extensions=("png",), fixture=True)
    tabular(output / "table_fixture.tex", "lrr", ["Method", "Estimate", "95\\% CI"], [["TS-JS", "0.01234", "[0.00123, 0.02345]"]])
    require((output / "convergence_training_risk.png").stat().st_size > 1000, "Missing layout-check figure")
    integration = pipeline_fixture()
    (output / "selftest.json").write_text(json.dumps({"ArtificialDataOnly": True, "Pipeline": integration}, indent=2)+"\n", encoding="utf-8")
    print("Paper-asset self-test passed; only artificial data were used. Fixture: "+str(output))


def pipeline_fixture():
    """Exercise all asset pathways on artificial archives, never on formal results."""
    import analyze as analysis
    from test_analysis import AnalysisFixture
    AnalysisFixture.setUpClass()
    try:
        root = AnalysisFixture.root
        builder = AssetBuilder(root)
        for phase in PHASES:
            _, aggregate, _ = analysis.load_phase(root, phase, True)
            destination = root / "analysis" / "results" / phase
            destination.mkdir(parents=True, exist_ok=True)
            aggregate.to_csv(destination / "instance_metrics.csv", index=False)
            if phase != "main":
                comparators = ["TS-JS:tail-only", "TS-JS:no-residual", "TS-JS:single-chain"] if phase == "ablation" else ["GA", "ALNS", "CB-TS"]
                effects = [{"Metric": "WaitCVaR", "N": n, "CV": cv, "Rho": .5 if phase == "correlated" else 0., "Comparator": method, "estimate": .02, "ci_low": .01, "ci_high": .03, "p_holm": .04} for method in comparators for cv in ((.2,) if phase == "correlated" else (.1,.2)) for n in (0,96,192)]
                pd.DataFrame(effects).to_csv(destination / "secondary_comparisons.csv", index=False)
        (root / "analysis/results/main/acceptance.json").write_text(json.dumps({"strict_complete": True, "optimization_plans": 2400, "replay_rows": 4800, "instances": 120}), encoding="utf-8")
        configs = root / "reproducibility/configs"
        selected = [{"Method": method, "Id": method+"_fixture", "Population": 32, "MutationProbability": .35, "RemovalFraction": .08, "Reaction": .2, "RepairTrials": 6, "InitialTemperature": .05, "Pool": 128, "Shortlist": 24, "Tenure": 7, "GuidedProbability": .8} for method in METHODS]
        (configs / "selected.json").write_text(json.dumps(selected), encoding="utf-8")
        (configs / "timing.json").write_text(json.dumps({96: 10, 192: 20}), encoding="utf-8")
        exact = root / "reports/exact"
        exact.mkdir(parents=True)
        pd.DataFrame([{"N": n, "Index": i, "Candidates": 1000, "EventFeasible": 100, "PriorityRepresentable": 50, "AllConstraintsFeasible": 2, "FullRisk": 1., "PriorityRisk": 1.} for n in (4,5,6) for i in (1,2)]).to_csv(exact / "exact_summary.csv", index=False)
        for phase in ("main", "timing"):
            for path in (root / "reproducibility/results" / phase / "runs").glob("*.json"):
                run = json.loads(path.read_text(encoding="utf-8"))
                run.update({"Work": int(run["Limit"]*.98), "Seconds": 3.5, "TimeLimit": 10 if phase == "timing" else 0, "Evaluations": 100, "StopReason": "fixture"})
                run["Evaluation"]["Risk"] = run["ReferenceCmax"]*.10
                run["Checkpoints"] = [{"Fraction": fraction, "Work": int(run["Limit"]*fraction), "Seconds": fraction*3.5, "Risk": run["ReferenceCmax"]*(.2-fraction*.05)} for fraction in (.25,.5)]
                if phase == "main" and run["Method"] == "GA":
                    run["Work"] = int(run["Limit"]*.4)
                    run["Checkpoints"] = run["Checkpoints"][:1]
                path.write_text(json.dumps(run), encoding="utf-8")
        replay_path = root / "reproducibility/results/main/replay_plan.csv"
        replay = pd.read_csv(replay_path)
        for metric, difference in (("WaitCVaR", .02), ("CmaxCVaR", .03)):
            for prefix in (250,500):
                replay[metric+"First"+str(prefix)] = replay[metric]+replay.ReferenceCmax*difference*(250/prefix)
        replay.to_csv(replay_path, index=False)
        frames = builder.require_complete()
        builder.metadata();builder.auxiliary_tables();builder.endpoint_archive(frames)
        main_runs, timing_runs = builder.archived_runs("main"), builder.archived_runs("timing")
        builder.convergence(main_runs, fixture=True);builder.runtimes(main_runs,timing_runs);builder.monte_carlo_stability();builder.manifest()
        convergence = pd.read_csv(builder.output / "convergence_summary.csv")
        require(np.allclose(convergence.loc[(convergence.Method == "GA") & (convergence.Checkpoint == "half"), "ActualWorkFraction"], .4), "Early termination must preserve actual work")
        require(convergence.loc[(convergence.Method == "GA") & (convergence.Checkpoint == "half"), "CarriedSeeds"].eq(150).all(), "Early-termination provenance")
        mc = pd.read_csv(builder.output / "monte_carlo_prefix_summary.csv")
        expected = mc.Metric.map({"WaitCVaR": .02, "CmaxCVaR": .03}) * 250/mc.Prefix
        require(np.allclose(mc.MeanAbsoluteDifferenceOverCref, expected) and np.allclose(mc.MaximumInstanceMeanAbsoluteDifferenceOverCref, expected), "Monte Carlo absolute-difference aggregation")
        archive = pd.read_csv(builder.output / "si_all_endpoints.csv")
        require(set(archive.Metric) == set(ENDPOINTS) and len(archive) == 2016, "Complete endpoint cells")
        manifest = json.loads((builder.output / "manifest.json").read_text(encoding="utf-8"))
        require(all(digest(root/path) == sha for path,sha in manifest["Sources"].items()), "Source hash trace")
        require(all(digest(builder.output/path) == sha for path,sha in manifest["Outputs"].items()), "Output hash trace")
        result = {"MainPlans": len(main_runs), "TimingPlans": len(timing_runs), "EndpointCells": len(archive), "MonteCarloCells": len(mc), "SourceHashes": len(manifest["Sources"]), "OutputHashes": len(manifest["Outputs"])}
        builder.manifest(True)
        metadata_manifest = json.loads((builder.output / "manifest.json").read_text(encoding="utf-8"))
        require(len(metadata_manifest["Outputs"]) == 6, "Metadata-only manifest excludes stale numerical assets")
        return result
    finally:
        AnalysisFixture.tearDownClass()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--metadata-only", action="store_true", help="Only configurations, exact audit and timing budgets; no formal outcomes")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    if args.self_test:
        self_test(root / "build" / "paper_assets_fixture");return
    builder = AssetBuilder(root)
    if args.metadata_only:
        builder.metadata();builder.manifest(True)
    else:
        frames = builder.require_complete()
        builder.metadata();builder.auxiliary_tables();builder.endpoint_archive(frames)
        main_runs, timing_runs = builder.archived_runs("main"), builder.archived_runs("timing")
        builder.convergence(main_runs);builder.runtimes(main_runs, timing_runs);builder.monte_carlo_stability();builder.manifest()
    print("Traced paper assets written to "+str(builder.output))


if __name__ == "__main__":
    main()
