"""Optional local launcher; a standard pip-installed environment also works.

Usage: python analysis/run_analysis.py paper_assets --root ROOT
"""
import argparse
from pathlib import Path
import runpy
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("script", choices=("analyze", "package_audit", "paper_assets", "test_analysis"))
    args, remaining = parser.parse_known_args()
    directory = Path(__file__).resolve().parent
    dependencies = directory.parent / "build" / "python_deps"
    if dependencies.is_dir():
        sys.path.append(str(dependencies))
    sys.path.insert(0, str(directory))
    sys.argv = [str(directory / (args.script+".py"))] + remaining
    runpy.run_path(sys.argv[0], run_name="__main__")


if __name__ == "__main__":
    main()
