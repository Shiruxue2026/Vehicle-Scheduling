"""Independent archive audit and traceable manuscript numbers.

No hypothesis selection or optimization is performed here. The event interpreter
does not import the C# kernel or the statistical analysis implementation.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict, deque
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import re

SIZES = (24, 48, 96, 192)
METHODS = ("GA", "ALNS", "CB-TS", "TS-JS")
MASK = (1 << 64) - 1
MAX_ERROR = 0.0


def require(condition, message):
    if not condition:
        raise ValueError(message)


def close(actual, expected, message, tolerance=2e-8):
    global MAX_ERROR
    require(math.isfinite(actual) and math.isfinite(expected), message + ": nonfinite")
    MAX_ERROR = max(MAX_ERROR, abs(actual - expected))
    require(abs(actual-expected) <= tolerance * max(1., abs(expected)), f"{message}: {actual!r} != {expected!r}")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seed(name):
    return int.from_bytes(hashlib.sha256(("tailrisk-v3|"+name).encode()).digest()[:4], "little") & 0x7fffffff


def mix(value):
    value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & MASK
    value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & MASK
    return value ^ (value >> 31)


def uniform(key):
    return ((mix(key) >> 11) + .5) / 9007199254740992.


def normal(key):
    return math.sqrt(-2*math.log(uniform(key))) * math.cos(2*math.pi*uniform(key ^ 0x9e3779b97f4a7c15))


def cvar(values, beta=.95):
    values = sorted(values, reverse=True)
    require(values and 0 <= beta < 1, "CVaR domain")
    mass = len(values)*(1-beta)
    whole = int(math.floor(mass))
    total = sum(values[:whole])
    if whole < len(values):
        total += (mass-whole)*values[whole]
    return total/mass


def p95(values):
    ordered = sorted(values)
    return ordered[max(0, math.ceil(.95*len(ordered))-1)]


def schedule_key(schedule):
    return "|".join(";".join(",".join(map(str, chain)) for chain in schedule[layer]) for layer in ("Q", "A", "Y"))


class Interpreter:
    def __init__(self, instance, schedule):
        self.ins, self.schedule = instance, schedule
        self.n = n = instance["N"]
        self.source = 10*n
        self.outgoing = [[] for _ in range(10*n+1)]
        self.nominal = {}
        self.indegree = [0]*(10*n+1)
        tasks = instance["Tasks"]
        predecessors = {}
        vehicle = {}
        for layer, count in (("Q", instance["Qn"]), ("A", instance["An"]), ("Y", instance["Yn"])):
            chains = schedule[layer]
            require(len(chains) == count and all(chains), "Resource counts/nonemptiness")
            require(Counter(task for chain in chains for task in chain) == Counter(range(n)), "Each task must occur once per layer")
            previous = [-1]*n
            for resource, chain in enumerate(chains):
                for position, task in enumerate(chain):
                    if layer != "A":
                        require(tasks[task][layer] == resource, "Fixed crane assignment")
                    else:
                        vehicle[task] = resource
                    previous[task] = chain[position-1] if position else -1
            predecessors[layer] = previous
        zero = 5*n+n*n+instance["An"]*n
        for task in range(n):
            base = 10*task
            pq, pa, py = (predecessors[layer][task] for layer in ("Q", "A", "Y"))
            self.arc(self.source if pq < 0 else 10*pq+4, base, zero, 0.)
            self.arc(base, base+1, task, tasks[task]["PQ"])
            index = 5*n+n*n+vehicle[task]*n+task if pa < 0 else 5*n+pa*n+task
            journey = self.initial(vehicle[task], task) if pa < 0 else self.empty(pa, task)
            self.arc(self.source if pa < 0 else 10*pa+8, base+2, index, journey)
            self.arc(base+1, base+3, zero, 0.);self.arc(base+2, base+3, zero, 0.)
            self.arc(base+3, base+4, n+task, tasks[task]["HQ"])
            loaded = (instance["Depth"] + abs(instance["Qx"][tasks[task]["Q"]]-instance["Yx"][tasks[task]["Y"]]))/instance["LoadedSpeed"]
            self.arc(base+4, base+5, 4*n+task, loaded)
            self.arc(self.source if py < 0 else 10*py+9, base+6, zero, 0.)
            self.arc(base+5, base+7, zero, 0.);self.arc(base+6, base+7, zero, 0.)
            self.arc(base+7, base+8, 3*n+task, tasks[task]["HY"])
            self.arc(base+8, base+9, 2*n+task, tasks[task]["PY"])
        degree = self.indegree.copy()
        ready = deque(i for i, value in enumerate(degree) if not value)
        self.order = []
        while ready:
            vertex = ready.popleft();self.order.append(vertex)
            for child, _ in self.outgoing[vertex]:
                degree[child] -= 1
                if degree[child] == 0:
                    ready.append(child)
        require(len(self.order) == len(degree), "Cyclic event graph")

    def initial(self, vehicle, task):
        return abs(self.ins["Ax"][vehicle]-self.ins["Qx"][self.ins["Tasks"][task]["Q"]])/self.ins["EmptySpeed"]

    def empty(self, previous, task):
        return (self.ins["Depth"] + abs(self.ins["Yx"][self.ins["Tasks"][previous]["Y"]]-self.ins["Qx"][self.ins["Tasks"][task]["Q"]]))/self.ins["EmptySpeed"]

    def empty_total(self):
        return sum(self.initial(vehicle, chain[0]) + sum(self.empty(previous, task) for previous, task in zip(chain, chain[1:])) for vehicle, chain in enumerate(self.schedule["A"]))

    def arc(self, source, target, index, value):
        self.outgoing[source].append((target, index));self.indegree[target] += 1
        if index in self.nominal:
            close(self.nominal[index], value, "Repeated duration-index definition")
        self.nominal[index] = value

    def forward(self, cv=0., scenario_seed=0, scenario=0, rho=0.):
        frame = self.nominal
        if cv:
            sigma = math.sqrt(math.log(1+cv*cv))
            basis = (((scenario_seed & 0xffffffff)*0x9e3779b97f4a7c15) & MASK) ^ ((((scenario+1) & 0xffffffff)*0xd1b54a32d192ed03) & MASK)
            common = normal(basis ^ 0x94d049bb133111eb)
            shared, local = math.sqrt(rho), math.sqrt(1-rho)
            frame = {index: value*math.exp(-.5*sigma*sigma + sigma*(shared*common + local*normal((basis+(index+1)*0x632be59bd9b4e019) & MASK))) if value else 0. for index, value in self.nominal.items()}
        times = [0.]*(self.source+1)
        for vertex in self.order:
            for child, index in self.outgoing[vertex]:
                times[child] = max(times[child], times[vertex]+frame[index])
        return times

    def values(self, times):
        q = [max(0., times[10*i+3]-times[10*i+2]) for i in range(self.n)]
        y = [max(0., times[10*i+7]-times[10*i+5]) for i in range(self.n)]
        return [a+b for a, b in zip(q, y)], max(times[10*i+9] for i in range(self.n))

    def metrics(self, times):
        n = self.n
        qgap = [times[10*i+2]-times[10*i+1] for i in range(n)]
        ygap = [times[10*i+5]-times[10*i+6] for i in range(n)]
        qw, yw = [[max(0., -x) for x in gap] for gap in (qgap, ygap)]
        qcw, ycw = [[max(0., x) for x in gap] for gap in (qgap, ygap)]
        waits = [q+y for q, y in zip(qw, yw)]
        makespan = max(times[10*i+9] for i in range(n))
        metrics = {"Cmax": makespan, "WaitMean": sum(waits)/n, "WaitP95": p95(waits)}
        for prefix, values in (("QAgvWait", qw), ("YAgvWait", yw), ("QCraneWait", qcw), ("YCraneWait", ycw)):
            metrics[prefix+"Mean"] = sum(values)/n;metrics[prefix+"P95"] = p95(values)
        qintervals = [(times[10*i+2], times[10*i+3]) for i in range(n) if qw[i] > 0]
        yintervals = [(times[10*i+5], times[10*i+7]) for i in range(n) if yw[i] > 0]
        for prefix, intervals in (("Q", qintervals), ("Y", yintervals), ("Both", qintervals+yintervals)):
            # Integrate over distinct endpoints using midpoint occupancy.
            knots = sorted({0., makespan, *(x for interval in intervals for x in interval)})
            histogram = defaultdict(float)
            for left, right in zip(knots, knots[1:]):
                midpoint = (left+right)/2
                count = sum(start <= midpoint < end for start, end in intervals)
                histogram[count] += right-left
            area = sum(count*duration for count, duration in histogram.items())
            close(area, sum(end-start for start, end in intervals), "Queue-area waiting identity")
            cumulative = 0.;quantile = 0
            for count in sorted(histogram):
                cumulative += histogram[count]
                if cumulative+1e-10 >= .95*makespan:
                    quantile = count;break
            metrics[prefix+"OccupancyMean"] = area/makespan
            metrics[prefix+"OccupancyP95"] = quantile
            metrics[prefix+"OccupancyMax"] = max(histogram, default=0)
        metrics["PhaseMean"] = (sum(map(abs, qgap))+sum(map(abs, ygap)))/(2*n)
        variation = sum(abs(gap[a]-gap[b]) for layer, gap in (("Q", qgap), ("Y", ygap)) for chain in self.schedule[layer] for a, b in zip(chain, chain[1:]))
        metrics["GTVMean"] = variation/(2*n-self.ins["Qn"]-self.ins["Yn"])
        return metrics


def expected_ids(phase):
    sizes, count = (SIZES, 30) if phase == "main" else ((96, 192), 10)
    return {f"test_N{n}_I{i:02}" for n in sizes for i in range(1, count+1)}


def archive_audit(root, phase, full_replay=False, raw_scenarios=3):
    require(phase in {"main", "ablation", "timing", "correlated"}, "Audit only explicitly completed formal phases")
    results = root / "reproducibility" / "results"
    folder = results / phase
    rows = read_csv(folder / "replay_plan.csv")
    expected_rows = {"main": 4800, "ablation": 600, "timing": 800, "correlated": 400}[phase]
    require(len(rows) == expected_rows, f"{phase}: expected {expected_rows} newly archived replay rows")
    require({row["InstanceId"] for row in rows} == expected_ids(phase), "Frozen instance set mismatch")
    selected = {item["Method"]: item["Id"] for item in read_json(root / "reproducibility" / "configs" / "selected.json")}
    keys = [(row["InstanceId"], row["Method"], row["ConfigId"], int(row["Seed"]), float(row["CV"]), float(row["Rho"])) for row in rows]
    require(len(set(keys)) == len(keys), "Duplicate plan-condition key")
    plan_keys = {key[:4] for key in keys}
    run_folder = results / ("main" if phase == "correlated" else phase) / "runs"
    runs = {}
    for path in sorted(run_folder.glob("*.json")):
        run = read_json(path)
        key = (run["InstanceId"], run["Method"], run["ConfigId"], run["Seed"])
        if phase == "correlated" and key not in plan_keys:
            continue
        require(key not in runs, "Duplicate archived plan")
        runs[key] = (run, path)
    require(set(runs) == plan_keys, "Run/replay plan set mismatch")
    for row in rows:
        key = (row["InstanceId"], row["Method"], row["ConfigId"], int(row["Seed"]))
        run = runs[key][0]
        require(row["ScheduleId"] == run["ScheduleId"], "Replay row references a different schedule")
        for field, expected_value in [("NominalCmax", run["Evaluation"]["NomCmax"]), ("Empty", run["Evaluation"]["Empty"]), ("ReferenceCmax", run["ReferenceCmax"]), ("ReferenceEmpty", run["ReferenceEmpty"])]:
            close(float(row[field]), expected_value, "Run/replay archived metadata "+field)
    expected_run_count = {"main": 2400, "ablation": 300, "timing": 400, "correlated": 400}[phase]
    require(len(runs) == expected_run_count, "Wrong optimization plan count")
    conditions = ((.2, .5),) if phase == "correlated" else ((.1, 0.), (.2, 0.))
    labels = [("TS-JS", "TS-JS_"+variant) for variant in ("tail-only", "no-residual", "single-chain")] if phase == "ablation" else list(selected.items())
    expected = {(instance, method, config, seed(f"algorithm|{instance}|{k}"), cv, rho) for instance in expected_ids(phase) for method, config in labels for k in range(1, 6) for cv, rho in conditions}
    require(set(keys) == expected, "Frozen method/configuration/seed/CV/rho cells mismatch")
    require(all(row["Phase"] == phase and int(row["Scenarios"]) == 1000 for row in rows), "Wrong replay phase/scenario count")
    instances, references = {}, {}
    for instance_id in expected_ids(phase):
        instance = read_json(root / "reproducibility" / "data" / "test" / (instance_id+".json"))
        require(instance["Id"] == instance_id and instance["Split"] == "test", "Instance metadata")
        require(instance["Seed"] == seed(f"instance|test|{instance['N']}|{int(instance_id[-2:])}"), "Instance generation seed")
        instances[instance_id] = instance
        reference = read_json(root / "reproducibility" / "data" / "test" / (instance_id+"_reference.json"))
        require(reference["InstanceId"] == instance_id, "Reference instance ID")
        independent_reference = Interpreter(instance, reference["Schedule"])
        _, reference_completion = independent_reference.values(independent_reference.forward())
        close(reference_completion, reference["Cmax"], "Independent efficiency reference completion")
        close(independent_reference.empty_total(), reference["Empty"], "Independent efficiency reference empty travel")
        references[instance_id] = (reference, independent_reference)
    nominal_checked = 0
    chosen = {}
    for key, (run, path) in runs.items():
        instance = instances[run["InstanceId"]]
        interpreter = Interpreter(instance, run["Schedule"])
        reference = references[run["InstanceId"]][0]
        close(run["ReferenceCmax"], reference["Cmax"], "Shared reference makespan")
        close(run["ReferenceEmpty"], reference["Empty"], "Shared reference empty travel")
        actual_hash = hashlib.sha256(schedule_key(run["Schedule"]).encode()).hexdigest()[:16]
        require(actual_hash == run["ScheduleId"], "Archived schedule hash does not match actual chains")
        require(run["Evaluation"]["Complete"] and run["Evaluation"]["Feasible"], "Incomplete/infeasible final plan")
        require(0 <= run["Work"] <= run["Limit"], "Archived work overflow")
        require(run["TrainingScenarios"] == 64, "Wrong training scenario count")
        require(run["Phase"] == ("main" if phase == "correlated" else phase), "Wrong source optimization phase")
        if phase == "main":
            require(run["Limit"] == 15*run["N"]*(32768+1024*run["N"]) and run["TimeLimit"] == 0, "Frozen primary budget")
        _, completion = interpreter.values(interpreter.forward())
        close(completion, run["Evaluation"]["NomCmax"], "Independent archived nominal completion")
        close(interpreter.empty_total(), run["Evaluation"]["Empty"], "Independent archived initial+empty travel")
        tolerance = 1e-9*max(1, run["ReferenceCmax"])
        require(completion <= 1.01*run["ReferenceCmax"]+tolerance, "Independent nominal constraint")
        require(interpreter.empty_total() <= 1.01*run["ReferenceEmpty"]+1e-9*max(1,run["ReferenceEmpty"]), "Independent empty constraint")
        require(run["Evaluation"]["CvarCmax"] <= run["ReferenceCvarCmax"]+.01*run["ReferenceCmax"]+tolerance, "Archived training-risk constraint")
        nominal_checked += 1
        if run["InstanceId"].endswith("_I01") and run["Seed"] == seed(f"algorithm|{run['InstanceId']}|1"):
            chosen[key] = (run, path, interpreter)
    training_decodings = 0
    reference_risks = {}
    for key, (run, path, interpreter) in chosen.items():
        waits, completions = [], []
        training_seed = seed("train|"+run["InstanceId"])
        for scenario in range(64):
            w, c = interpreter.values(interpreter.forward(.2, training_seed, scenario))
            waits.extend(w);completions.append(c);training_decodings += 1
        close(cvar(waits), run["Evaluation"]["Risk"], "Independent joint training waiting CVaR")
        close(cvar(completions), run["Evaluation"]["CvarCmax"], "Independent training completion CVaR")
        if run["InstanceId"] not in reference_risks:
            reference_interpreter = references[run["InstanceId"]][1]
            reference_risks[run["InstanceId"]] = cvar(reference_interpreter.values(reference_interpreter.forward(.2, training_seed, scenario))[1] for scenario in range(64))
        close(reference_risks[run["InstanceId"]], run["ReferenceCvarCmax"], "Independent common training risk cap")

    raw_checked = 0
    manifest_count = 0
    scenario_seeds = set()
    for instance_id in sorted(instances):
        for cv, rho in conditions:
            stem = f"{instance_id}_cv{cv*100:02.0f}_rho{rho*100:02.0f}"
            manifest = read_json(folder / "replay" / (stem+"_manifest.json"))
            scenario_seed = seed(f"replay|{instance_id}|cv{cv:.2f}|rho{rho:.2f}")
            require(manifest["Instance"] == instance_id and manifest["Phase"] == phase and manifest["Scenarios"] == 1000, "Replay manifest metadata")
            require(float(manifest["CV"]) == cv and float(manifest["Rho"]) == rho, "Replay manifest CV/rho")
            require(manifest["ScenarioSeed"] == scenario_seed, "Replay scenario seed")
            require(scenario_seed not in scenario_seeds, "Unexpected replay seed collision")
            scenario_seeds.add(scenario_seed)
            condition_rows = [row for row in rows if row["InstanceId"] == instance_id and float(row["CV"]) == cv and float(row["Rho"]) == rho]
            require(manifest["Plans"] == len(condition_rows) and manifest["Decodings"] == 1000*len(condition_rows), "Replay manifest count")
            raw_path = folder / "replay" / (stem+".csv.gz")
            require(sha256(raw_path) == manifest["RawSha256"], "Replay raw archive checksum")
            manifest_count += 1
            audit_plans = {path.stem: (run, interpreter) for run, path, interpreter in chosen.values() if run["InstanceId"] == instance_id}
            seen_raw = set()
            expected_plan_ids = {path.stem for run, path in runs.values() if run["InstanceId"] == instance_id}
            present = {plan: bytearray(1000) for plan in expected_plan_ids}
            raw_count = 0
            with gzip.open(raw_path, "rt", encoding="utf-8-sig", newline="") as stream:
                for row in csv.DictReader(stream):
                    scenario = int(row["Scenario"])
                    plan_id = row["PlanId"]
                    require(plan_id in present and 0 <= scenario < 1000, "Unexpected raw plan/scenario")
                    require(not present[plan_id][scenario], "Duplicate raw plan/scenario")
                    present[plan_id][scenario] = 1
                    raw_count += 1
                    if scenario >= raw_scenarios or plan_id not in audit_plans:
                        continue
                    raw_key = (row["PlanId"], scenario)
                    require(raw_key not in seen_raw, "Duplicate raw replay record")
                    seen_raw.add(raw_key)
                    run, interpreter = audit_plans[row["PlanId"]]
                    expected_metrics = interpreter.metrics(interpreter.forward(cv, scenario_seed, scenario, rho))
                    for metric, expected_value in expected_metrics.items():
                        close(float(row[metric]), expected_value, "Independent raw replay "+metric)
                    raw_checked += 1
            require(raw_count == len(expected_plan_ids)*1000 and all(all(mask) for mask in present.values()), "Raw scenario records are incomplete")
            require(len(seen_raw) == len(audit_plans)*raw_scenarios, "Missing selected raw replay records")
            if full_replay:
                for plan_id, (run, interpreter) in audit_plans.items():
                    waits, completions = [], []
                    for scenario in range(1000):
                        w, c = interpreter.values(interpreter.forward(cv, scenario_seed, scenario, rho));waits.extend(w);completions.append(c)
                    row = next(row for row in condition_rows if row["ScheduleId"] == run["ScheduleId"] and row["Method"] == run["Method"] and int(row["Seed"]) == run["Seed"] and row["ConfigId"] == run["ConfigId"])
                    close(cvar(waits), float(row["WaitCVaR"]), "Independent full held-out waiting CVaR")
                    close(cvar(completions), float(row["CmaxCVaR"]), "Independent full held-out completion CVaR")
                    close(sum(waits)/len(waits), float(row["WaitMean"]), "Independent full held-out waiting mean")
                    close(p95(waits), float(row["WaitP95"]), "Independent full held-out waiting P95")
                    close(sum(completions)/1000, float(row["CmaxMean"]), "Independent full held-out completion mean")
                    exceed = sum(c > 1.01*run["ReferenceCmax"]+1e-9*max(1,run["ReferenceCmax"]) for c in completions)/1000
                    close(exceed, float(row["CapExceedance"]), "Independent cap exceedance")
    require(not scenario_seeds.intersection(seed("train|"+instance) for instance in instances), "Training/test bank seed collision")
    return {"Phase": phase, "Status": "passed", "OptimizationPlansChecked": nominal_checked, "ReplayRows": len(rows), "SelectedPlans": len(chosen), "IndependentTrainingDecodings": training_decodings, "IndependentRawReplayDecodings": raw_checked, "Full1000ScenarioReplayOfSelectedPlans": full_replay, "ReplayManifestsAndChecksums": manifest_count, "MaximumAbsoluteDiscrepancy": MAX_ERROR}


def manuscript_numbers(root, write=False):
    result = root / "analysis" / "results" / "main"
    metadata_path = result / "acceptance.json"
    table_path = result / "primary_acceptance.csv"
    metadata, rows = read_json(metadata_path), read_csv(table_path)
    entries = []
    def add(name, source, selector, field, value, formatting):
        display = "not applicable" if value is None else format(value, formatting)
        entries.append({"Macro": name, "Source": str(source.relative_to(root)).replace("\\", "/"), "SourceSha256": sha256(source), "Selector": selector, "Field": field, "RawValue": value, "Format": formatting, "Display": display})
    add("MainPlans", metadata_path, {}, "optimization_plans", metadata["optimization_plans"], "d")
    add("MainInstances", metadata_path, {}, "instances", metadata["instances"], "d")
    add("MainReplayDecodings", metadata_path, {}, "replay_rows * 1000", metadata["replay_rows"]*1000, "d")
    add("WaitingRiskReductionPercent", metadata_path, {}, "relative_risk_reduction_percent", metadata["relative_risk_reduction_percent"], ".2f")
    for name, criterion, cv in [("WaitingFivePercent", "waiting_at_least_5_percent", .2), ("CompletionGuardCVTen", "completion_risk_noninferiority", .1), ("CompletionGuardCVTwenty", "completion_risk_noninferiority", .2), ("EmptyTravelGuard", "empty_travel_at_most_1_percent", 0.)]:
        selected = [row for row in rows if row["Criterion"] == criterion and float(row["CV"]) == cv]
        require(len(selected) == 1, "Ambiguous numerical macro source")
        for suffix, field in [("Estimate", "estimate"), ("Lower", "ci_low"), ("Upper", "ci_high")]:
            add(name+suffix, table_path, {"Criterion": criterion, "CV": cv}, field, float(selected[0][field]), ".5f")
    folder = root / "manuscript" / "generated"
    tex = "% Generated from archived analysis; definitions are traced in paper_numbers_trace.json.\n" + "\n".join("\\newcommand{\\"+item["Macro"]+"}{"+item["Display"]+"}" for item in entries) + "\n"
    if write:
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "paper_numbers.tex").write_text(tex, encoding="utf-8")
        (folder / "paper_numbers_trace.json").write_text(json.dumps(entries, indent=2) + "\n", encoding="utf-8")
    else:
        require((folder / "paper_numbers.tex").read_text(encoding="utf-8") == tex, "Manuscript numerical macros differ from archived analysis")
        require(read_json(folder / "paper_numbers_trace.json") == entries, "Manuscript numerical macro trace is stale")
    return {"Status": "passed", "Macros": len(entries), "Written": write}


def self_test(fixture=None):
    instance = {"N": 4, "Qn": 2, "An": 2, "Yn": 2, "Qx": [0.,10.], "Yx": [2.,8.], "Ax": [5.,7.], "Depth": 4., "LoadedSpeed": 1., "EmptySpeed": 1.5, "Tasks": [{"Id": i,"Q": i%2,"Y": i//2,"PQ":4+i,"HQ":1+i%2,"PY":6-i,"HY":1.} for i in range(4)]}
    schedule = {"Q": [[0,2],[1,3]],"A": [[0,2],[1,3]],"Y": [[0,1],[2,3]]}
    interpreter = Interpreter(instance, schedule)
    times = interpreter.forward()
    close(times[2], 5/1.5, "Known initial travel")
    close(times[12], 3/1.5, "Known second vehicle initial travel")
    close(cvar([0,1,2,3], .625), 8/3, "Fractional CVaR")
    metrics = interpreter.metrics(times)
    close(metrics["QAgvWaitMean"]+metrics["YAgvWaitMean"], metrics["WaitMean"], "Both interfaces counted")
    require(interpreter.forward(.2, 19, 0) == interpreter.forward(.2, 19, 0), "Perturbation determinism")
    invalid = {"Q": schedule["Q"], "A": [[],[0,1,2,3]], "Y": schedule["Y"]}
    try:
        Interpreter(instance, invalid)
    except ValueError:
        pass
    else:
        raise ValueError("Empty vehicle was accepted")
    if fixture is not None:
        exported = read_json(fixture)
        interpreter = Interpreter(exported["Instance"], exported["Schedule"])
        for case in exported["Cases"]:
            times = interpreter.forward(case["CV"], exported["ScenarioSeed"], case["Scenario"], case["Rho"])
            for actual, expected in zip(times, case["Times"]):
                close(actual, expected, "Independent Python/C# event and perturbation agreement")
            for metric, actual in interpreter.metrics(times).items():
                close(actual, case["Metrics"][metric], "Independent Python/C# operational metric "+metric)
    print(f"Independent package-audit interpreter self-test passed; maximum absolute discrepancy {MAX_ERROR:.3g}.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--phase", choices=["main", "ablation", "timing", "correlated"], default="main")
    parser.add_argument("--full-replay", action="store_true", help="Reconstruct all 1000 held-out scenarios for deterministic selected plans")
    parser.add_argument("--write-macros", action="store_true")
    parser.add_argument("--audit-macros", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--fixture", type=Path, help="Artificial C# export for cross-language self-test only")
    args = parser.parse_args()
    if args.self_test:
        self_test(args.fixture);return
    root = args.root.resolve()
    frozen = read_json(root / "reproducibility" / "configs" / "freeze.json")
    for relative, expected in frozen.items():
        require(sha256(root / relative) == expected, "Frozen source mismatch: "+relative)
    report = archive_audit(root, args.phase, args.full_replay)
    if args.write_macros or args.audit_macros:
        report["NumericalMacros"] = manuscript_numbers(root, args.write_macros)
    output = root / "reports" / ("package_audit_"+args.phase+".json")
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
