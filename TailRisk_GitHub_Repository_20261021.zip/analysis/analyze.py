"""Frozen v3 analysis. No optimization or data-dependent endpoint selection.

The independent unit is an instance. Each plan's pooled task/scenario CVaR is
computed by the replay engine; five plan values are averaged within an instance.
Main and auxiliary phases are never concatenated by this script.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np
import pandas as pd

SIZES = (24, 48, 96, 192)
METHODS = ("GA", "ALNS", "CB-TS", "TS-JS")
CVS = (0.10, 0.20)
BOOTSTRAPS = 20_000
BOOTSTRAP_SEED = 202610101
METRICS = (
    "WaitCVaR", "WaitMean", "WaitP95", "QAgvWaitMean", "QAgvWaitP95",
    "YAgvWaitMean", "YAgvWaitP95", "QCraneWaitMean", "QCraneWaitP95",
    "YCraneWaitMean", "YCraneWaitP95", "CmaxMean", "CmaxCVaR",
    "CapExceedance", "RelativeCmaxChange", "QOccupancyMean", "QOccupancyP95",
    "QOccupancyMax", "YOccupancyMean", "YOccupancyP95", "YOccupancyMax",
    "BothOccupancyMean", "BothOccupancyP95", "BothOccupancyMax", "PhaseMean", "GTVMean",
    "NominalCmax", "Empty",
)
PLAN_KEY = ["InstanceId", "Method", "ConfigId", "Seed"]


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def model_seed(name: str) -> int:
    return int.from_bytes(hashlib.sha256(("tailrisk-v3|" + name).encode()).digest()[:4], "little") & 0x7fffffff


def verify_freeze(root):
    manifest = json.loads((root / "reproducibility" / "configs" / "freeze.json").read_text(encoding="utf-8-sig"))
    for relative, expected in manifest.items():
        actual = hashlib.sha256((root / relative).read_bytes()).hexdigest()
        require(actual == expected, f"Frozen file changed: {relative}")


def signed_rank_exact(values):
    """Two-sided conditional signed-rank distribution, including tied ranks.

    Numerical differences are rounded to 12 decimal places before zero removal
    and ranking. Integer doubled average ranks make the subset-sum DP exact.
    Positive values favor the proposed method in all comparison tables.
    """
    d = np.round(np.asarray(values, dtype=float), 12)
    require(np.isfinite(d).all(), "Nonfinite signed-rank observations")
    d = d[d != 0]
    if not len(d):
        return {"n_nonzero": 0, "p_raw": 1.0, "rank_biserial": 0.0}
    order = np.argsort(np.abs(d), kind="stable")
    ranks2 = np.empty(len(d), dtype=np.int64)
    j = 0
    while j < len(d):
        k = j + 1
        while k < len(d) and abs(d[order[k]]) == abs(d[order[j]]):
            k += 1
        ranks2[order[j:k]] = j + 1 + k
        j = k
    total = int(ranks2.sum())
    plus = int(ranks2[d > 0].sum())
    counts = np.zeros(total + 1, dtype=object)
    counts[0] = 1
    reached = 0
    for rank in ranks2:
        rank = int(rank)
        previous = counts[:reached + 1].copy()
        counts[rank:rank + reached + 1] += previous
        reached += rank
    denominator = 1 << len(d)
    lower = sum(counts[:plus + 1])
    upper = sum(counts[plus:])
    p = min(1.0, float(2 * min(lower, upper) / denominator))
    return {"n_nonzero": len(d), "p_raw": p, "rank_biserial": (2 * plus - total) / total}


def holm(values):
    p = np.asarray(values, dtype=float)
    require(np.isfinite(p).all() and ((p >= 0) & (p <= 1)).all(), "Invalid p value")
    order = np.argsort(p, kind="stable")
    adjusted = np.empty(len(p))
    running = 0.0
    for k, index in enumerate(order):
        running = max(running, (len(p) - k) * p[index])
        adjusted[index] = min(1.0, running)
    return adjusted


class StratifiedBootstrap:
    def __init__(self, sizes, repeats=BOOTSTRAPS, seed=BOOTSTRAP_SEED):
        self.sizes = np.asarray(sizes)
        self.groups = tuple(sorted(np.unique(self.sizes)))
        require(len(self.groups) > 0, "Empty bootstrap sample")
        generator = np.random.default_rng(seed)
        self.weights = np.zeros((repeats, len(self.sizes)))
        self.point_weights = np.zeros(len(self.sizes))
        for group in self.groups:
            positions = np.flatnonzero(self.sizes == group)
            count = len(positions)
            draws = generator.integers(0, count, size=(repeats, count))
            frequencies = np.zeros((repeats, count), dtype=np.uint16)
            np.add.at(frequencies, (np.arange(repeats)[:, None], draws), 1)
            self.weights[:, positions] = frequencies / (len(self.groups) * count)
            self.point_weights[positions] = 1 / (len(self.groups) * count)

    def estimate(self, values):
        x = np.asarray(values, dtype=float)
        require(x.shape == self.point_weights.shape and np.isfinite(x).all(), "Bootstrap dimension/value mismatch")
        mean = float(self.point_weights @ x)
        lower, upper = np.quantile(self.weights @ x, [0.025, 0.975])
        return {"estimate": mean, "ci_low": float(lower), "ci_high": float(upper)}


def load_phase(root: Path, phase: str, strict: bool):
    folder = root / "reproducibility" / "results" / phase
    frame = pd.read_csv(folder / "replay_plan.csv")
    frame["SourcePhase"] = "main" if phase == "correlated" else phase
    if phase == "ablation":
        # Reuse the same full-method plans; this does not add independent units.
        baseline = pd.read_csv(root / "reproducibility" / "results" / "main" / "replay_plan.csv")
        baseline = baseline[baseline.InstanceId.isin(frame.InstanceId.unique()) & baseline.Method.eq("TS-JS")].copy()
        require(not baseline.empty, "Full TS-JS ablation reference is missing")
        baseline["SourcePhase"] = "main"
        baseline["Phase"] = "ablation"
        frame = pd.concat([frame, baseline], ignore_index=True)
    required = set(PLAN_KEY + ["N", "Phase", "ScheduleId", "CV", "Rho", "Scenarios", "ReferenceCmax", "ReferenceEmpty"] + list(METRICS))
    require(required <= set(frame.columns), f"Missing columns: {sorted(required - set(frame.columns))}")
    require(not frame.empty and frame["Phase"].eq(phase).all(), "Mixed/empty analysis phase")
    require(not frame[list(required)].isna().any().any(), "Missing replay fields")
    numeric = ["CV", "Rho", "Scenarios", "ReferenceCmax", "ReferenceEmpty"] + list(METRICS)
    require(np.isfinite(frame[numeric].to_numpy(dtype=float)).all(), "Nonfinite replay metrics")
    frame["CV"] = frame["CV"].round(8)
    frame["Rho"] = frame["Rho"].round(8)
    require(not frame.duplicated(PLAN_KEY + ["CV", "Rho"]).any(), "Duplicate plan/CV/rho rows")
    require(frame["ReferenceCmax"].gt(0).all(), "Nonpositive shared reference time")
    require(frame["CapExceedance"].between(0, 1).all(), "Cap exceedance must be a probability")
    require(np.allclose(frame.QAgvWaitMean + frame.YAgvWaitMean, frame.WaitMean, rtol=1e-9, atol=1e-9), "Interface waiting means do not sum to total")
    require((frame.WaitCVaR + 1e-8 >= frame.WaitMean).all(), "Waiting CVaR below mean")
    require((frame.CmaxCVaR + 1e-8 >= frame.CmaxMean).all(), "Completion CVaR below mean")
    require((frame.NominalCmax <= 1.01 * frame.ReferenceCmax + 1e-7).all(), "Nominal cap violated")
    require((frame.Empty <= 1.01 * frame.ReferenceEmpty + 1e-7).all(), "Empty-travel cap violated")
    for instance, group in frame.groupby("InstanceId", sort=True):
        for metric in ["N", "ReferenceCmax", "ReferenceEmpty"]:
            require(np.allclose(group[metric], group[metric].iloc[0], atol=1e-9, rtol=1e-9), f"Nonshared {metric}: {instance}")
    for key, group in frame.groupby(PLAN_KEY, sort=True):
        require(group.ScheduleId.nunique() == 1, f"Different schedules in replay rows: {key}")
        for metric in ["NominalCmax", "Empty"]:
            require(np.allclose(group[metric], group[metric].iloc[0], atol=1e-9, rtol=1e-9), f"Nominal metric changed across replay: {key}")

    runs = {}
    for source_phase in frame.SourcePhase.unique():
        keys = set(frame.loc[frame.SourcePhase.eq(source_phase), PLAN_KEY].itertuples(index=False, name=None))
        source_folder = root / "reproducibility" / "results" / source_phase / "runs"
        for path in sorted(source_folder.glob("*.json")):
            run = json.loads(path.read_text(encoding="utf-8-sig"))
            key = tuple(run[name] for name in PLAN_KEY)
            if source_phase == "main" and phase != "main" and key not in keys:
                continue
            require(key not in runs, f"Duplicate archived optimization result: {key}")
            require(run["Phase"] == source_phase, f"Wrong archived phase: {path.name}")
            require(run["Evaluation"]["Complete"] and run["Evaluation"]["Feasible"], f"Incomplete/infeasible returned plan: {key}")
            require(0 <= run["Work"] <= run["Limit"], f"Work budget exceeded: {key}")
            if phase == "main":
                require(run["TrainingScenarios"] == 64 and run["TimeLimit"] == 0, f"Incorrect main training/time budget: {key}")
                require(run["Limit"] == 15 * run["N"] * (32768 + 1024 * run["N"]), f"Incorrect frozen main work budget: {key}")
            runs[key] = run
    require(set(runs) == set(frame[PLAN_KEY].itertuples(index=False, name=None)), "Archived runs and replay plan sets differ")
    for row in frame.itertuples(index=False):
        key = tuple(getattr(row, name) for name in PLAN_KEY)
        run = runs[key]
        require(run["ScheduleId"] == row.ScheduleId, f"Replay schedule hash mismatch: {key}")
        require(run["N"] == row.N, f"Run/replay size mismatch: {key}")
        for actual, expected in [(row.NominalCmax, run["Evaluation"]["NomCmax"]), (row.Empty, run["Evaluation"]["Empty"]), (row.ReferenceCmax, run["ReferenceCmax"]), (row.ReferenceEmpty, run["ReferenceEmpty"])]:
            require(math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-9), f"Run/replay metadata mismatch: {key}")

    if phase == "main":
        require(set(frame.Method) == set(METHODS), "Unexpected main methods")
        require(frame.Rho.eq(0).all() and set(frame.CV) == set(CVS), "Unexpected main perturbation conditions")
        require(frame.groupby("Method").ConfigId.nunique().eq(1).all(), "More than one selected configuration per main method")
        require(frame.Scenarios.eq(1000).all(), "Main plans require 1000 scenarios per CV")
        if strict:
            expected_ids = {f"test_N{n}_I{i:02}" for n in SIZES for i in range(1, 31)}
            require(set(frame.InstanceId) == expected_ids, "Wrong/missing/extra frozen test instance")
            require(len(runs) == 2400 and len(frame) == 4800, "Main requires 2400 plans and 4800 replay rows")
            selected = json.loads((root / "reproducibility" / "configs" / "selected.json").read_text(encoding="utf-8-sig"))
            expected_configs = {item["Method"]: item["Id"] for item in selected}
            require(set(expected_configs) == set(METHODS), "Frozen method configurations are incomplete")
            for method, group in frame.groupby("Method"):
                require(set(group.ConfigId) == {expected_configs[method]}, f"Wrong frozen configuration: {method}")
        for instance, group in frame.groupby("InstanceId", sort=True):
            expected_seeds = {model_seed(f"algorithm|{instance}|{k}") for k in range(1, 6)}
            for (method, cv), subset in group.groupby(["Method", "CV"]):
                require(set(subset.Seed) == expected_seeds and len(subset) == 5, f"Missing/extra frozen seed: {instance}/{method}/{cv}")
            require(len(group) == 4 * 2 * 5, f"Missing method/CV cell: {instance}")
    if phase in {"main", "timing", "correlated"}:
        frame["Label"] = frame.Method
    elif phase == "ablation":
        frame["Label"] = np.where(frame.SourcePhase.eq("main"), "TS-JS:full", "TS-JS:" + frame.ConfigId.str.replace("TS-JS_", "", regex=False))
    else:
        frame["Label"] = frame.Method + ":" + frame.ConfigId
    if strict and phase in {"ablation", "timing", "correlated"}:
        expected_ids = {f"test_N{n}_I{i:02}" for n in (96, 192) for i in range(1, 11)}
        require(set(frame.InstanceId) == expected_ids, "Wrong/missing/extra auxiliary instances")
        require(len(runs) == 400 and len(frame) == (400 if phase == "correlated" else 800), "Incomplete auxiliary plans/conditions")
        require(frame.Scenarios.eq(1000).all(), "Auxiliary replay must use 1000 scenarios")
        require(set(frame.CV) == ({.20} if phase == "correlated" else set(CVS)), "Incorrect auxiliary CVs")
        require(frame.Rho.eq(.5 if phase == "correlated" else 0).all(), "Incorrect auxiliary correlation")
        expected_labels = {"TS-JS:full", "TS-JS:tail-only", "TS-JS:no-residual", "TS-JS:single-chain"} if phase == "ablation" else set(METHODS)
        require(set(frame.Label) == expected_labels, "Wrong auxiliary method/configuration labels")
        if phase in {"timing", "correlated"}:
            selected = json.loads((root / "reproducibility" / "configs" / "selected.json").read_text(encoding="utf-8-sig"))
            expected_configs = {item["Method"]: item["Id"] for item in selected}
            require(set(expected_configs) == set(METHODS), "Frozen auxiliary configurations are incomplete")
            for method, group in frame.groupby("Method"):
                require(set(group.ConfigId) == {expected_configs[method]}, f"Wrong frozen auxiliary configuration: {method}")
        for (instance, label, cv), group in frame.groupby(["InstanceId", "Label", "CV"]):
            require(set(group.Seed) == {model_seed(f"algorithm|{instance}|{k}") for k in range(1, 6)} and len(group) == 5, f"Incorrect auxiliary seeds: {instance}/{label}/{cv}")
        expected_cells = 4 if phase == "correlated" else 8
        require(frame.groupby("InstanceId").size().eq(5 * expected_cells).all(), "Missing auxiliary method/CV cell")
    fields = ["N", "InstanceId", "Label", "CV", "Rho"]
    aggregate = frame.groupby(fields, sort=True, as_index=False)[["ReferenceCmax", "ReferenceEmpty"] + list(METRICS)].mean()
    aggregate["SearchSeeds"] = frame.groupby(fields, sort=True).size().to_numpy()
    require(frame.groupby(fields).SourcePhase.nunique().eq(1).all(), "Mixed source within an instance/method cell")
    aggregate["SourcePhase"] = frame.groupby(fields, sort=True).SourcePhase.first().to_numpy()
    return frame, aggregate, runs


def paired(aggregate, comparator, proposed, cv, rho=0.0, size=None):
    selected = aggregate[(aggregate.CV == cv) & (aggregate.Rho == rho)]
    if size is not None:
        selected = selected[selected.N == size]
    left = selected[selected.Label == comparator].set_index(["N", "InstanceId"]).sort_index()
    right = selected[selected.Label == proposed].set_index(["N", "InstanceId"]).sort_index()
    require(len(left) > 0 and left.index.equals(right.index), f"Unpaired analysis: {comparator}, {proposed}, CV={cv}, rho={rho}, N={size}")
    require(np.allclose(left.ReferenceCmax, right.ReferenceCmax, atol=1e-9, rtol=1e-9), "Nonshared pair reference")
    return left, right, StratifiedBootstrap(left.index.get_level_values("N"))


def main_acceptance(aggregate):
    rows = []
    left, right, bootstrap = paired(aggregate, "ALNS", "TS-JS", .20)
    reference = left.ReferenceCmax.to_numpy()
    delta = (left.WaitCVaR.to_numpy() - right.WaitCVaR.to_numpy()) / reference
    delta5 = (.95 * left.WaitCVaR.to_numpy() - right.WaitCVaR.to_numpy()) / reference
    row = {"Criterion": "waiting_at_least_5_percent", "CV": .20, "Contrast": "(0.95 ALNS - TS-JS) / Cref", "Threshold": 0.0, "Direction": "lower_bound_above", **bootstrap.estimate(delta5), **signed_rank_exact(delta)}
    row["Pass"] = row["ci_low"] > 0
    rows.append(row)
    baseline_mean = float(bootstrap.point_weights @ (left.WaitCVaR.to_numpy() / reference))
    proposed_mean = float(bootstrap.point_weights @ (right.WaitCVaR.to_numpy() / reference))
    percent = 100 * (baseline_mean - proposed_mean) / baseline_mean if baseline_mean > 0 else None
    for cv in CVS:
        left, right, bootstrap = paired(aggregate, "ALNS", "TS-JS", cv)
        contrast = (right.CmaxCVaR.to_numpy() - left.CmaxCVaR.to_numpy()) / left.ReferenceCmax.to_numpy()
        row = {"Criterion": "completion_risk_noninferiority", "CV": cv, "Contrast": "(TS-JS - ALNS) / Cref", "Threshold": .01, "Direction": "upper_bound_below", **bootstrap.estimate(contrast)}
        row["Pass"] = row["ci_high"] < .01
        rows.append(row)
    left, right, bootstrap = paired(aggregate, "ALNS", "TS-JS", .20)
    contrast = (right.Empty.to_numpy() - 1.01 * left.Empty.to_numpy()) / left.ReferenceCmax.to_numpy()
    row = {"Criterion": "empty_travel_at_most_1_percent", "CV": 0, "Contrast": "(TS-JS - 1.01 ALNS) / Cref", "Threshold": 0.0, "Direction": "upper_bound_below", **bootstrap.estimate(contrast)}
    row["Pass"] = row["ci_high"] < 0
    rows.append(row)
    acceptance = pd.DataFrame(rows)
    metadata = {"primary_comparison": "TS-JS versus ALNS at CV 0.20", "bootstrap": BOOTSTRAPS, "bootstrap_seed": BOOTSTRAP_SEED, "interval": "two-sided 95% percentile, instance-paired, size-stratified", "weighting": "equal weight to each size, equal weight to each instance within size", "relative_risk_reduction_percent": percent, "ordinary_difference": StratifiedBootstrap(left.index.get_level_values("N")).estimate(delta), "operational_acceptance_pass": bool(acceptance.Pass.all()), "claim": "All statistical acceptance criteria passed." if acceptance.Pass.all() else "The predefined operational acceptance criteria were not all met.", "note": "Intervals are pointwise. Acceptance is an intersection of all criteria; no endpoint may substitute for a failed criterion. The signed-rank p value is for a zero ordinary difference, not the 5% acceptance contrast."}
    return acceptance, metadata


def comparisons(aggregate, phase, reference_label=None):
    rows = []
    labels = tuple(sorted(aggregate.Label.unique()))
    proposed = "TS-JS" if phase in {"main", "timing", "correlated"} else "TS-JS:full" if phase == "ablation" else reference_label
    if not proposed:
        return pd.DataFrame()
    require(proposed in labels, "Reference label absent from auxiliary phase")
    for cv, rho in aggregate[["CV", "Rho"]].drop_duplicates().itertuples(index=False, name=None):
        for comparator in labels:
            if comparator == proposed:
                continue
            for size in [None] + sorted(aggregate.N.unique().tolist()):
                left, right, bootstrap = paired(aggregate, comparator, proposed, cv, rho, size)
                scale = left.ReferenceCmax.to_numpy()
                for metric in METRICS:
                    # Main sole primary test is recorded with the acceptance table.
                    if phase == "main" and metric == "WaitCVaR" and comparator == "ALNS" and cv == .20 and rho == 0 and size is None:
                        continue
                    raw = left[metric].to_numpy() - right[metric].to_numpy()
                    value = raw / scale if metric in {"WaitCVaR", "CmaxCVaR", "Empty", "NominalCmax"} else raw
                    scope = "overall" if size is None else "size_specific"
                    family = f"{phase}/{scope}/{metric}"
                    rows.append({"Family": family, "Metric": metric, "Comparator": comparator, "Proposed": proposed, "N": 0 if size is None else size, "CV": cv, "Rho": rho, "Instances": len(raw), "NormalizedByCref": metric in {"WaitCVaR", "CmaxCVaR", "Empty", "NominalCmax"}, **bootstrap.estimate(value), **signed_rank_exact(value)})
    result = pd.DataFrame(rows)
    if not result.empty:
        result["p_holm"] = result.groupby("Family", sort=False).p_raw.transform(lambda values: holm(values.to_numpy()))
        result["FamilyTests"] = result.groupby("Family").p_raw.transform("size")
    return result


def tex_escape(value):
    return str(value).replace("\\", r"\textbackslash{}").replace("_", r"\_").replace("%", r"\%")


def write_assets(root, phase, aggregate, acceptance=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42, "ps.fonttype": 42, "savefig.dpi": 300})
    target = root / "manuscript" / "generated" / phase
    target.mkdir(parents=True, exist_ok=True)
    summary = aggregate.groupby(["N", "Label", "CV", "Rho"], as_index=False)[list(METRICS)].mean()
    summary.to_csv(target / "operational_summary.csv", index=False, encoding="utf-8-sig")
    for cv, rho in summary[["CV", "Rho"]].drop_duplicates().itertuples(index=False, name=None):
        table = summary[(summary.CV == cv) & (summary.Rho == rho)].sort_values(["N", "Label"])
        text = [r"\begin{tabular}{rlrrrrr}", r"\toprule", r"$N$ & Method & Wait CVaR & Yard wait P95 & $C_{\max}$ CVaR & Empty & Exceedance (\%) \\", r"\midrule"]
        for row in table.itertuples(index=False):
            text.append(f"{row.N} & {tex_escape(row.Label)} & {row.WaitCVaR:.3f} & {row.YAgvWaitP95:.3f} & {row.CmaxCVaR:.3f} & {row.Empty:.3f} & {100*row.CapExceedance:.2f} " + r"\\")
        text += [r"\bottomrule", r"\end{tabular}"]
        (target / f"operational_cv{cv:.2f}_rho{rho:.2f}.tex").write_text("\n".join(text) + "\n", encoding="utf-8")
    if phase != "main":
        return
    fig, axes = plt.subplots(1, 2, figsize=(7.1, 3.0), sharey=False, constrained_layout=True)
    colors = {"GA": "#7A7D82", "ALNS": "#0072B2", "CB-TS": "#D55E00", "TS-JS": "#009E73"}
    for axis, cv in zip(axes, CVS):
        for method in METHODS:
            means, lows, highs = [], [], []
            for n in SIZES:
                group = aggregate[(aggregate.CV == cv) & (aggregate.Rho == 0) & (aggregate.N == n) & (aggregate.Label == method)].sort_values("InstanceId")
                estimate = StratifiedBootstrap(np.repeat(n, len(group))).estimate(group.WaitCVaR.to_numpy())
                means.append(estimate["estimate"]);lows.append(estimate["ci_low"]);highs.append(estimate["ci_high"])
            x = np.arange(len(SIZES)) + (METHODS.index(method) - 1.5) * .06
            axis.errorbar(x, means, yerr=[np.maximum(0, np.asarray(means)-lows), np.maximum(0, np.asarray(highs)-means)], color=colors[method], marker="o", markersize=3, linewidth=1, capsize=2, label=method)
        axis.set_xticks(range(len(SIZES)), SIZES);axis.set_xlabel("Tasks");axis.set_title(f"Duration CV = {cv:.2f}")
        axis.set_ylabel("Total AGV waiting CVaR95");axis.grid(axis="y", alpha=.18)
    axes[0].legend(frameon=False, fontsize=8)
    for extension in ["pdf", "png"]:
        fig.savefig(target / f"waiting_risk_by_size.{extension}", bbox_inches="tight")
    plt.close(fig)
    if acceptance is not None:
        labels, means, lows, highs = [], [], [], []
        for row in acceptance.itertuples(index=False):
            if row.Direction == "lower_bound_above":
                estimate, low, high = row.estimate-row.Threshold, row.ci_low-row.Threshold, row.ci_high-row.Threshold
            else:
                estimate, low, high = row.Threshold-row.estimate, row.Threshold-row.ci_high, row.Threshold-row.ci_low
            labels.append({"waiting_at_least_5_percent": "Waiting reduction: 5% threshold", "completion_risk_noninferiority": f"Completion risk: CV {row.CV:.2f}", "empty_travel_at_most_1_percent": "Empty travel: 1% margin"}[row.Criterion])
            means.append(100*estimate);lows.append(100*low);highs.append(100*high)
        fig, axis = plt.subplots(figsize=(6.8, 2.8), constrained_layout=True)
        axis.axvline(0, color="black", linewidth=.7)
        axis.errorbar(means, range(4), xerr=[np.maximum(0, np.asarray(means)-lows), np.maximum(0, np.asarray(highs)-means)], fmt="o", color="#0072B2", capsize=3)
        axis.set_yticks(range(4), labels);axis.invert_yaxis();axis.set_xlabel("Acceptance margin (% of common reference makespan)")
        axis.grid(axis="x", alpha=.18)
        for extension in ["pdf", "png"]:
            fig.savefig(target / f"acceptance_margins.{extension}", bbox_inches="tight")
        plt.close(fig)
        text = [r"\begin{tabular}{lrrrr}", r"\toprule", r"Criterion & CV & Estimate & 95\% CI & Pass \\", r"\midrule"]
        short = {"waiting_at_least_5_percent": r"Waiting: $\Delta_5$", "completion_risk_noninferiority": "Completion-risk increase", "empty_travel_at_most_1_percent": "Empty-travel contrast"}
        for row in acceptance.itertuples(index=False):
            text.append(f"{short[row.Criterion]} & {row.CV:.2f} & {row.estimate:.5f} & [{row.ci_low:.5f}, {row.ci_high:.5f}] & {'Yes' if row.Pass else 'No'} " + r"\\")
        text += [r"\bottomrule", r"\end{tabular}"]
        (target / "primary_acceptance.tex").write_text("\n".join(text) + "\n", encoding="utf-8")


def self_test():
    require(model_seed("bootstrap") == int.from_bytes(hashlib.sha256(b"tailrisk-v3|bootstrap").digest()[:4], "little") & 0x7fffffff, "C# seed translation")
    require(np.allclose(holm([.01, .04, .03]), [.03, .06, .06]), "Holm known case")
    require(signed_rank_exact([0, 0])["p_raw"] == 1, "All-zero signed ranks")
    for values in [[1, 2, 3], [1, -1, 2, -2], [0, 1, 1, -2], [1, 1, 1], [-3, 1, 2, 2, -4]]:
        data = np.asarray(values, dtype=float);data = data[data != 0]
        absolute = np.abs(data)
        ranks = np.asarray([1 + np.sum(absolute < x) + (np.sum(absolute == x)-1)/2 for x in absolute])
        observed = abs(np.sum(ranks * np.sign(data)))
        count = sum(abs(np.dot(ranks, signs)) >= observed - 1e-12 for signs in itertools.product([-1, 1], repeat=len(data)))
        require(math.isclose(signed_rank_exact(values)["p_raw"], count / 2**len(data)), "Tied-rank DP versus exhaustive signs")
    bootstrap = StratifiedBootstrap([24, 24, 48], repeats=1000)
    require(math.isclose(bootstrap.estimate([2, 2, 4])["estimate"], 3), "Equal size weights")
    require(np.allclose(bootstrap.weights.sum(axis=1), 1), "Bootstrap weight sum")
    # An instance with a zero comparator remains in the linear 5% contrast.
    comparator, proposed, reference = np.array([0., 10.]), np.array([0., 9.]), np.array([20., 20.])
    contrast = (.95 * comparator - proposed) / reference
    require(np.isfinite(contrast).all() and math.isclose(contrast.mean(), .0125), "Zero baseline linear contrast")
    print("Self-tests passed: exact tied-rank DP, Holm, stratified bootstrap, seed translation and zero-baseline contrast.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--phase", default="main")
    parser.add_argument("--strict-complete", action="store_true")
    parser.add_argument("--reference-label", help="Auxiliary proposed/full configuration label, Method:ConfigId")
    parser.add_argument("--no-assets", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test();return
    if args.phase == "main":
        require(args.strict_complete, "Confirmatory main analysis requires --strict-complete; incomplete test results must not be inspected.")
    root = args.root.resolve()
    if args.phase in {"main", "ablation", "timing", "correlated"}:
        verify_freeze(root)
    frame, aggregate, runs = load_phase(root, args.phase, args.strict_complete)
    output = root / "analysis" / "results" / args.phase
    output.mkdir(parents=True, exist_ok=True)
    aggregate.to_csv(output / "instance_metrics.csv", index=False, encoding="utf-8-sig")
    aggregate.groupby(["N", "Label", "CV", "Rho"], as_index=False)[list(METRICS)].mean().to_csv(output / "summary.csv", index=False, encoding="utf-8-sig")
    acceptance = None
    if args.phase == "main":
        acceptance, metadata = main_acceptance(aggregate)
        metadata.update({"optimization_plans": len(runs), "replay_rows": len(frame), "instances": frame.InstanceId.nunique(), "strict_complete": args.strict_complete})
        acceptance.to_csv(output / "primary_acceptance.csv", index=False, encoding="utf-8-sig")
        (output / "acceptance.json").write_text(json.dumps(metadata, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    secondary = comparisons(aggregate, args.phase, args.reference_label)
    if not secondary.empty:
        secondary.to_csv(output / "secondary_comparisons.csv", index=False, encoding="utf-8-sig")
        secondary.groupby("Family", as_index=False).agg(Tests=("p_raw", "size")).to_csv(output / "multiplicity_families.csv", index=False)
    if not args.no_assets:
        write_assets(root, args.phase, aggregate, acceptance)
    print(f"Analysis complete: phase={args.phase}; {len(runs)} plans; {len(frame)} replay rows. Outputs: {output}")


if __name__ == "__main__":
    main()
