"""End-to-end analysis checks on explicitly artificial fixture data only."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pandas as pd

import analyze as analysis


class AnalysisFixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory(prefix="tailrisk-analysis-fixture-")
        cls.root = Path(cls.temporary.name)
        cls.rows = []
        cls.runs = []
        selected = [{"Method": method, "Id": method + "_fixture"} for method in analysis.METHODS]
        configs = cls.root / "reproducibility" / "configs"
        configs.mkdir(parents=True)
        (configs / "selected.json").write_text(json.dumps(selected), encoding="utf-8")
        for n in analysis.SIZES:
            for i in range(1, 31):
                instance = f"test_N{n}_I{i:02}"
                reference = float(n + 50)
                for method in analysis.METHODS:
                    for k in range(1, 6):
                        seed = analysis.model_seed(f"algorithm|{instance}|{k}")
                        run = {"InstanceId": instance, "N": n, "Phase": "main", "Method": method, "ConfigId": method + "_fixture", "Seed": seed, "ScheduleId": f"FAKE-{instance}-{method}-{k}", "Work": 100, "Limit": 15*n*(32768+1024*n), "TimeLimit": 0, "TrainingScenarios": 64, "ReferenceCmax": reference, "ReferenceEmpty": reference/2, "Evaluation": {"Complete": True, "Feasible": True, "NomCmax": reference, "Empty": reference/2}}
                        cls.runs.append(run)
                        for cv in analysis.CVS:
                            risk = (10 + i*.01 + k*.05 + n*.005 + cv) * {"GA": 1.2, "ALNS": 1., "CB-TS": .95, "TS-JS": .9}[method]
                            row = {name: 0. for name in analysis.METRICS}
                            row.update({key: run[key] for key in analysis.PLAN_KEY + ["N", "Phase", "ScheduleId", "ReferenceCmax", "ReferenceEmpty"]})
                            row.update({"CV": cv, "Rho": 0., "Scenarios": 1000, "NominalCmax": reference, "Empty": reference/2, "WaitCVaR": risk, "WaitMean": risk/2, "WaitP95": risk*.8, "QAgvWaitMean": risk*.2, "YAgvWaitMean": risk*.3, "YAgvWaitP95": risk*.6, "CmaxMean": reference*1.02, "CmaxCVaR": reference*(1.05 + (.002 if method == "TS-JS" else 0)), "CapExceedance": .8, "RelativeCmaxChange": 2.})
                            cls.rows.append(row)
        cls.save("main", cls.runs, cls.rows)
        subset = lambda item: item["N"] >= 96 and int(item["InstanceId"][-2:]) <= 10
        large_runs = [item for item in cls.runs if subset(item)]
        large_rows = [item for item in cls.rows if subset(item)]
        timing_runs = [dict(item, Phase="timing") for item in large_runs]
        timing_rows = [dict(item, Phase="timing") for item in large_rows]
        cls.save("timing", timing_runs, timing_rows)
        correlated = [dict(item, Phase="correlated", Rho=.5) for item in large_rows if item["CV"] == .2]
        cls.save("correlated", [], correlated)
        ablation_runs, ablation_rows = [], []
        for variant in ["tail-only", "no-residual", "single-chain"]:
            for item in large_runs:
                if item["Method"] == "TS-JS":
                    ablation_runs.append(dict(item, Phase="ablation", ConfigId="TS-JS_"+variant))
            for item in large_rows:
                if item["Method"] == "TS-JS":
                    ablation_rows.append(dict(item, Phase="ablation", ConfigId="TS-JS_"+variant))
        cls.save("ablation", ablation_runs, ablation_rows)

    @classmethod
    def save(cls, phase, runs, rows):
        folder = cls.root / "reproducibility" / "results" / phase
        (folder / "runs").mkdir(parents=True, exist_ok=True)
        for index, run in enumerate(runs):
            (folder / "runs" / f"fixture_{index:04}.json").write_text(json.dumps(run), encoding="utf-8")
        pd.DataFrame(rows).to_csv(folder / "replay_plan.csv", index=False)

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def test_main_aggregation_and_acceptance(self):
        frame, aggregate, runs = analysis.load_phase(self.root, "main", True)
        self.assertEqual((len(frame), len(aggregate), len(runs)), (4800, 960, 2400))
        first = aggregate[(aggregate.InstanceId == "test_N24_I01") & (aggregate.Label == "ALNS") & (aggregate.CV == .2)].iloc[0]
        self.assertAlmostEqual(first.WaitCVaR, 10 + .01 + .15 + 24*.005 + .2)
        acceptance, metadata = analysis.main_acceptance(aggregate)
        self.assertTrue(acceptance.Pass.all())
        self.assertAlmostEqual(metadata["relative_risk_reduction_percent"], 10)
        completion = acceptance[acceptance.Criterion == "completion_risk_noninferiority"]
        self.assertTrue(np.allclose(completion.estimate, .002))

    def test_auxiliary_provenance(self):
        for phase, counts in [("ablation", (800, 400)), ("timing", (800, 400)), ("correlated", (400, 400))]:
            frame, aggregate, runs = analysis.load_phase(self.root, phase, True)
            self.assertEqual((len(frame), len(runs)), counts)
            if phase == "ablation":
                self.assertEqual(frame.SourcePhase.value_counts().to_dict(), {"ablation": 600, "main": 200})
                self.assertEqual(set(aggregate.loc[aggregate.Label.eq("TS-JS:full"), "SourcePhase"]), {"main"})
            if phase == "correlated":
                self.assertEqual(set(aggregate.SourcePhase), {"main"})

    def test_missing_and_duplicate_rejected(self):
        path = self.root / "reproducibility" / "results" / "main" / "replay_plan.csv"
        for invalid in [self.rows[:-1], self.rows + [self.rows[0]]]:
            pd.DataFrame(invalid).to_csv(path, index=False)
            with self.assertRaises(ValueError):
                analysis.load_phase(self.root, "main", True)
        pd.DataFrame(self.rows).to_csv(path, index=False)

    def test_wrong_aux_configuration_rejected(self):
        path = self.root / "reproducibility" / "results" / "timing" / "replay_plan.csv"
        original = path.read_bytes()
        frame = pd.read_csv(path)
        frame.loc[0, "ConfigId"] = "GA_unfrozen"
        frame.to_csv(path, index=False)
        with self.assertRaises(ValueError):
            analysis.load_phase(self.root, "timing", True)
        path.write_bytes(original)

    def test_secondary_family_sizes(self):
        _, aggregate, _ = analysis.load_phase(self.root, "main", True)
        # Three metrics are sufficient to exercise the family construction;
        # the production constant retains all 28 metrics.
        original = analysis.METRICS
        try:
            analysis.METRICS = ("WaitCVaR", "CmaxCVaR", "YAgvWaitP95")
            table = analysis.comparisons(aggregate, "main")
        finally:
            analysis.METRICS = original
        sizes = table.groupby("Family").size().to_dict()
        self.assertEqual(sizes["main/overall/WaitCVaR"], 5)
        self.assertEqual(sizes["main/overall/CmaxCVaR"], 6)
        self.assertEqual(sizes["main/size_specific/WaitCVaR"], 24)
        self.assertEqual(sizes["main/size_specific/YAgvWaitP95"], 24)
        self.assertTrue((table.p_holm >= table.p_raw).all())


if __name__ == "__main__":
    analysis.self_test()
    unittest.main()
