# Statistical analysis fixed before confirmation

The executable specification is `analysis/analyze.py`. No confirmation outcome was inspected while this specification was written. The source hash is included in the study freeze manifest.

## Independent unit and estimands

The independent unit is a generated instance. A plan's waiting CVaR95 is calculated from all tasks and all 1000 replay scenarios jointly, including zero waits. The quantity is total AGV waiting at both interfaces. It is not a sum of interface CVaRs and is not an average of scenario-wise CVaRs. Five search-seed plan values are averaged within each instance. Seeds and replay scenarios are repeated observations, not independent inferential units.

For instance i in size h, let A and T denote the seed-averaged ALNS and proposed waiting CVaRs, and let Cref be their shared positive reference makespan. The ordinary difference is (A - T)/Cref. The five-percent contrast is (0.95 A - T)/Cref. Each size receives weight 1/4; instances receive equal weight within a size. No individual baseline risk is used as a denominator. An instance whose ALNS risk is zero remains included.

The displayed relative reduction is one minus the ratio of the two overall reference-normalized means. It is undefined if the overall ALNS risk is zero. It is not the mean of per-instance percentage changes.

## Sole primary comparison and simultaneous acceptance requirements

The sole primary comparison is TS-JS versus ALNS at duration CV 0.20 and correlation rho 0. Acceptance requires all of the following:

1. The lower endpoint of the two-sided 95% interval for the five-percent waiting contrast is strictly above zero.
2. At CV 0.10 and 0.20 separately, the upper endpoint for `(CmaxCVaR_TS - CmaxCVaR_ALNS)/Cref` is strictly below 0.01.
3. The upper endpoint for `(Empty_TS - 1.01 Empty_ALNS)/Cref` is strictly below zero. Empty travel includes initial depot-to-quay travel; it is a nominal route quantity and is tested once.

The completion margin is 1% of the common reference makespan, not one percentage point of cap-exceedance probability. Cap-exceedance probability is reported separately. The 1% empty margin is a benchmark research tolerance, not a field-validated service standard.

Intervals use 20,000 paired instance bootstrap samples, with replacement within size, Python NumPy generator seed 202610101, and percentile endpoints 0.025 and 0.975. A sampled instance retains all methods and its already averaged search seeds. These are pointwise intervals. Acceptance is an intersection of criteria; no improvement may compensate for a failed criterion. Passing all criteria does not establish superiority over every comparator or at every size.

The separately reported exact signed-rank p value tests a zero ordinary difference, not the 5% margin. It cannot override a failed confidence-interval acceptance criterion. Ranks use absolute differences after rounding to 12 decimal places; zero differences are removed. Ties receive average ranks. Doubled integer ranks yield an exact subset-sum sign distribution, including ties. The rank-biserial sign is positive when the comparator has greater cost than the proposed method.

## Complete secondary families

The script reports all 28 listed metrics for every available predefined comparison, without filtering by sign or significance. Holm adjustment is applied independently within each `phase/scope/metric` family.

- Main, overall waiting CVaR: five comparisons, comprising the three comparators at both CVs except the sole primary comparison.
- Main, other overall metrics: six comparisons per metric.
- Main, size-specific: four sizes x two CVs x three comparators = 24 comparisons per metric. These are secondary; they do not replace the aggregate primary comparison.
- Ablation: full TS-JS versus the three variants, two CVs; six overall and twelve size-specific comparisons per metric.
- Timing: three comparators, two CVs; six overall and twelve size-specific comparisons per metric.
- Correlated replay: three comparators, CV 0.20 and rho 0.50; three overall and six size-specific comparisons per metric.

The four metrics WaitCVaR, CmaxCVaR, Empty and NominalCmax use Cref-normalized differences in comparison tables. Other differences retain their native units. CapExceedance is a probability; RelativeCmaxChange is already expressed in percent. Diagnostic phase/GTV comparisons do not establish operational benefits.

Waiting quantiles pool the task/scenario samples within each plan. Occupancy is different: the time-weighted mean, time-weighted P95 and maximum are computed separately on each scenario's interval [0, Cmax], and the 1000 scenario statistics are averaged. The reported occupancy P95 is not a pooled scenario/time quantile, and the reported maximum is not the largest queue observed across all scenarios.

## Data provenance and completeness

Main analysis refuses to run without `--strict-complete`. It verifies the 120 exact frozen instance IDs, four selected configurations, five hashed search seeds per instance/method, both CVs, rho 0, 1000 scenarios per condition, 2400 archived plans, and 4800 replay rows. It rejects missing values, duplicate keys, mismatched schedule IDs, changed nominal quantities across CVs, nonshared reference values, incomplete returned evaluations, budget violations, and frozen-source changes.

Auxiliary phases are analyzed separately. Ablation reuses the full TS-JS plans from the same 20 main instances and five seeds; these rows are marked SourcePhase=main. The 300 variant plans and 100 reused full plans yield 800 condition rows. Correlated replay links its 400 plans to the main archive and does not add independent plans. Timing contains 400 new runs and 800 condition rows. No auxiliary outcome is added to the primary sample.

## Technical completion versus research success

A complete, internally consistent archive and manuscript satisfy technical delivery requirements even when statistical acceptance fails. A failed criterion is reported directly. Neither a positive secondary test nor a favorable subset changes the sole primary conclusion. Confirmation outcomes are not used to retune the frozen algorithms.
