# Development changes

## Before development round r1: nested TS-JS neighborhoods

This change was made before any registered development round or unseen-test execution. A correctness smoke run on one synthetic validation instance (N=24, index=2; initial-schedule seed 20271019, training-bank seed 20271020; K=8 at CV=.20; search seed 20271021; 1,000,000 event-edge visits; pool=32, shortlist=8) showed that excluding useful single-chain moves could disadvantage the full solver. The reference in this smoke was an unoptimized initial schedule, not the shared reference used in the study.

The initial TS-JS implementation proposed predominantly two-chain moves. Its smoke risk was 25.412802, whereas the single-chain ablation obtained 16.364816. This observation prompted a structural correction: both guided and random proposal branches now sample 50% single-chain moves and 50% joint moves. The single-chain ablation replaces the joint share with single-chain proposals. The main neighborhood therefore includes the simpler moves instead of excluding them. GuidedProbability remains unchanged and controls guided versus random selection, independently of this 50/50 move mixture.

The full-candidate, complete-K-scenario evaluation rule is unchanged. No nominal-only feasibility screen was introduced. The initial smoke summaries also included GA 26.067403, ALNS 28.770290, CB-TS 24.562272, tail-only 24.991900, and no-residual 22.288324. These are six-decimal smoke summaries, not formal performance evidence.

After the neighborhood correction, the same smoke configuration produced GA 26.067403, ALNS 28.770290, CB-TS 24.562272, TS-JS 23.624062, tail-only 24.376476, no-residual 29.050271, and single-chain 16.364816. The single-chain variant remains best on this one smoke instance. No general superiority or mechanism benefit is inferred. Full post-change records are saved in `reports/solver_smoke_nested_neighborhood.json`.

Independent validation was rerun after the change and passed: 43 schedules, maximum event discrepancy zero; all four solvers passed independent final-metric, complete/feasible-plan, work-budget, and repeated-seed checks. All seven smoke configurations returned complete feasible plans within the work limit. No formal experiment or holdout data was run for this change.
