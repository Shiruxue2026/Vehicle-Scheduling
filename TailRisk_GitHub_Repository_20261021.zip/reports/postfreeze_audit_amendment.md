# Post-freeze archive-audit parsing amendment

Recorded UTC: 2026-10-10T03:40:19.906954+00:00.

## Discovery and scope

The issue was found by reading source during the ongoing frozen formal pipeline, before inspecting any formal performance outcomes. `Replay.cs` writes chunk manifests as `Dictionary<string,string>`. The frozen Python audit compared four string fields (`Scenarios`, `ScenarioSeed`, `Plans`, `Decodings`) directly with integers, causing valid archives to fail metadata validation. This is an archive-reader type incompatibility; it does not change generation, optimization, replay, measurement, statistical analysis, acceptance rules, selected configurations, or any stored numerical result.

The frozen `analysis/package_audit.py` and original `freeze.json` are unchanged. The complete amended copy is `analysis/package_audit_v1_1.py`. Its only changes are one strict integer-field parser and four calls replacing direct manifest-field access. It accepts JSON integers and ASCII signed-decimal integer strings; it rejects booleans, floating-point values, fractions, scientific notation, whitespace, and nonnumeric values. The existing equality checks still enforce the expected scenario seed/counts. Reversing exactly these five textual substitutions reproduces the original file byte for byte.

The amended file is intentionally outside the earlier freeze. Its main entry point still verifies every original frozen file, including the unchanged original audit. This amendment must be included in the final delivery checksums and cited as the audit version actually executed. Do not overwrite the original freeze, describe this new file as the original frozen version, or rerun numerical experiments because of this parsing repair.

## SHA-256 provenance

| File | SHA-256 |
|---|---|
| `analysis/package_audit.py` | `9e42546f731e4f2f69eddc6e82837edf014d757436fbfd7ddd44327281fd7faa` |
| `analysis/package_audit_v1_1.py` | `98d4e1d1469cb716c363f30113803271603f93ec0f812cd68cb63e7ead7d88dd` |
| `reproducibility/configs/freeze.json` | `8d1f58153e1fec73ed276e32460b2c5fa4ed439445626cc5646648ce395d42a2` |

The original audit hash was checked against its entry in the original freeze.

## Bounded verification actually performed

PASS: 12 field conversions from three existing development chunk manifests; seven valid artificial representations; 14 invalid artificial representations; unchanged original freeze-entry check; inverse byte-exact comparison. No formal replay file, ranking, metric row, or optimization outcome was read. No experiment, full replay, rendering, or statistical analysis was run.

Development metadata sources:

- `reproducibility/results/dev_r1_selection/replay/development_N192_I06_cv10_rho00_manifest.json`
- `reproducibility/results/dev_trainingK32/replay/development_N192_I06_cv20_rho00_manifest.json`
- `reproducibility/results/dev_trainingK128/replay/development_N192_I06_cv20_rho00_manifest.json`

## Invocation after every formal phase has completed

The frozen launcher does not expose this new script name. Invoke the amended script directly; do not modify the frozen launcher or original analysis scripts:

```powershell
$studyRoot = 'C:\TailRisk Verify\study'
$Python = Join-Path $studyRoot '.venv\Scripts\python.exe'
& $Python -X utf8 (Join-Path $studyRoot 'analysis\package_audit_v1_1.py') --self-test --fixture (Join-Path $studyRoot 'build\reproduced_validation\interpreter_fixture.json')
foreach ($phase in @('main','ablation','timing','correlated')) {
    $extra = if ($phase -eq 'main') { @('--write-macros') } else { @() }
    & $Python -X utf8 (Join-Path $studyRoot 'analysis\package_audit_v1_1.py') --root $studyRoot --phase $phase --full-replay @extra
    if ($LASTEXITCODE -ne 0) { throw ('Amended independent audit failed: ' + $phase) }
}
```

At discovery, `reproduce.ps1 -Mode analysis/full` invoked the frozen original via its launcher and would encounter the known parser error. The unfrozen wrapper has subsequently been updated by the root agent: its artificial fixture and archive-audit calls now invoke `analysis/package_audit_v1_1.py` directly through `$archiveAuditor`, while all analysis calls retain the frozen launcher. The root README now names the amended script and describes the amendment. This follow-up was verified by source inspection; no full pipeline was executed for that check. The `verify` mode's artificial fixture checks do not exercise the real chunk-manifest field issue. The new parser's development-metadata and negative-value tests above cover that issue.

## Complete minimal diff

```diff
--- analysis/package_audit.py (frozen original)
+++ analysis/package_audit_v1_1.py (audit-only amendment)
@@ -36,4 +36,10 @@
 def read_json(path):
     return json.loads(path.read_text(encoding="utf-8-sig"))
+
+
+def manifest_integer(manifest, field):
+    value = manifest[field]
+    require(type(value) is int or (isinstance(value, str) and re.fullmatch(r"[+-]?[0-9]+", value) is not None), "Replay manifest integer field: " + field)
+    return int(value)
 
 
@@ -314,11 +320,11 @@
             manifest = read_json(folder / "replay" / (stem+"_manifest.json"))
             scenario_seed = seed(f"replay|{instance_id}|cv{cv:.2f}|rho{rho:.2f}")
-            require(manifest["Instance"] == instance_id and manifest["Phase"] == phase and manifest["Scenarios"] == 1000, "Replay manifest metadata")
+            require(manifest["Instance"] == instance_id and manifest["Phase"] == phase and manifest_integer(manifest, "Scenarios") == 1000, "Replay manifest metadata")
             require(float(manifest["CV"]) == cv and float(manifest["Rho"]) == rho, "Replay manifest CV/rho")
-            require(manifest["ScenarioSeed"] == scenario_seed, "Replay scenario seed")
+            require(manifest_integer(manifest, "ScenarioSeed") == scenario_seed, "Replay scenario seed")
             require(scenario_seed not in scenario_seeds, "Unexpected replay seed collision")
             scenario_seeds.add(scenario_seed)
             condition_rows = [row for row in rows if row["InstanceId"] == instance_id and float(row["CV"]) == cv and float(row["Rho"]) == rho]
-            require(manifest["Plans"] == len(condition_rows) and manifest["Decodings"] == 1000*len(condition_rows), "Replay manifest count")
+            require(manifest_integer(manifest, "Plans") == len(condition_rows) and manifest_integer(manifest, "Decodings") == 1000*len(condition_rows), "Replay manifest count")
             raw_path = folder / "replay" / (stem+".csv.gz")
             require(sha256(raw_path) == manifest["RawSha256"], "Replay raw archive checksum")
```
