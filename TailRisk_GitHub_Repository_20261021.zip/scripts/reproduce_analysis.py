"""Recompute all four frozen formal analyses and their independent audits."""
import argparse
from pathlib import Path
import subprocess
import sys
from verify_data import verify

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    args=parser.parse_args();root=args.root.resolve()
    verify(root,True)
    for phase in ('main','ablation','timing','correlated'):
        subprocess.run([sys.executable,'-X','utf8',str(root/'analysis/run_analysis.py'),'analyze','--root',str(root),'--phase',phase,'--strict-complete'],check=True)
        subprocess.run([sys.executable,'-X','utf8',str(root/'analysis/package_audit_v1_1.py'),'--root',str(root),'--phase',phase,'--full-replay'],check=True)
    print('All frozen analyses and independent audits completed.')

if __name__=='__main__':main()
