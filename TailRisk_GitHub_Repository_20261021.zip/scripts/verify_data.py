"""Verify unchanged archived experiment files using Python's standard library."""
import argparse
import hashlib
import json
from pathlib import Path

def sha256(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            value.update(block)
    return value.hexdigest()

def verify(root, require_raw=False):
    manifest=json.loads((root/'DATA_MANIFEST.json').read_text(encoding='utf-8'))
    checked=0; missing_raw=0
    for relative, record in manifest['Files'].items():
        path=(root/relative).resolve()
        if not path.is_relative_to(root.resolve()):
            raise ValueError('Unsafe manifest path: '+relative)
        if not path.is_file():
            if record['Group']=='raw_replay' and not require_raw:
                missing_raw+=1; continue
            raise ValueError('Missing file: '+relative)
        if path.stat().st_size!=record['Bytes'] or sha256(path)!=record['Sha256']:
            raise ValueError('File checksum mismatch: '+relative)
        checked+=1
    freeze=json.loads((root/'reproducibility/configs/freeze.json').read_text(encoding='utf-8-sig'))
    for relative, expected in freeze.items():
        if sha256(root/relative)!=expected:
            raise ValueError('Original freeze mismatch: '+relative)
    result={'VerifiedFiles':checked,'RawReplayFilesNotInstalled':missing_raw,'OriginalFrozenFilesVerified':len(freeze),'Status':'passed'}
    print(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--require-raw',action='store_true')
    args=parser.parse_args()
    verify(args.root.resolve(),args.require_raw)
