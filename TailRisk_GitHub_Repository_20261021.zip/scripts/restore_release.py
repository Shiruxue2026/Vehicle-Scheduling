"""Restore the data release into this checkout, checking every member hash."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import zipfile
from verify_data import verify

def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive',type=Path)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    a=p.parse_args();root=a.root.resolve()
    expected=json.loads((root/'DATA_MANIFEST.json').read_text(encoding='utf-8'))['Files']
    with zipfile.ZipFile(a.archive) as archive:
        names=archive.namelist()
        if len(names)!=len(set(names)) or set(names)!=set(expected)|{'DATA_MANIFEST.json'}:
            raise ValueError('Release member list does not match this dataset version')
        embedded=json.loads(archive.read('DATA_MANIFEST.json'))
        if embedded['Files']!=expected:raise ValueError('Release manifest does not match checkout')
        for relative,record in expected.items():
            destination=(root/relative).resolve()
            if not destination.is_relative_to(root):raise ValueError('Unsafe archive path')
            if destination.is_file():
                if sha256(destination)==record['Sha256']:continue
                raise ValueError('Refusing to replace changed local file: '+relative)
            destination.parent.mkdir(parents=True,exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=destination.parent,prefix='restore-',delete=False) as temp:
                temporary=Path(temp.name)
                with archive.open(relative) as source:shutil.copyfileobj(source,temp)
            try:
                if temporary.stat().st_size!=record['Bytes'] or sha256(temporary)!=record['Sha256']:
                    raise ValueError('Release checksum mismatch: '+relative)
                temporary.replace(destination)
            finally:
                if temporary.exists():temporary.unlink()
    verify(root,True)

if __name__=='__main__':main()
