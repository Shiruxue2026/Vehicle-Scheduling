namespace TailRisk;

public sealed partial class SearchContext {
    public bool CanContinue=>Budget.Available();
    public static long MainBudget(int n)=>15L*n*(32768L+1024L*n);
    public static SearchContext Create(Instance ins,ScenarioBank bank,Schedule reference,long limit,double seconds=0,bool nominalOnly=false){
        var c=new SearchContext{Ins=ins,Bank=bank,Reference=reference.Clone(),EvaluateNominalOnly=nominalOnly};
        var graph=Kernel.Build(ins,reference,out _);if(graph==null)throw new ArgumentException("Invalid reference");
        c.ReferenceEval=c.Raw(reference,graph,false);c.ReferenceEval.Feasible=true;c.ReferenceEval.Violation=0;
        c.Budget=new(){Limit=limit,SecondsLimit=seconds,ProposalLimit=seconds>0?int.MaxValue:2000*ins.N};c.BestRisk=c.ReferenceEval.Risk;
        return c;
    }
    public Graph Build(Schedule s){
        if(!Budget.Available(24L*Ins.N))return null;
        var graph=Kernel.Build(Ins,s,out long visits);if(!Budget.Charge(visits))throw new InvalidOperationException("Graph preflight failed");
        if(graph!=null)ValidGraphs++;return graph;
    }
    public Evaluation Evaluate(Schedule s,bool trace=false){var g=Build(s);return g==null?null:Evaluate(s,g,trace);}
    public Evaluation Evaluate(Schedule s,Graph g,bool trace=false){
        long work=(long)g.EdgeCount*(EvaluateNominalOnly?1:Bank.Count+1);
        if(!Budget.Available(work))return null;
        Budget.Charge(work);var e=Raw(s,g,trace);Evaluations++;
        if(!EvaluateNominalOnly){
            double c=ReferenceEval.NomCmax,empty=ReferenceEval.Empty;
            e.Violation=Math.Max(0,e.NomCmax-1.01*c)/c+Math.Max(0,e.Empty-1.01*empty)/Math.Max(1,empty)+Math.Max(0,e.CvarCmax-ReferenceEval.CvarCmax-.01*c)/c;
            e.Feasible=e.NomCmax<=1.01*c+1e-9*Math.Max(1,c)
                && e.Empty<=1.01*empty+1e-9*Math.Max(1,empty)
                && e.CvarCmax<=ReferenceEval.CvarCmax+.01*c+1e-9*Math.Max(1,c);
        }
        if(e.Feasible)FeasibleEvaluations++;
        if(Budget.SecondsLimit>0&&Budget.Clock.Elapsed.TotalSeconds>Budget.SecondsLimit)return null;
        return e;
    }
    Evaluation Raw(Schedule s,Graph g,bool trace){
        var t=new double[g.Nodes];Kernel.Forward(g,Bank.Nominal,t);
        double nominal=Kernel.Cmax(g,t),empty=Kernel.Empty(Ins,s);
        if(EvaluateNominalOnly)return new(){Complete=true,Feasible=true,Risk=nominal,NomCmax=nominal,CvarCmax=nominal,Empty=empty,Violation=0,Graph=g,TaskTail=Enumerable.Range(0,Ins.N).Select(i=>Kernel.Wait(t,i)).ToArray()};
        int k=Bank.Count,n=Ins.N;if(k<=0)throw new ArgumentException("Nonempty training scenarios required");
        var waits=new double[k*n];var cs=new double[k];var times=trace?new double[k][]:null;
        for(int b=0;b<k;b++){Kernel.Forward(g,Bank.Frames[b],t);cs[b]=Kernel.Cmax(g,t);for(int i=0;i<n;i++)waits[b*n+i]=Kernel.Wait(t,i);if(trace)times[b]=(double[])t.Clone();}
        var weights=Kernel.TailWeights(waits);var contributions=new double[n];double risk=0;
        for(int p=0;p<waits.Length;p++){double z=weights[p]*waits[p];risk+=z;contributions[p%n]+=z;}
        return new(){Complete=true,Feasible=true,Risk=risk,CvarCmax=Kernel.Cvar(cs),NomCmax=nominal,Empty=empty,Violation=0,Graph=g,Times=times,WaitSamples=trace?waits:null,TaskTail=contributions};
    }
    public Sensitivity Differentiate(Evaluation e){
        if(e.Times==null||e.Times.Length!=Bank.Count||e.WaitSamples==null)throw new ArgumentException("Training trace required");
        int n=Ins.N,k=Bank.Count;var g=e.Graph;long cost=2L*g.EdgeCount*k;
        if(!Budget.Available(cost))return null;Budget.Charge(cost);
        var weights=Kernel.TailWeights(e.WaitSamples);
        var result=new Sensitivity{Lambda=new double[k][],TaskInfluence=new double[n],TaskTail=new double[n],TaskQTail=new double[n],TaskYTail=new double[n]};
        for(int b=0;b<k;b++){
            var t=e.Times[b];var frame=Bank.Frames[b];var lam=new double[g.Nodes];result.Lambda[b]=lam;
            for(int i=0;i<n;i++){int v=10*i;double w=weights[b*n+i],q=Math.Max(0,t[v+1]-t[v+2]),y=Math.Max(0,t[v+6]-t[v+5]);if(q>0){lam[v+1]+=w;lam[v+2]-=w;}if(y>0){lam[v+6]+=w;lam[v+5]-=w;}result.TaskQTail[i]+=w*q;result.TaskYTail[i]+=w*y;result.TaskTail[i]+=w*(q+y);}
            for(int p=g.Topo.Length-1;p>=0;p--){int v=g.Topo[p],u=g.P1[v];if(u<0)continue;int u2=g.P2[v];if(u2<0)lam[u]+=lam[v];else {double a=t[u]+frame[g.W1[v]],c=t[u2]+frame[g.W2[v]];if(a>c)lam[u]+=lam[v];else if(c>a)lam[u2]+=lam[v];else{lam[u]+=.5*lam[v];lam[u2]+=.5*lam[v];}}}
            for(int v=0;v<g.Source;v++){int u=g.P1[v],u2=g.P2[v];double duration=u<0?0:frame[g.W1[v]];if(u2>=0)duration=Math.Max(duration,frame[g.W2[v]]);result.TaskInfluence[v/10]+=Math.Abs(lam[v])*duration;}
        }
        return result;
    }
    public double ScoreCandidate(Graph candidate,Evaluation current,Sensitivity sens){
        Graph old=current.Graph;var changed=new List<int>();long cost=0;
        long scan=(long)old.EdgeCount+candidate.EdgeCount;
        if(!Budget.Available(scan))return double.PositiveInfinity;Budget.Charge(scan);
        for(int v=0;v<candidate.Source;v++)if(candidate.P1[v]!=old.P1[v]||candidate.P2[v]!=old.P2[v]||candidate.W1[v]!=old.W1[v]||candidate.W2[v]!=old.W2[v]){changed.Add(v);cost+=(candidate.P2[v]<0?1:2);}
        cost*=Bank.Count;
        if(!Budget.Available(cost))return double.PositiveInfinity;Budget.Charge(cost);
        double score=0;for(int b=0;b<Bank.Count;b++){var t=current.Times[b];var f=Bank.Frames[b];foreach(int v in changed){double next=t[candidate.P1[v]]+f[candidate.W1[v]];if(candidate.P2[v]>=0)next=Math.Max(next,t[candidate.P2[v]]+f[candidate.W2[v]]);score+=sens.Lambda[b][v]*(next-t[v]);}}
        return score;
    }
    public void RecordBest(Evaluation e){
        if(e!=null&&e.Complete&&e.Feasible)BestRisk=Math.Min(BestRisk,e.Risk);
        double[] marks={.25,.50,1};while(NextCheckpoint<marks.Length&&Budget.Used>=marks[NextCheckpoint]*Budget.Limit){Checkpoints.Add(new(){Fraction=marks[NextCheckpoint++],Risk=BestRisk,Work=Budget.Used,Seconds=Budget.Clock.Elapsed.TotalSeconds});}
    }
    public RunResult Finish(Schedule s,Evaluation e,string method,int seed,string configid){
        RecordBest(e);if(Checkpoints.Count==0||Checkpoints[^1].Work!=Budget.Used)Checkpoints.Add(new(){Fraction=Math.Min(1,(double)Budget.Used/Budget.Limit),Risk=e.Risk,Work=Budget.Used,Seconds=Budget.Clock.Elapsed.TotalSeconds});
        string reason=Budget.SecondsLimit>0&&Budget.Clock.Elapsed.TotalSeconds>=Budget.SecondsLimit?"time":Budget.Proposals>=Budget.ProposalLimit?"proposal-limit":"work";
        return new(){InstanceId=Ins.Id,N=Ins.N,Method=method,Seed=seed,ConfigId=configid,Schedule=s.Clone(),Evaluation=e,ScheduleId=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(s.Key()))).ToLowerInvariant()[..16],StopReason=reason,Work=Budget.Used,Limit=Budget.Limit,Seconds=Budget.Clock.Elapsed.TotalSeconds,TimeLimit=Budget.SecondsLimit,Proposals=Budget.Proposals,Evaluations=Evaluations,ValidGraphs=ValidGraphs,FeasibleEvaluations=FeasibleEvaluations,ReferenceCmax=ReferenceEval.NomCmax,ReferenceEmpty=ReferenceEval.Empty,ReferenceCvarCmax=ReferenceEval.CvarCmax,TrainingScenarios=Bank.Count,Checkpoints=Checkpoints};
    }
}
