using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
namespace TailRisk;

public sealed class IntegrityInput {
    public string InstanceId, InstancePath, InstanceHash, ReferencePath, ReferenceHash;
    public int N, TrainingSeed;
    public double ReferenceCmax, ReferenceEmpty, ReferenceCvarCmax;
}
public sealed class IntegrityRun {
    public string FileName, InstanceId, ConfigId, Method;
    public int Seed, SeedIndex;
    public long Limit;
    public double TimeLimit;
}
public sealed class RunSetSpecification {
    public int Schema=1, TrainingCount;
    public string Phase;
    public bool NominalOnly;
    public double TrainingCV=.20, TrainingRho=0;
    public SortedDictionary<string,string> NumericalCore=new(StringComparer.Ordinal);
    public List<SearchConfig> Configurations=new();
    public List<IntegrityInput> Inputs=new();
    public List<IntegrityRun> Runs=new();
}
public sealed class IntegritySession {
    public string Id, StartedUtc, AssemblyHash, Runtime, Architecture;
    public SortedDictionary<string,string> AllSource=new(StringComparer.Ordinal);
}
public sealed class RunSetManifest {
    public string CreatedUtc, SpecificationHash;
    public RunSetSpecification Specification;
    public IntegritySession FirstSession;
    [JsonIgnore] public string Root, DirectoryPath;
    [JsonIgnore] public IntegritySession Session;
    [JsonIgnore] public Dictionary<string,IntegrityRun> Expected;
    [JsonIgnore] public Dictionary<string,Instance> Instances;
    [JsonIgnore] public Dictionary<string,IntegrityInput> Inputs;
}
public sealed class IntegrityReceipt {
    public int Schema=1;
    public string SpecificationHash, FileHash, ScheduleHash, SessionId, AssemblyHash, SavedUtc;
}

/// <summary>
/// Exact run-set contracts for safe resumption. Numerical-core changes reject
/// resumption; reporting/CLI changes are retained as per-session provenance.
/// This is outside every method's optimization budget and never changes a plan.
/// </summary>
public static class RunIntegrity {
    static readonly string[] CoreFiles={"Contracts.cs","Model.cs","Kernel.cs","SearchContext.cs","Operations.cs","Solvers.cs","Moves.cs"};
    public static string HashFile(string path)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
    static string HashText(string text)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text))).ToLowerInvariant();
    public static string ScheduleHash(Schedule schedule)=>HashText(schedule.Key());
    static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException("Run integrity: "+message);}
    static string Relative(string root,string path)=>Path.GetRelativePath(root,path).Replace('\\','/');
    static string Full(string root,string relative)=>Path.GetFullPath(Path.Combine(root,relative));
    static bool Near(double a,double b)=>double.IsFinite(a)&&double.IsFinite(b)&&Math.Abs(a-b)<=1e-9*Math.Max(1,Math.Max(Math.Abs(a),Math.Abs(b)));
    static void SafeName(string value){Require(!string.IsNullOrWhiteSpace(value)&&value!="."&&value!=".."&&value.IndexOfAny(Path.GetInvalidFileNameChars())<0&&!value.Contains('/')&&!value.Contains('\\'),"unsafe identifier: "+value);}
    static SortedDictionary<string,string> Core(string root){
        var result=new SortedDictionary<string,string>(StringComparer.Ordinal);
        foreach(string name in CoreFiles){string path=Path.Combine(root,"reproducibility","src",name);result[Relative(root,path)]=HashFile(path);}
        return result;
    }
    static IntegritySession Session(string root){
        var s=new IntegritySession{Id=DateTime.UtcNow.ToString("yyyyMMddTHHmmssfffffff")+"_"+Guid.NewGuid().ToString("N"),StartedUtc=DateTime.UtcNow.ToString("O"),AssemblyHash=HashFile(typeof(RunIntegrity).Assembly.Location),Runtime=RuntimeInformation.FrameworkDescription,Architecture=RuntimeInformation.ProcessArchitecture.ToString()};
        foreach(string path in System.IO.Directory.GetFiles(Path.Combine(root,"reproducibility","src"),"*.cs").Order(StringComparer.Ordinal))s.AllSource[Relative(root,path)]=HashFile(path);
        string project=Path.Combine(root,"reproducibility","TailRisk.csproj");s.AllSource[Relative(root,project)]=HashFile(project);
        return s;
    }
    static void Attach(RunSetManifest manifest,string root){
        manifest.Root=Path.GetFullPath(root);manifest.DirectoryPath=Path.Combine(root,"reproducibility","results",manifest.Specification.Phase);
        manifest.Expected=manifest.Specification.Runs.ToDictionary(x=>x.FileName,StringComparer.Ordinal);
        manifest.Inputs=manifest.Specification.Inputs.ToDictionary(x=>x.InstanceId,StringComparer.Ordinal);
        manifest.Instances=manifest.Specification.Inputs.ToDictionary(x=>x.InstanceId,x=>JsonIO.Read<Instance>(Full(root,x.InstancePath)),StringComparer.Ordinal);
    }
    public static RunSetManifest EnsureRunSet(string root,string phase,IReadOnlyList<Instance> instances,IReadOnlyList<SearchConfig> configs,int seeds,double fraction=1,Dictionary<int,double> seconds=null,bool nominal=false,int trainingCount=64){
        SafeName(phase);Require(instances.Count>0&&configs.Count>0&&seeds>0&&trainingCount>0&&double.IsFinite(fraction)&&fraction>0,"empty or invalid run-set arguments");
        Require(instances.Select(x=>x.Id).Distinct().Count()==instances.Count,"duplicate instances");
        Require(configs.Select(x=>x.Id).Distinct().Count()==configs.Count,"duplicate configuration IDs");
        var spec=new RunSetSpecification{Phase=phase,TrainingCount=trainingCount,NominalOnly=nominal,NumericalCore=Core(root)};
        spec.Configurations=configs.OrderBy(x=>x.Id,StringComparer.Ordinal).Select(x=>JsonSerializer.Deserialize<SearchConfig>(JsonSerializer.Serialize(x,JsonIO.Compact),JsonIO.Options)).ToList();
        foreach(var cfg in spec.Configurations)SafeName(cfg.Id);
        foreach(var ins in instances.OrderBy(x=>x.Id,StringComparer.Ordinal)){
            SafeName(ins.Id);string inputPath=Path.Combine(root,"reproducibility","data",ins.Split,ins.Id+".json"),referencePath=Path.Combine(root,"reproducibility","data",ins.Split,ins.Id+"_reference.json");
            Require(File.Exists(inputPath)&&File.Exists(referencePath),"missing prepared input/reference for "+ins.Id);
            var disk=JsonIO.Read<Instance>(inputPath);Require(JsonSerializer.Serialize(ins,JsonIO.Compact)==JsonSerializer.Serialize(disk,JsonIO.Compact),"in-memory input differs from archive: "+ins.Id);
            var reference=JsonIO.Read<ReferenceRecord>(referencePath);Require(reference.InstanceId==ins.Id,"reference instance mismatch: "+ins.Id);
            var graph=Kernel.Build(ins,reference.Schedule,out _);Require(graph!=null,"invalid reference schedule: "+ins.Id);
            var nominalEval=Kernel.Nominal(ins,reference.Schedule,graph);Require(Near(nominalEval.NomCmax,reference.Cmax)&&Near(nominalEval.Empty,reference.Empty),"reference scalar mismatch: "+ins.Id);
            int trainingSeed=Model.Seed($"train|{ins.Id}");double cvar=reference.Cmax;
            if(!nominal){var bank=Model.MakeBank(ins,trainingCount,.2,trainingSeed);var times=new double[graph.Nodes];var cs=new double[trainingCount];for(int k=0;k<trainingCount;k++){Kernel.Forward(graph,bank.Frames[k],times);cs[k]=Kernel.Cmax(graph,times);}cvar=Kernel.Cvar(cs);}
            spec.Inputs.Add(new(){InstanceId=ins.Id,N=ins.N,InstancePath=Relative(root,inputPath),InstanceHash=HashFile(inputPath),ReferencePath=Relative(root,referencePath),ReferenceHash=HashFile(referencePath),TrainingSeed=trainingSeed,ReferenceCmax=reference.Cmax,ReferenceEmpty=reference.Empty,ReferenceCvarCmax=cvar});
            foreach(var cfg in spec.Configurations)for(int k=1;k<=seeds;k++){
                double duration=seconds?.GetValueOrDefault(ins.N)??0;Require(double.IsFinite(duration)&&duration>=0,"invalid time budget");
                // Timed confirmation has no practical work cap. The sentinel
                // leaves ample signed-integer headroom for safe additions.
                long limit=duration>0?long.MaxValue/4:checked((long)(SearchContext.MainBudget(ins.N)*fraction));Require(limit>0,"nonpositive work budget");
                spec.Runs.Add(new(){FileName=$"{ins.Id}_{cfg.Id}_S{k}.json",InstanceId=ins.Id,ConfigId=cfg.Id,Method=cfg.Method,Seed=Model.Seed($"algorithm|{ins.Id}|{k}"),SeedIndex=k,Limit=limit,TimeLimit=duration});
            }
        }
        string directory=Path.Combine(root,"reproducibility","results",phase),path=Path.Combine(directory,"runset_manifest.json"),fingerprint=HashText(JsonSerializer.Serialize(spec,JsonIO.Compact));
        var session=Session(root);RunSetManifest manifest;
        if(File.Exists(path)){
            manifest=JsonIO.Read<RunSetManifest>(path);
            Require(manifest.SpecificationHash==HashText(JsonSerializer.Serialize(manifest.Specification,JsonIO.Compact)),"modified manifest: "+phase);
            Require(manifest.SpecificationHash==fingerprint,"run-set/core/config/input/reference/seed/K/budget changed; use a new phase directory: "+phase);
        }else{
            string runs=Path.Combine(directory,"runs");Require(!System.IO.Directory.Exists(runs)||System.IO.Directory.GetFiles(runs,"*.json").Length==0,"unmanifested existing runs; explicitly archive before resumption: "+phase);
            manifest=new(){CreatedUtc=DateTime.UtcNow.ToString("O"),SpecificationHash=fingerprint,Specification=spec,FirstSession=session};JsonIO.Save(path,manifest);
        }
        Attach(manifest,root);manifest.Session=session;
        JsonIO.Save(Path.Combine(directory,"provenance","sessions",session.Id+".json"),session);
        return manifest;
    }
    public static RunSetManifest VerifyRunSet(string root,string phase,bool requireComplete=true){
        SafeName(phase);var manifest=JsonIO.Read<RunSetManifest>(Path.Combine(root,"reproducibility","results",phase,"runset_manifest.json"));
        Require(manifest.Specification.Phase==phase&&manifest.Specification.Schema==1,"manifest phase/schema mismatch");
        Require(manifest.SpecificationHash==HashText(JsonSerializer.Serialize(manifest.Specification,JsonIO.Compact)),"modified manifest: "+phase);
        Require(JsonSerializer.Serialize(manifest.Specification.NumericalCore,JsonIO.Compact)==JsonSerializer.Serialize(Core(root),JsonIO.Compact),"numerical core changed since optimization: "+phase);
        foreach(var item in manifest.Specification.Inputs){Require(HashFile(Full(root,item.InstancePath))==item.InstanceHash,"instance changed: "+item.InstanceId);Require(HashFile(Full(root,item.ReferencePath))==item.ReferenceHash,"reference changed: "+item.InstanceId);}
        Attach(manifest,root);if(requireComplete)CheckComplete(manifest);return manifest;
    }
    static IntegrityRun ValidateFields(RunSetManifest manifest,RunResult run,string path){
        string file=Path.GetFileName(path);Require(manifest.Expected.TryGetValue(file,out var expected),"unexpected run filename: "+file);
        string intended=Path.GetFullPath(Path.Combine(manifest.DirectoryPath,"runs",file));Require(Path.GetFullPath(path)==intended,"run outside its phase directory: "+path);
        var input=manifest.Inputs[expected.InstanceId];var ins=manifest.Instances[expected.InstanceId];
        Require(run.InstanceId==expected.InstanceId&&run.N==input.N&&run.ConfigId==expected.ConfigId&&run.Method==expected.Method&&run.Seed==expected.Seed&&run.Phase==manifest.Specification.Phase,"run identity mismatch: "+file);
        Require(run.Limit==expected.Limit&&run.Work>=0&&run.Work<=run.Limit&&Near(run.TimeLimit,expected.TimeLimit)&&run.TrainingScenarios==manifest.Specification.TrainingCount,"run budget/training mismatch: "+file);
        Require(double.IsFinite(run.Seconds)&&run.Seconds>=0&&run.Proposals>=0&&run.Evaluations>=0&&run.FeasibleEvaluations>=0&&run.FeasibleEvaluations<=run.Evaluations,"invalid run counters: "+file);
        Require(Near(run.ReferenceCmax,input.ReferenceCmax)&&Near(run.ReferenceEmpty,input.ReferenceEmpty)&&Near(run.ReferenceCvarCmax,input.ReferenceCvarCmax),"reference metric mismatch: "+file);
        var e=run.Evaluation;Require(e!=null&&e.Complete&&e.Feasible,"incomplete/infeasible returned incumbent: "+file);
        Require(new[]{e.Risk,e.CvarCmax,e.NomCmax,e.Empty,e.Violation}.All(x=>double.IsFinite(x)&&x>=0),"nonfinite/negative evaluation: "+file);
        var graph=Kernel.Build(ins,run.Schedule,out _);Require(graph!=null,"incomplete/cyclic/incompatible schedule: "+file);
        Require(run.ScheduleId==ScheduleHash(run.Schedule)[..16],"schedule ID mismatch: "+file);
        var nominal=Kernel.Nominal(ins,run.Schedule,graph);Require(Near(nominal.NomCmax,e.NomCmax)&&Near(nominal.Empty,e.Empty),"nominal schedule/evaluation mismatch: "+file);
        if(!manifest.Specification.NominalOnly){
            double tol=1e-9*Math.Max(1,input.ReferenceCmax);
            Require(e.NomCmax<=1.01*input.ReferenceCmax+tol&&e.Empty<=1.01*input.ReferenceEmpty+1e-9*Math.Max(1,input.ReferenceEmpty)&&e.CvarCmax<=input.ReferenceCvarCmax+.01*input.ReferenceCmax+tol,"reported feasible result violates a cap: "+file);
        }else Require(Near(e.Risk,e.NomCmax),"nominal-only objective mismatch: "+file);
        Require(run.Diagnostics!=null&&run.Diagnostics.Values.All(double.IsFinite)&&(!run.Diagnostics.TryGetValue("PartialEvaluations",out double partial)||partial==0),"invalid diagnostics/partial evaluations: "+file);
        Require(run.Checkpoints!=null&&run.Checkpoints.All(x=>x.Work>=0&&x.Work<=run.Work&&double.IsFinite(x.Risk)&&x.Risk>=0&&double.IsFinite(x.Fraction)&&x.Fraction>=0&&x.Fraction<=1),"invalid checkpoints: "+file);
        return expected;
    }
    static string ReceiptPath(RunSetManifest m,string path)=>Path.Combine(m.DirectoryPath,"provenance","runs",Path.GetFileName(path));
    public static void ValidateRun(RunSetManifest manifest,RunResult run,string path){
        ValidateFields(manifest,run,path);
        Require(File.Exists(path)&&File.Exists(ReceiptPath(manifest,path)),"run or provenance receipt missing: "+path);
        var receipt=JsonIO.Read<IntegrityReceipt>(ReceiptPath(manifest,path));
        Require(receipt.Schema==1&&receipt.SpecificationHash==manifest.SpecificationHash&&receipt.FileHash==HashFile(path)&&receipt.ScheduleHash==ScheduleHash(run.Schedule),"run receipt/hash mismatch: "+path);
        string sessionPath=Path.Combine(manifest.DirectoryPath,"provenance","sessions",receipt.SessionId+".json");
        Require(File.Exists(sessionPath),"run execution session missing: "+path);
        var session=JsonIO.Read<IntegritySession>(sessionPath);Require(session.AssemblyHash==receipt.AssemblyHash,"execution assembly provenance mismatch: "+path);
    }
    public static RunResult ValidateExistingRun(RunSetManifest manifest,string path){var run=JsonIO.Read<RunResult>(path);ValidateRun(manifest,run,path);return run;}
    public static void SaveCompletedRun(RunSetManifest manifest,RunResult run,string path){
        ValidateFields(manifest,run,path);Require(manifest.Session!=null,"saving requires an active EnsureRunSet session");
        Require(!File.Exists(path),"refusing to overwrite an archived run: "+path);
        // Receipt first, final run last: interruption cannot expose an accepted
        // result lacking the actual executing assembly/session provenance.
        string serialized=JsonSerializer.Serialize(run,JsonIO.Options);
        JsonIO.Save(ReceiptPath(manifest,path),new IntegrityReceipt{SpecificationHash=manifest.SpecificationHash,FileHash=HashText(serialized),ScheduleHash=ScheduleHash(run.Schedule),SessionId=manifest.Session.Id,AssemblyHash=manifest.Session.AssemblyHash,SavedUtc=DateTime.UtcNow.ToString("O")});
        JsonIO.Save(path,run);ValidateRun(manifest,run,path);
    }
    public static int CheckComplete(RunSetManifest manifest){
        string dir=Path.Combine(manifest.DirectoryPath,"runs");Require(System.IO.Directory.Exists(dir),"run directory missing");
        var actual=System.IO.Directory.GetFiles(dir,"*.json").Select(Path.GetFileName).ToHashSet(StringComparer.Ordinal);
        Require(actual.SetEquals(manifest.Expected.Keys),"missing or extra archived runs in "+manifest.Specification.Phase);
        foreach(string name in manifest.Expected.Keys.Order(StringComparer.Ordinal))ValidateExistingRun(manifest,Path.Combine(dir,name));
        return actual.Count;
    }
}
