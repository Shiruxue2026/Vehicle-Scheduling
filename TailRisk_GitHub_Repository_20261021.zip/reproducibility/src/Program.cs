using System.Globalization;
namespace TailRisk;
public static class Program {
    public static int Main(string[] args){
        CultureInfo.CurrentCulture=CultureInfo.InvariantCulture;CultureInfo.DefaultThreadCurrentCulture=CultureInfo.InvariantCulture;
        using var studyGate=new Mutex(false,"TailRisk_Rebuild_Experiment_Gate_v3");bool gateHeld=false;
        try{
            string command=args.FirstOrDefault()??"help";var options=new Dictionary<string,string>();
            if(new[]{"prepare","develop","calibrate","main","ablation","timing","replay","training-sensitivity"}.Contains(command)){
                try{gateHeld=studyGate.WaitOne(0);}catch(AbandonedMutexException){gateHeld=true;}
                if(!gateHeld)throw new InvalidOperationException("Another study command is running; use its internal --workers parallelism and run phases sequentially");
            }
            for(int i=1;i<args.Length;i++)if(args[i].StartsWith("--")){string key=args[i][2..];options[key]=i+1<args.Length&&!args[i+1].StartsWith("--")?args[++i]:"true";}
            string root=Path.GetFullPath(options.GetValueOrDefault("root",Path.Combine(AppContext.BaseDirectory,"../../../..")));
            string output=options.GetValueOrDefault("output",Path.Combine(root,"reports","validation"));
            switch(command){
                case "selftest":Validation.Run(output);break;
                case "exact":ExactAudit.Run(output);break;
                case "smoke":Commands.Smoke(root);break;
                case "prepare":Commands.Prepare(root,options);break;
                case "develop":Commands.Develop(root,options);break;
                case "select":Commands.Select(root,options);break;
                case "training-sensitivity":Commands.TrainingSensitivity(root,options);break;
                case "freeze":Commands.Freeze(root,options);break;
                case "main":Commands.MainStudy(root,options);break;
                case "ablation":Commands.Ablation(root,options);break;
                case "calibrate":Commands.Calibrate(root,options);break;
                case "timing":Commands.Timing(root,options);break;
                case "replay":Replay.Run(root,options);break;
                default:Console.WriteLine("Commands: selftest exact smoke prepare develop select freeze main ablation calibrate timing replay; --root PATH --workers N");break;
            }
            return 0;
        }catch(Exception ex){Console.Error.WriteLine(ex);return 1;}
        finally{if(gateHeld)studyGate.ReleaseMutex();}
    }
}
