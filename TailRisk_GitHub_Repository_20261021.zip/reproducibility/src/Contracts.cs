using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;
namespace TailRisk;

public sealed class TaskSpec {
    public int Id, Q, Y;
    public double PQ, HQ, PY, HY;
}
public sealed class Instance {
    public string Id, Split, Version = "geometry-v3.0";
    public int N, Qn, An, Yn, Seed;
    public TaskSpec[] Tasks;
    public double[] Qx, Yx, Ax;
    public double Width=8, Depth=4, LoadedSpeed=1, EmptySpeed=1.5;
    public double Loaded(int i)=> (Depth+Math.Abs(Qx[Tasks[i].Q]-Yx[Tasks[i].Y]))/LoadedSpeed;
    public double Empty(int i,int j)=> (Depth+Math.Abs(Yx[Tasks[i].Y]-Qx[Tasks[j].Q]))/EmptySpeed;
    public double Initial(int a,int i)=>Math.Abs(Ax[a]-Qx[Tasks[i].Q])/EmptySpeed;
}
public sealed class Schedule {
    public int[][] Q, A, Y;
    public Schedule Clone()=>new(){Q=Q.Select(x=>(int[])x.Clone()).ToArray(),A=A.Select(x=>(int[])x.Clone()).ToArray(),Y=Y.Select(x=>(int[])x.Clone()).ToArray()};
    public string Key()=>string.Join("|",new[]{Q,A,Y}.Select(z=>string.Join(";",z.Select(x=>string.Join(",",x)))));
}
public sealed class ScenarioBank {
    public double CV, Rho;
    public int Seed, Count;
    public double[][] Frames;
    public double[] Nominal;
}
public sealed class Graph {
    public int N, Nodes, Source, EdgeCount;
    public int[] P1,P2,W1,W2,Topo;
    public long BuildVisits;
}
public sealed class Evaluation {
    public bool Complete, Feasible;
    public double Risk=double.PositiveInfinity, CvarCmax=double.PositiveInfinity, NomCmax=double.PositiveInfinity, Empty=double.PositiveInfinity, Violation=double.PositiveInfinity;
    public double[] TaskTail;
    [JsonIgnore] public Graph Graph;
    [JsonIgnore] public double[][] Times;
    [JsonIgnore] public double[] WaitSamples;
}
public sealed class Sensitivity {
    public double[][] Lambda;
    public double[] TaskInfluence, TaskTail, TaskQTail, TaskYTail;
}
public sealed class SearchConfig {
    public string Id="default", Method="TS-JS", Ablation="none";
    public int Pool=128, Shortlist=24, Tenure=7, Population=32, Segment=25, RepairTrials=6;
    public double GuidedProbability=.8, MutationProbability=.35, RemovalFraction=.08, Reaction=.2, InitialTemperature=.05;
}
public sealed class Checkpoint {
    public double Fraction, Risk, Seconds;
    public long Work;
}
public sealed class RunResult {
    public string InstanceId, Phase, Method, ConfigId, StopReason, ScheduleId;
    public int N, Seed, TrainingScenarios, Proposals, Evaluations, ValidGraphs, FeasibleEvaluations;
    public long Work, Limit;
    public double Seconds, TimeLimit, ReferenceCmax, ReferenceEmpty, ReferenceCvarCmax;
    public Schedule Schedule;
    public Evaluation Evaluation;
    public List<Checkpoint> Checkpoints=new();
    public Dictionary<string,double> Diagnostics=new();
}
public sealed class WorkBudget {
    public long Limit, Used;
    public int ProposalLimit, Proposals;
    public double SecondsLimit;
    public Stopwatch Clock=Stopwatch.StartNew();
    public bool Available(long amount=1)=> Used+amount<=Limit && Proposals<ProposalLimit && (SecondsLimit<=0||Clock.Elapsed.TotalSeconds<SecondsLimit);
    public bool Charge(long amount){if(Used+amount>Limit)return false;Used+=amount;return true;}
    public bool Propose(){if(!Available())return false;Proposals++;return true;}
}
public sealed partial class SearchContext {
    public Instance Ins;
    public ScenarioBank Bank;
    public Schedule Reference;
    public Evaluation ReferenceEval;
    public WorkBudget Budget;
    public int Evaluations, ValidGraphs, FeasibleEvaluations;
    public List<Checkpoint> Checkpoints=new();
    public double BestRisk=double.PositiveInfinity;
    public int NextCheckpoint;
    public bool EvaluateNominalOnly=false;
}
public static class JsonIO {
    public static readonly JsonSerializerOptions Options=new(){IncludeFields=true,WriteIndented=true,NumberHandling=JsonNumberHandling.AllowNamedFloatingPointLiterals};
    public static readonly JsonSerializerOptions Compact=new(){IncludeFields=true,NumberHandling=JsonNumberHandling.AllowNamedFloatingPointLiterals};
    public static void Save<T>(string path,T value){Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));string temp=path+".tmp";File.WriteAllText(temp,JsonSerializer.Serialize(value,Options));File.Move(temp,path,true);}
    public static T Read<T>(string path)=>JsonSerializer.Deserialize<T>(File.ReadAllText(path),Options);
}
