namespace TailRisk;

// Every public move returns a complete schedule. Q and Y assignments are fixed.
internal static class Moves
{
    internal static int[][] Layer(Schedule s, int layer) => layer == 0 ? s.Q : layer == 1 ? s.A : s.Y;
    internal static void SetLayer(Schedule s, int layer, int[][] value)
    { if (layer == 0) s.Q = value; else if (layer == 1) s.A = value; else s.Y = value; }
    internal static (int Resource, int Position) Locate(int[][] chains, int task)
    {
        for (int r = 0; r < chains.Length; r++)
        { int p = Array.IndexOf(chains[r], task); if (p >= 0) return (r, p); }
        throw new InvalidOperationException("Move input omits a task.");
    }
    internal static Schedule Relocate(Instance ins, Schedule source, int layer, int task, int target, int position)
    {
        var old = Layer(source, layer); var location = Locate(old, task);
        if (layer == 0) target = ins.Tasks[task].Q;
        if (layer == 2) target = ins.Tasks[task].Y;
        if (target < 0 || target >= old.Length) return null;
        if (target != location.Resource && old[location.Resource].Length == 1) return null;
        var result = source.Clone(); var chains = Layer(result, layer);
        var removed = chains[location.Resource].ToList(); removed.RemoveAt(location.Position);
        chains[location.Resource] = removed.ToArray();
        var inserted = chains[target].ToList();
        inserted.Insert(Math.Clamp(position, 0, inserted.Count), task);
        chains[target] = inserted.ToArray();
        return result;
    }
    internal static Schedule Swap(Instance ins, Schedule source, int layer, int first, int second)
    {
        if (first == second) return source.Clone();
        if (layer == 0 && ins.Tasks[first].Q != ins.Tasks[second].Q) return null;
        if (layer == 2 && ins.Tasks[first].Y != ins.Tasks[second].Y) return null;
        var result = source.Clone(); var chains = Layer(result, layer);
        var a = Locate(chains, first); var b = Locate(chains, second);
        chains[a.Resource][a.Position] = second; chains[b.Resource][b.Position] = first;
        return result;
    }
    internal static int Position(int count, int oldPosition, Random random)
    {
        if (count == 0) return 0;
        return random.NextDouble() < .7
            ? Math.Clamp(oldPosition + random.Next(-3, 4), 0, count)
            : random.Next(count + 1);
    }
    internal static Schedule MoveTask(Instance ins, Schedule current, int layer, int task, Random random)
    {
        var chains = Layer(current, layer); var old = Locate(chains, task);
        int target = layer == 1 && random.NextDouble() < .4 ? random.Next(chains.Length) : old.Resource;
        if (target != old.Resource && chains[old.Resource].Length == 1)
        {
            int other = chains[target][random.Next(chains[target].Length)];
            return Swap(ins, current, layer, task, other);
        }
        int available = chains[target].Length - (target == old.Resource ? 1 : 0);
        return Relocate(ins, current, layer, task, target, Position(available, old.Position, random));
    }
    internal static Schedule RandomMutation(Instance ins, Schedule current, Random random, bool joint = false)
    {
        int task = random.Next(ins.N), layer = random.Next(3);
        var result = MoveTask(ins, current, layer, task, random);
        if (result != null && joint)
            result = MoveTask(ins, result, (layer + 1 + random.Next(2)) % 3, random.Next(ins.N), random) ?? result;
        return result;
    }
    internal static Schedule Joint(Instance ins, Schedule current, int tail, int blocker, bool yard, Random random, bool single)
    {
        int craneLayer = yard ? 2 : 0;
        int craneTask = random.NextDouble() < .65 ? blocker : tail;
        if (single) return random.NextDouble() < .5
            ? MoveTask(ins, current, 1, tail, random)
            : MoveTask(ins, current, craneLayer, craneTask, random);
        var result = MoveTask(ins, current, 1, tail, random);
        if (result == null) return null;
        result = MoveTask(ins, result, craneLayer, craneTask, random);
        return result;
    }
    internal static Schedule Crossover(Instance ins, Schedule first, Schedule second, Random random)
    {
        var result = first.Clone();
        // Inherit local resource precedences and AGV assignments from the second parent.
        // No partial child is ever evaluated. Event-DAG legality is checked afterwards.
        int changes = 2 + random.Next(5);
        for (int k = 0; k < changes; k++)
        {
            int layer = random.Next(3); var donor = Layer(second, layer);
            int resource = random.Next(donor.Length), p = random.Next(donor[resource].Length);
            int task = donor[resource][p]; var receiver = Layer(result, layer);
            var location = Locate(receiver, task);
            int target = layer == 1 ? resource : location.Resource;
            int predecessor = p == 0 ? -1 : donor[resource][p - 1];
            var without = receiver[target].Where(x => x != task).ToArray();
            int anchor = Array.IndexOf(without, predecessor);
            int position = predecessor < 0 ? 0 : anchor >= 0 ? anchor + 1 : without.Length;
            if (target != location.Resource && receiver[location.Resource].Length == 1)
            {
                int replacement = receiver[target][random.Next(receiver[target].Length)];
                result = Swap(ins, result, layer, task, replacement) ?? result;
            }
            else result = Relocate(ins, result, layer, task, target, position) ?? result;
        }
        return result;
    }
    internal static Schedule RepairProposal(Instance ins, Schedule current, HashSet<int> pending, int task, Random random)
    {
        var partial = current.Clone();
        foreach (int layer in new[] { 0, 1, 2 })
            SetLayer(partial, layer, Layer(current, layer).Select(c => c.Where(t => !pending.Contains(t)).ToArray()).ToArray());
        // Insert the selected removed task in the actual partial plan.
        foreach (int layer in new[] { 0, 1, 2 })
        {
            var old = Locate(Layer(current, layer), task);
            int target = layer == 1 && random.NextDouble() < .5 ? random.Next(ins.An) : old.Resource;
            var list = Layer(partial, layer)[target].ToList();
            int projected = Layer(current, layer)[old.Resource].Take(old.Position).Count(t => !pending.Contains(t));
            list.Insert(Position(list.Count, projected, random), task);
            Layer(partial, layer)[target] = list.ToArray();
        }
        // Restore every still-pending task before scoring. Restoration follows its
        // previous chain and places it before the first surviving original successor.
        var remaining = pending.Where(t => t != task).ToHashSet();
        foreach (int layer in new[] { 0, 1, 2 })
        {
            var original = Layer(current, layer); var completed = Layer(partial, layer);
            for (int r = 0; r < original.Length; r++)
            {
                var list = completed[r].ToList();
                for (int p = original[r].Length - 1; p >= 0; p--)
                {
                    int t = original[r][p]; if (!remaining.Contains(t)) continue;
                    int insert = list.Count;
                    for (int j = p + 1; j < original[r].Length; j++)
                    { int found = list.IndexOf(original[r][j]); if (found >= 0) { insert = found; break; } }
                    list.Insert(insert, t);
                }
                completed[r] = list.ToArray();
            }
            if (completed.Any(c => c.Length == 0)) return null;
        }
        return partial;
    }
    internal static IEnumerable<int> DirectPredecessors(Schedule schedule, int task)
    {
        foreach (var chains in new[] { schedule.Q, schedule.A, schedule.Y })
        { var z = Locate(chains, task); if (z.Position > 0) yield return chains[z.Resource][z.Position - 1]; }
    }
}

