using System.Globalization;
using System.Text;

namespace TailRisk;

// Deliberately independent of Kernel.Build/Forward: explicit outgoing arcs,
// Kahn sorting, and forward relaxation rather than the kernel's parent arrays.
public sealed class IndependentEvents
{
    public readonly Instance Ins;
    public readonly int Source;
    public readonly double[] Times;
    readonly int[] head, next, target, duration, indegree, degree, queue, order;
    readonly int[] pq, pa, py, vehicle, seen;
    int edges, ordered;
    public int Edges => edges;
    public IndependentEvents(Instance ins)
    {
        Ins=ins; Source=10*ins.N; int nodes=Source+1;
        Times=new double[nodes]; head=new int[nodes];
        next=new int[12*ins.N+8]; target=new int[next.Length]; duration=new int[next.Length];
        indegree=new int[nodes]; degree=new int[nodes]; queue=new int[nodes]; order=new int[nodes];
        pq=new int[ins.N]; pa=new int[ins.N]; py=new int[ins.N]; vehicle=new int[ins.N]; seen=new int[ins.N];
    }
    bool ReadLayer(int[][] chains,int count,int[] pred,int kind)
    {
        if(chains==null || chains.Length!=count)return false;
        Array.Clear(seen); Array.Fill(pred,-1);
        for(int r=0;r<count;r++)
        {
            if(chains[r]==null || chains[r].Length==0)return false;
            int previous=-1;
            foreach(int i in chains[r])
            {
                if(i<0 || i>=Ins.N || seen[i]++!=0)return false;
                if(kind==0 && Ins.Tasks[i].Q!=r)return false;
                if(kind==2 && Ins.Tasks[i].Y!=r)return false;
                pred[i]=previous; previous=i;
                if(kind==1)vehicle[i]=r;
            }
        }
        return seen.All(x=>x==1);
    }
    void Arc(int from,int to,int weight)
    {
        target[edges]=to; duration[edges]=weight; next[edges]=head[from]; head[from]=edges++;
        indegree[to]++;
    }
    public bool Build(Schedule s)
    {
        if(s==null || !ReadLayer(s.Q,Ins.Qn,pq,0) || !ReadLayer(s.A,Ins.An,pa,1) || !ReadLayer(s.Y,Ins.Yn,py,2))return false;
        Array.Fill(head,-1); Array.Clear(indegree); edges=0; ordered=0;
        int n=Ins.N, zero=5*n+n*n+Ins.An*n;
        for(int i=0;i<n;i++)
        {
            int v=10*i;
            Arc(pq[i]<0?Source:10*pq[i]+4,v,zero);           // SQ: preceding QC release
            Arc(v,v+1,i);                                    // EQ: QC preparation
            Arc(pa[i]<0?Source:10*pa[i]+8,v+2,
                pa[i]<0?5*n+n*n+vehicle[i]*n+i:5*n+pa[i]*n+i); // AQ: first/empty journey
            Arc(v+1,v+3,zero); Arc(v+2,v+3,zero);             // BQ: physical meeting
            Arc(v+3,v+4,n+i);                                // DQ: quay handover done
            Arc(v+4,v+5,4*n+i);                              // AY: loaded journey
            Arc(py[i]<0?Source:10*py[i]+9,v+6,zero);          // RY: preceding YC completion
            Arc(v+5,v+7,zero); Arc(v+6,v+7,zero);             // BY: yard meeting
            Arc(v+7,v+8,3*n+i);                              // DY: AGV released
            Arc(v+8,v+9,2*n+i);                              // CY: yard processing done
        }
        Array.Copy(indegree,degree,degree.Length); int first=0,last=0;
        for(int v=0;v<degree.Length;v++)if(degree[v]==0)queue[last++]=v;
        while(first<last)
        {
            int v=queue[first++]; order[ordered++]=v;
            for(int e=head[v];e>=0;e=next[e])if(--degree[target[e]]==0)queue[last++]=target[e];
        }
        return ordered==Times.Length;
    }
    public void Forward(double[] frame)
    {
        if(ordered!=Times.Length)throw new InvalidOperationException("Independent event graph is not acyclic.");
        if(frame.Length!=5*Ins.N+Ins.N*Ins.N+Ins.An*Ins.N+1)throw new ArgumentException("Duration-frame length.");
        Array.Clear(Times);
        for(int k=0;k<ordered;k++)
        {
            int v=order[k];
            for(int e=head[v];e>=0;e=next[e])
            {
                double w=frame[duration[e]];
                if(!double.IsFinite(w)||w<0)throw new ArgumentException("Invalid nonnegative event duration.");
                Times[target[e]]=Math.Max(Times[target[e]],Times[v]+w);
            }
        }
    }
    public double Makespan()=>Enumerable.Range(0,Ins.N).Max(i=>Times[10*i+9]);
    public double[] Waits()=>Enumerable.Range(0,Ins.N).Select(i=>
        Math.Max(0,Times[10*i+3]-Times[10*i+2])+Math.Max(0,Times[10*i+7]-Times[10*i+5])).ToArray();
    public double Empty(Schedule s)=>s.A.Select((chain,a)=>Ins.Initial(a,chain[0])+
        Enumerable.Range(1,chain.Length-1).Sum(k=>Ins.Empty(chain[k-1],chain[k]))).Sum();
    public static double Cvar(IEnumerable<double> values,double beta=.95)
    {
        double[] a=values.OrderByDescending(x=>x).ToArray();
        if(a.Length==0 || beta<0 || beta>=1 || a.Any(x=>!double.IsFinite(x)))throw new ArgumentException("CVaR domain.");
        double mass=(1-beta)*a.Length, left=mass,total=0;
        for(int k=0;k<a.Length && left>1e-12;k++)
        {double take=Math.Min(1,left);total+=take*a[k];left-=take;}
        return total/mass;
    }
    public static bool PriorityRepresentable(Schedule s,int n)
    {
        bool[,] arcs=new bool[n,n]; int[] deg=new int[n];
        foreach(int[][] layer in new[]{s.Q,s.A,s.Y})foreach(int[] chain in layer)
            for(int k=1;k<chain.Length;k++)
            {int u=chain[k-1],v=chain[k];if(!arcs[u,v]){arcs[u,v]=true;deg[v]++;}}
        var q=new Queue<int>(Enumerable.Range(0,n).Where(i=>deg[i]==0)); int done=0;
        while(q.Count>0){int u=q.Dequeue();done++;for(int v=0;v<n;v++)if(arcs[u,v] && --deg[v]==0)q.Enqueue(v);}
        return done==n;
    }
}

public static class ExactAudit
{
    sealed class Record {public Schedule Schedule;public double Nominal,Empty;public bool Priority;}
    static IEnumerable<int[]> Permutations(int[] source)
    {
        int[] a=(int[])source.Clone();
        IEnumerable<int[]> Visit(int k)
        {
            if(k==a.Length){yield return (int[])a.Clone();yield break;}
            for(int j=k;j<a.Length;j++)
            { (a[j],a[k])=(a[k],a[j]);foreach(var p in Visit(k+1))yield return p;(a[j],a[k])=(a[k],a[j]); }
        }
        return Visit(0);
    }
    static List<int[][]> FixedChains(Instance ins,bool quay)
    {
        int count=quay?ins.Qn:ins.Yn;var result=new List<int[][]>();var current=new int[count][];
        void Visit(int r)
        {
            if(r==count){result.Add(current.Select(x=>(int[])x.Clone()).ToArray());return;}
            int[] tasks=Enumerable.Range(0,ins.N).Where(i=>(quay?ins.Tasks[i].Q:ins.Tasks[i].Y)==r).ToArray();
            if(tasks.Length==0)throw new InvalidOperationException("Exact benchmark has an unused fixed resource.");
            foreach(var p in Permutations(tasks)){current[r]=p;Visit(r+1);}
        }
        Visit(0);return result;
    }
    static List<int[][]> VehicleChains(int n)
    {
        var result=new List<int[][]>();
        foreach(var p in Permutations(Enumerable.Range(0,n).ToArray()))for(int cut=1;cut<n;cut++)
            result.Add(new[]{p.Take(cut).ToArray(),p.Skip(cut).ToArray()});
        return result;
    }
    static bool Better(double risk,string key,double current,string currentKey)=>
        risk<current-1e-10 || (Math.Abs(risk-current)<=1e-10 && (currentKey==null || string.CompareOrdinal(key,currentKey)<0));
    public static void Run(string outputdir)
    {
        Directory.CreateDirectory(outputdir);
        var rows=new List<string>{"N,Index,Candidates,EventFeasible,PriorityRepresentable,ReferenceCmax,ReferenceEmpty,ReferenceCvarCmax,NominalAndEmptyFeasible,AllConstraintsFeasible,PriorityAllConstraintsFeasible,FullRisk,PriorityRisk,ReferencePriority"};
        for(int n=4;n<=6;n++)for(int index=1;index<=2;index++)
        {
            Instance ins=Model.Generate(n,index,"exact");
            if(ins.Qn!=2 || ins.An!=2 || ins.Yn!=2)throw new InvalidOperationException("Exact audit requires two resources per layer.");
            var qlist=FixedChains(ins,true);var ylist=FixedChains(ins,false);var alist=VehicleChains(n);
            var ev=new IndependentEvents(ins);double[] nominal=Model.NominalFrame(ins);
            var feasible=new List<Record>();var s=new Schedule();Record reference=null;string referenceKey=null;
            long candidates=0,represented=0;
            foreach(var q in qlist)foreach(var y in ylist)foreach(var a in alist)
            {
                candidates++;s.Q=q;s.Y=y;s.A=a;if(!ev.Build(s))continue;
                ev.Forward(nominal);double c=ev.Makespan(),empty=ev.Empty(s);bool rep=IndependentEvents.PriorityRepresentable(s,n);
                if(rep)represented++;
                var row=new Record{Schedule=s.Clone(),Nominal=c,Empty=empty,Priority=rep};feasible.Add(row);
                bool tie=reference!=null && Math.Abs(c-reference.Nominal)<=1e-10 && Math.Abs(empty-reference.Empty)<=1e-10;
                string key=tie || reference==null?s.Key():null;
                if(reference==null || c<reference.Nominal-1e-10 || (Math.Abs(c-reference.Nominal)<=1e-10 && empty<reference.Empty-1e-10) || (tie && string.CompareOrdinal(key,referenceKey)<0))
                {reference=row;referenceKey=key??s.Key();}
            }
            if(reference==null)throw new InvalidOperationException("Empty exact feasible domain.");
            ScenarioBank bank=Model.MakeBank(ins,64,.20,2027100000+100*n+index);
            double[] cmax=new double[bank.Count],wait=new double[n*bank.Count];
            void Replay(Schedule plan)
            {
                if(!ev.Build(plan))throw new InvalidOperationException("Stored exact plan became infeasible.");
                for(int b=0;b<bank.Count;b++)
                {ev.Forward(bank.Frames[b]);cmax[b]=ev.Makespan();Array.Copy(ev.Waits(),0,wait,b*n,n);}
            }
            Replay(reference.Schedule);double refRiskC=IndependentEvents.Cvar(cmax);
            double tol=1e-9*Math.Max(1,reference.Nominal), fullRisk=double.PositiveInfinity,priorityRisk=double.PositiveInfinity;
            long eligible=0,all=0,priorityAll=0;Schedule fullPlan=null,priorityPlan=null;string fullKey=null,priorityKey=null;
            foreach(var row in feasible)
            {
                if(row.Nominal>1.01*reference.Nominal+tol || row.Empty>1.01*reference.Empty+1e-9*Math.Max(1,reference.Empty))continue;
                eligible++;Replay(row.Schedule);double cr=IndependentEvents.Cvar(cmax);
                if(cr>refRiskC+.01*reference.Nominal+tol)continue;
                all++;if(row.Priority)priorityAll++;
                double risk=IndependentEvents.Cvar(wait);string key=row.Schedule.Key();
                if(Better(risk,key,fullRisk,fullKey)){fullRisk=risk;fullPlan=row.Schedule;fullKey=key;}
                if(row.Priority && Better(risk,key,priorityRisk,priorityKey)){priorityRisk=risk;priorityPlan=row.Schedule;priorityKey=key;}
            }
            string id=$"exact_n{n}_i{index}";
            JsonIO.Save(Path.Combine(outputdir,id+".json"),new{Instance=ins,TrainingCV=bank.CV,TrainingSeed=bank.Seed,TrainingScenarios=bank.Count,Candidates=candidates,EventFeasible=feasible.Count,PriorityRepresentable=represented,Reference=reference.Schedule,ReferenceCmax=reference.Nominal,ReferenceEmpty=reference.Empty,ReferenceCvarCmax=refRiskC,ReferencePriority=reference.Priority,NominalAndEmptyFeasible=eligible,AllConstraintsFeasible=all,PriorityAllConstraintsFeasible=priorityAll,FullRisk=fullRisk,PriorityRisk=priorityRisk,FullPlan=fullPlan,PriorityPlan=priorityPlan});
            object[] values={n,index,candidates,feasible.Count,represented,reference.Nominal,reference.Empty,refRiskC,eligible,all,priorityAll,fullRisk,priorityRisk,reference.Priority};
            rows.Add(string.Join(",",values.Select(v=>Convert.ToString(v,CultureInfo.InvariantCulture))));
            File.WriteAllLines(Path.Combine(outputdir,"exact_summary.csv"),rows,Encoding.UTF8);
            Console.WriteLine($"Exact {id}: {candidates} candidates; {feasible.Count} event-feasible.");
        }
    }
}

public static class Validation
{
    static readonly List<object> Checks=new();
    static double maxEventError,maxMetricError,maxDerivativeError;
    static void Require(bool condition,string message)
    {if(!condition)throw new InvalidOperationException("Independent validation: "+message);}
    static void Close(double actual,double expected,string message,double tolerance=1e-9)
    {
        Require(double.IsFinite(actual)&&double.IsFinite(expected),message+" is nonfinite");
        double error=Math.Abs(actual-expected);maxMetricError=Math.Max(maxMetricError,error);
        Require(error<=tolerance*Math.Max(1,Math.Abs(expected)),message+$": {actual:R} != {expected:R}");
    }
    static Instance Toy()
    {
        var ins=new Instance{Id="validation_initial_travel",Split="validation",N=4,Qn=2,An=2,Yn=2,Qx=new[]{0.0,10},Yx=new[]{2.0,8},Ax=new[]{5.0,7},Width=10,Depth=4};
        ins.Tasks=Enumerable.Range(0,4).Select(i=>new TaskSpec{Id=i,Q=i%2,Y=i/2,PQ=4+i,HQ=1+i%2,PY=6-i,HY=1}).ToArray();
        return ins;
    }
    static void Compare(Instance ins,Schedule s,ScenarioBank bank)
    {
        var audit=new IndependentEvents(ins);Require(audit.Build(s),"reference independent graph");
        Graph graph=Kernel.Build(ins,s,out long visits);Require(graph!=null,"kernel rejected independent feasible graph");
        Require(visits==24L*ins.N && graph.EdgeCount==12*ins.N,"graph work accounting");
        var actual=new double[graph.Nodes];var allWaits=new List<double>();var makespans=new List<double>();
        foreach(var frame in bank.Frames.Prepend(bank.Nominal))
        {
            audit.Forward(frame);Kernel.Forward(graph,frame,actual);
            for(int v=0;v<actual.Length;v++)
            {maxEventError=Math.Max(maxEventError,Math.Abs(actual[v]-audit.Times[v]));Close(actual[v],audit.Times[v],"event time");}
            Close(Kernel.Cmax(graph,actual),audit.Makespan(),"makespan");
            double[] waits=audit.Waits();
            for(int i=0;i<ins.N;i++)Close(Kernel.Wait(actual,i),waits[i],"total task waiting");
            Close(Kernel.Cvar(waits),IndependentEvents.Cvar(waits),"per-scenario waiting CVaR");
            CheckOccupancy(audit);
            if(!ReferenceEquals(frame,bank.Nominal)){allWaits.AddRange(waits);makespans.Add(audit.Makespan());}
        }
        Close(Kernel.Empty(ins,s),audit.Empty(s),"empty travel including depot legs");
        var ctx=SearchContext.Create(ins,bank,s,100_000_000);
        long before=ctx.Budget.Used;var e=ctx.Evaluate(s,true);
        Require(e!=null&&e.Complete&&e.Feasible,"complete reference evaluation");
        Require(ctx.Budget.Used-before==24L*ins.N+12L*ins.N*(bank.Count+1),"scenario evaluation work accounting");
        Close(e.Risk,IndependentEvents.Cvar(allWaits),"joint task-scenario CVaR");
        Close(e.CvarCmax,IndependentEvents.Cvar(makespans),"completion CVaR");
        Close(e.Empty,audit.Empty(s),"evaluation empty travel");
        Close(e.TaskTail.Sum(),e.Risk,"task attribution sums to risk");
        Require(e.Times.Length==bank.Count,"trace count excludes nominal");
        var limited=SearchContext.Create(ins,bank,s,24L*ins.N+12L*ins.N*(bank.Count+1)-1);
        Require(limited.Evaluate(s,true)==null,"incomplete budget must not return partial scenario evaluation");
        Require(limited.Budget.Used<=limited.Budget.Limit,"strict evaluation budget");
    }
    static void CheckOccupancy(IndependentEvents e)
    {
        foreach(bool quay in new[]{true,false})
        {
            var intervals=Enumerable.Range(0,e.Ins.N).Select(i=>(Start:e.Times[10*i+(quay?2:5)],End:e.Times[10*i+(quay?3:7)])).ToArray();
            var knots=intervals.SelectMany(p=>new[]{p.Start,p.End}).Append(0).Append(e.Makespan()).Distinct().OrderBy(x=>x).ToArray();
            double area=0;
            for(int k=1;k<knots.Length;k++)
            {double midpoint=.5*(knots[k-1]+knots[k]);int count=intervals.Count(p=>p.Start<=midpoint&&midpoint<p.End);area+=count*(knots[k]-knots[k-1]);}
            Close(area,intervals.Sum(p=>p.End-p.Start),"integrated queue occupancy equals accumulated AGV wait");
        }
    }
    static void CheckCvar()
    {
        var cases=new[]{(new[]{0.0,0,0,10},.5,5.0),(new[]{0.0,0,0,10},.95,10.0),(new[]{0.0,1,2,3},.625,8.0/3),(new[]{1.0,2,2,2,7},.6,4.5),(new[]{0.0,0,0},.95,0.0),(new[]{3.0},.95,3.0)};
        foreach(var (values,beta,expected) in cases)
        {
            Close(Kernel.Cvar(values,beta),expected,"known fractional-tail CVaR");
            var weights=Kernel.TailWeights(values,beta);
            Close(weights.Sum(),1,"CVaR weights sum to one");
            Require(weights.All(w=>w>=0 && w<=1/((1-beta)*values.Length)+1e-10),"CVaR weight constraints");
            Close(weights.Zip(values,(w,v)=>w*v).Sum(),expected,"tail-weight objective");
            for(int i=0;i<values.Length;i++)for(int j=0;j<values.Length;j++)if(values[i]==values[j])Close(weights[i],weights[j],"equal split across tail ties");
        }
        var rng=new Random(20271014);
        foreach(int n in new[]{1,3,20,21,63,64,257})foreach(double beta in new[]{0.0,.5,.95,.975})
        {
            var values=Enumerable.Range(0,n).Select(_=>rng.NextDouble()<.3?0:Math.Round(10*rng.NextDouble(),2)).ToArray();
            Close(Kernel.Cvar(values,beta),IndependentEvents.Cvar(values,beta),"independent sorted-tail CVaR");
        }
        Checks.Add(new{Check="CVaR fractional order statistics, tied weights, zero samples",Status="passed"});
    }
    static void CheckInvalid(Instance ins,Schedule valid)
    {
        var invalid=new List<Schedule>();
        var x=valid.Clone();x.A[0]=Array.Empty<int>();invalid.Add(x);
        x=valid.Clone();x.A[0]=x.A[0].Concat(new[]{x.A[1][0]}).ToArray();invalid.Add(x);
        x=valid.Clone();x.Q[0][0]=x.Q[1][0];invalid.Add(x);
        x=valid.Clone();(x.Y[0],x.Y[1])=(x.Y[1],x.Y[0]);invalid.Add(x);
        x=valid.Clone();x.A[0][0]=ins.N;invalid.Add(x);
        x=valid.Clone();x.A[0]=x.A[0].Skip(1).ToArray();invalid.Add(x);
        foreach(var s in invalid)
        {
            Require(!new IndependentEvents(ins).Build(s),"independent invalid assignment rejection");
            Require(Kernel.Build(ins,s,out _)==null,"kernel invalid assignment rejection");
        }
        // The task 0 -> task 2 quay/vehicle precedences oppose their yard order.
        var cycle=new Schedule{Q=new[]{new[]{0,2},new[]{1,3}},A=new[]{new[]{0,2},new[]{1,3}},Y=new[]{new[]{2,0},new[]{1,3}}};
        var cyclicIns=Toy();foreach(var task in cyclicIns.Tasks)task.Y=task.Id%2;
        Require(!new IndependentEvents(cyclicIns).Build(cycle),"independent deadlock rejection");
        Require(Kernel.Build(cyclicIns,cycle,out _)==null,"kernel deadlock rejection");
        Checks.Add(new{Check="Nonempty complete assignments, fixed-resource compatibility and cyclic chains",Cases=invalid.Count+1,Status="passed"});
    }
    static void CheckDerivatives(Instance ins,Schedule s,ScenarioBank bank)
    {
        var ctx=SearchContext.Create(ins,bank,s,100_000_000);var e=ctx.Evaluate(s,true);
        long before=ctx.Budget.Used;var sensitivity=ctx.Differentiate(e);
        Require(sensitivity!=null,"sensitivity budget");
        Require(ctx.Budget.Used-before==2L*e.Graph.EdgeCount*bank.Count,"reverse-pass accounting");
        Close(sensitivity.TaskTail.Sum(),e.Risk,"sensitivity tail attribution");
        Close(sensitivity.TaskQTail.Sum()+sensitivity.TaskYTail.Sum(),e.Risk,"interface attribution");
        before=ctx.Budget.Used;
        Close(ctx.ScoreCandidate(e.Graph,e,sensitivity),0,"unchanged graph screening score");
        Require(ctx.Budget.Used-before==2L*e.Graph.EdgeCount,"residual screening full graph scan accounting");
        var audit=new IndependentEvents(ins);Require(audit.Build(s),"derivative independent graph");
        double[] samples=new double[bank.Count*ins.N];
        double Risk()
        {for(int b=0;b<bank.Count;b++){audit.Forward(bank.Frames[b]);Array.Copy(audit.Waits(),0,samples,b*ins.N,ins.N);}return IndependentEvents.Cvar(samples);}
        double baseline=Risk();int checkedCount=0,kinks=0,nonzero=0;double epsilon=1e-5;
        int[] eventOffsets={1,4,9,8,5};
        for(int b=0;b<bank.Count;b++)for(int type=0;type<5;type++)for(int i=0;i<ins.N;i++)
        {
            int position=type*ins.N+i;double old=bank.Frames[b][position];
            bank.Frames[b][position]=old+epsilon;double plus=Risk();
            bank.Frames[b][position]=old-epsilon;double minus=Risk();bank.Frames[b][position]=old;
            double right=(plus-baseline)/epsilon,left=(baseline-minus)/epsilon;
            if(Math.Abs(right-left)>2e-5){kinks++;continue;}
            double finiteDifference=(plus-minus)/(2*epsilon),analytic=sensitivity.Lambda[b][10*i+eventOffsets[type]];
            if(Math.Abs(finiteDifference)>1e-6)nonzero++;
            double error=Math.Abs(finiteDifference-analytic);maxDerivativeError=Math.Max(maxDerivativeError,error);
            Close(analytic,finiteDifference,"adjoint versus independent central difference",2e-5);checkedCount++;
        }
        Require(checkedCount>=10,"insufficient smooth finite-difference checks");
        Require(nonzero>0,"finite-difference test must include active nonzero tail gradients");
        Checks.Add(new{Check="Reverse sensitivities versus independent central finite differences",SmoothCoordinates=checkedCount,NonzeroCoordinates=nonzero,NondifferentiableCoordinates=kinks,MaxError=maxDerivativeError,Status="passed"});
    }
    static void CheckSolvers()
    {
        var ins=Model.Generate(24,1,"validation");var reference=Model.InitialSchedule(ins,20271016);
        var bank=Model.MakeBank(ins,8,.2,20271017);var audit=new IndependentEvents(ins);
        foreach(string method in new[]{"GA","ALNS","CB-TS","TS-JS"})
        {
            var cfg=new SearchConfig{Id="validation-small",Method=method,Population=8,Pool=16,Shortlist=4,Segment=4,RepairTrials=3,Tenure=3};
            var ctx=SearchContext.Create(ins,bank,reference,300_000);var run=Solvers.Run(ctx,cfg,20271018);
            Require(run.Evaluation!=null&&run.Evaluation.Complete&&run.Evaluation.Feasible,"solver incumbent must be complete and feasible: "+method);
            Require(run.Work<=run.Limit && run.Work==ctx.Budget.Used,"solver strict work limit: "+method);
            Require(audit.Build(run.Schedule),"independent feasibility of final repaired plan: "+method);
            var waits=new List<double>();var makespans=new List<double>();
            foreach(var frame in bank.Frames){audit.Forward(frame);waits.AddRange(audit.Waits());makespans.Add(audit.Makespan());}
            Close(run.Evaluation.Risk,IndependentEvents.Cvar(waits),"solver final risk: "+method);
            Close(run.Evaluation.CvarCmax,IndependentEvents.Cvar(makespans),"solver final completion risk: "+method);
            Close(run.Evaluation.Empty,audit.Empty(run.Schedule),"solver final empty travel: "+method);
            audit.Forward(bank.Nominal);Close(run.Evaluation.NomCmax,audit.Makespan(),"solver nominal completion: "+method);
            double tol=1e-9*Math.Max(1,ctx.ReferenceEval.NomCmax);
            Require(run.Evaluation.NomCmax<=1.01*ctx.ReferenceEval.NomCmax+tol,"solver nominal constraint: "+method);
            Require(run.Evaluation.Empty<=1.01*ctx.ReferenceEval.Empty+1e-9*Math.Max(1,ctx.ReferenceEval.Empty),"solver empty constraint: "+method);
            Require(run.Evaluation.CvarCmax<=ctx.ReferenceEval.CvarCmax+.01*ctx.ReferenceEval.NomCmax+tol,"solver risk constraint: "+method);
            Require(run.Diagnostics["PartialEvaluations"]==0,"partial repair evaluation counter: "+method);
            var ctx2=SearchContext.Create(ins,bank,reference,300_000);var again=Solvers.Run(ctx2,cfg,20271018);
            Require(run.Schedule.Key()==again.Schedule.Key() && run.Work==again.Work && run.Proposals==again.Proposals,"budget-limited solver determinism: "+method);
            Close(run.Evaluation.Risk,again.Evaluation.Risk,"solver deterministic risk: "+method);
            var partial=reference.Clone();partial.A[0]=partial.A[0].Skip(1).ToArray();
            var partialCtx=SearchContext.Create(ins,bank,reference,300_000);
            Require(partialCtx.Evaluate(partial)==null,"incomplete repair never yields objective: "+method);
            Checks.Add(new{Check="Complete solver result, independent metrics, constraints, strict budget and deterministic repetition",Method=method,run.Work,run.Evaluations,RepairLookaheads=run.Diagnostics["RepairLookaheads"],Status="passed"});
        }
    }
    public static void Run(string outputdir)
    {
        Directory.CreateDirectory(outputdir);Checks.Clear();maxEventError=maxMetricError=maxDerivativeError=0;
        CheckCvar();Instance toy=Toy();Schedule plan=Model.Priority(toy,new[]{0,1,2,3},new[]{0,1,0,1});
        var toyBank=Model.MakeBank(toy,8,.20,20271015);Compare(toy,plan,toyBank);CheckInvalid(toy,plan);
        var fixtureCases=new List<object>();var fixtureGraph=Kernel.Build(toy,plan,out _);
        foreach(double cv in new[]{0.0,.10,.20})foreach(double rho in new[]{0.0,.50})foreach(int scenario in new[]{0,7,999})
        {var times=new double[fixtureGraph.Nodes];Kernel.Forward(fixtureGraph,Model.Frame(toy,cv,20271015,scenario,rho),times);fixtureCases.Add(new{CV=cv,Rho=rho,Scenario=scenario,Times=times,Metrics=Operations.Measure(toy,plan,times)});}
        JsonIO.Save(Path.Combine(outputdir,"interpreter_fixture.json"),new{Purpose="Artificial cross-language audit fixture; not experimental evidence",Instance=toy,Schedule=plan,ScenarioSeed=20271015,Cases=fixtureCases});
        var audit=new IndependentEvents(toy);Require(audit.Build(plan),"initial-travel graph");audit.Forward(toyBank.Nominal);
        for(int a=0;a<toy.An;a++){int i=plan.A[a][0];Close(audit.Times[10*i+2],toy.Initial(a,i),"depot-to-first-quay arrival");Require(toy.Initial(a,i)>0,"nonzero initial travel test");}
        CheckDerivatives(toy,plan,toyBank);
        int schedules=1;
        foreach(int n in new[]{4,5,6,24,48,96,192})for(int index=1;index<=2;index++)
        {
            var ins=Model.Generate(n,index,n<=6?"exact":"validation");var bank=Model.MakeBank(ins,8,.2,Model.Seed("validation-bank|"+ins.Id));
            var copy=Model.MakeBank(ins,8,.2,bank.Seed);
            for(int b=0;b<bank.Count;b++)Require(bank.Frames[b].SequenceEqual(copy.Frames[b]),"scenario determinism");
            Require(Model.Frame(ins,0,bank.Seed,0).SequenceEqual(bank.Nominal),"zero-CV replay equals nominal");
            for(int seed=0;seed<3;seed++)
            {
                var schedule=Model.InitialSchedule(ins,Model.Seed($"validation-plan|{ins.Id}|{seed}"));
                Require(schedule.Key()==Model.InitialSchedule(ins,Model.Seed($"validation-plan|{ins.Id}|{seed}")).Key(),"schedule determinism");
                Require(IndependentEvents.PriorityRepresentable(schedule,ins.N),"priority construction representation");
                Compare(ins,schedule,bank);schedules++;
            }
        }
        Checks.Add(new{Check="Independent replay, complete-evaluation budgets, occupancy identities and determinism",Schedules=schedules,ScenariosPerSchedule=8,MaxEventError=maxEventError,MaxMetricError=maxMetricError,Status="passed"});
        CheckSolvers();
        JsonIO.Save(Path.Combine(outputdir,"validation.json"),new{Status="passed",Implementation="independent-outgoing-arcs-v1",Checks,MaxEventError=maxEventError,MaxMetricError=maxMetricError,MaxDerivativeError=maxDerivativeError});
        Console.WriteLine($"Independent validation passed: {schedules} schedules; maximum event error {maxEventError:R}.");
    }
}
