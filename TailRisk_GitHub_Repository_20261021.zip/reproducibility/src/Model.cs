using System.Security.Cryptography;
using System.Text;
namespace TailRisk;

public static class Model {
    public static int Seed(string name)=>BitConverter.ToInt32(SHA256.HashData(Encoding.UTF8.GetBytes("tailrisk-v3|"+name)),0)&int.MaxValue;
    public static void Shuffle<T>(T[] a,Random r){for(int i=a.Length-1;i>0;i--){int j=r.Next(i+1);(a[i],a[j])=(a[j],a[i]);}}
    public static Instance Generate(int n,int index,string split){
        var counts=n switch {24=>(3,4,3),48=>(4,6,4),96=>(6,10,6),192=>(8,16,8),_ when n>=4&&n<=6=>(2,2,2),_=>throw new ArgumentException("Unsupported N")};
        int seed=Seed($"instance|{split}|{n}|{index}");
        var ins=new Instance{Id=$"{split}_N{n}_I{index:00}",N=n,Qn=counts.Item1,An=counts.Item2,Yn=counts.Item3,Seed=seed,Split=split};
        ins.Qx=Enumerable.Range(0,ins.Qn).Select(q=>8.0*(q+.5)/ins.Qn).ToArray();
        ins.Yx=Enumerable.Range(0,ins.Yn).Select(y=>8.0*(y+.5)/ins.Yn).ToArray();
        ins.Ax=Enumerable.Range(0,ins.An).Select(a=>8.0*(a+.5)/ins.An).ToArray();
        int[] qs=Enumerable.Range(0,n).Select(i=>i%ins.Qn).ToArray(),ys=Enumerable.Range(0,n).Select(i=>i%ins.Yn).ToArray();
        Shuffle(qs,new Random(Seed($"{seed}|qc")));Shuffle(ys,new Random(Seed($"{seed}|yc")));
        var rng=new Random(Seed($"{seed}|service"));
        ins.Tasks=Enumerable.Range(0,n).Select(i=>new TaskSpec{Id=i,Q=qs[i],Y=ys[i],PQ=4+rng.Next(4),PY=4+rng.Next(4),HQ=1+rng.Next(2),HY=1+rng.Next(2)}).ToArray();
        return ins;
    }
    public static Schedule Priority(Instance ins,int[] order,int[] aa){
        var q=Enumerable.Range(0,ins.Qn).Select(_=>new List<int>()).ToArray();
        var a=Enumerable.Range(0,ins.An).Select(_=>new List<int>()).ToArray();
        var y=Enumerable.Range(0,ins.Yn).Select(_=>new List<int>()).ToArray();
        foreach(int i in order){q[ins.Tasks[i].Q].Add(i);a[aa[i]].Add(i);y[ins.Tasks[i].Y].Add(i);}
        return new(){Q=q.Select(x=>x.ToArray()).ToArray(),A=a.Select(x=>x.ToArray()).ToArray(),Y=y.Select(x=>x.ToArray()).ToArray()};
    }
    public static Schedule InitialSchedule(Instance ins,int seed){var rng=new Random(seed);var order=Enumerable.Range(0,ins.N).ToArray();Shuffle(order,rng);var aa=Enumerable.Range(0,ins.N).Select(i=>i%ins.An).ToArray();Shuffle(aa,rng);return Priority(ins,order,aa);}
    public static double[] NominalFrame(Instance ins){
        int n=ins.N;var frame=new double[5*n+n*n+ins.An*n+1];
        for(int i=0;i<n;i++){var t=ins.Tasks[i];frame[i]=t.PQ;frame[n+i]=t.HQ;frame[2*n+i]=t.PY;frame[3*n+i]=t.HY;frame[4*n+i]=ins.Loaded(i);for(int j=0;j<n;j++)frame[5*n+i*n+j]=ins.Empty(i,j);}
        for(int a=0;a<ins.An;a++)for(int i=0;i<n;i++)frame[5*n+n*n+a*n+i]=ins.Initial(a,i);
        return frame;
    }
    static ulong Mix(ulong z){unchecked{z=(z^(z>>30))*0xbf58476d1ce4e5b9UL;z=(z^(z>>27))*0x94d049bb133111ebUL;return z^(z>>31);}}
    static double Uniform(ulong key)=>( (Mix(key)>>11)+.5 )*(1.0/9007199254740992.0);
    static double Normal(ulong key)=>Math.Sqrt(-2*Math.Log(Uniform(key)))*Math.Cos(2*Math.PI*Uniform(key^0x9e3779b97f4a7c15UL));
    public static double[] Frame(Instance ins,double cv,int seed,int index,double rho=0)=>Perturb(NominalFrame(ins),cv,seed,index,rho);
    public static double[] Perturb(double[] nominal,double cv,int seed,int index,double rho=0){
        if(cv<0||rho<0||rho>1)throw new ArgumentException("Invalid uncertainty");
        var result=(double[])nominal.Clone();if(cv==0)return result;
        double sigma=Math.Sqrt(Math.Log(1+cv*cv)), shared=Math.Sqrt(rho),local=Math.Sqrt(1-rho);
        ulong basis=unchecked((ulong)(uint)seed*0x9e3779b97f4a7c15UL ^ (ulong)(uint)(index+1)*0xd1b54a32d192ed03UL);
        double common=Normal(basis^0x94d049bb133111ebUL);
        for(int i=0;i<result.Length-1;i++)if(result[i]!=0){double z=shared*common+local*Normal(unchecked(basis+(ulong)(i+1)*0x632be59bd9b4e019UL));result[i]*=Math.Exp(-.5*sigma*sigma+sigma*z);}
        return result;
    }
    public static ScenarioBank MakeBank(Instance ins,int count,double cv,int seed,double rho=0){var nominal=NominalFrame(ins);return new(){Count=count,CV=cv,Seed=seed,Rho=rho,Nominal=nominal,Frames=Enumerable.Range(0,count).Select(i=>Perturb(nominal,cv,seed,i,rho)).ToArray()};}
}
