namespace TailRisk;

public static class Solvers
{
    private sealed class Individual
    {
        public Schedule S;
        public Evaluation E;
        public Individual(Schedule s, Evaluation e) { S = s; E = e; }
    }
    private sealed class Candidate
    {
        public Schedule S;
        public Graph G;
        public string Key;
        public double Score;
        public int Index;
    }
    private sealed class Counters
    {
        public int FullCandidates, RepairLookaheads, PoolCandidates, ResidualScores, JointCandidates,
            SingleCandidates, UpstreamSelections, TabuRejected, AdaptiveUpdates, Accepted, CompletedRounds,
            EmptyNeighborhoodRounds, AllTabuRounds;
        public readonly int[] DestroyUses = new int[3], RepairUses = new int[2];
        public readonly double[] DestroyWeights = { 1, 1, 1 }, RepairWeights = { 1, 1 };
    }
    public static RunResult Run(SearchContext ctx, SearchConfig cfg, int seed)
    {
        var random = new Random(seed); var c = new Counters();
        string method = cfg.Method.ToUpperInvariant();
        Individual best = method switch
        {
            "GA" or "RISK-GA" => Genetic(ctx, cfg, random, c),
            "ALNS" or "ADAPTIVE-ALNS" => AdaptiveLns(ctx, cfg, random, c),
            "CB-TS" or "CRITICAL-BLOCK-TABU" or "CRITICAL-BLOCK-TS" => Tabu(ctx, cfg, random, c, true),
            "TS-JS" => Tabu(ctx, cfg, random, c, false),
            _ => throw new ArgumentException("Unknown solver: " + cfg.Method)
        };
        var result = ctx.Finish(best.S, best.E, cfg.Method, seed, cfg.Id);
        result.Diagnostics["FullCandidates"] = c.FullCandidates;
        result.Diagnostics["RepairLookaheads"] = c.RepairLookaheads;
        result.Diagnostics["PartialEvaluations"] = 0;
        result.Diagnostics["PoolCandidates"] = c.PoolCandidates;
        result.Diagnostics["ResidualScores"] = c.ResidualScores;
        result.Diagnostics["JointCandidates"] = c.JointCandidates;
        result.Diagnostics["SingleCandidates"] = c.SingleCandidates;
        result.Diagnostics["UpstreamSelections"] = c.UpstreamSelections;
        result.Diagnostics["TabuRejected"] = c.TabuRejected;
        result.Diagnostics["AdaptiveUpdates"] = c.AdaptiveUpdates;
        result.Diagnostics["Accepted"] = c.Accepted;
        result.Diagnostics["CompletedRounds"] = c.CompletedRounds;
        result.Diagnostics["EmptyNeighborhoodRounds"] = c.EmptyNeighborhoodRounds;
        result.Diagnostics["AllTabuRounds"] = c.AllTabuRounds;
        for (int i = 0; i < 3; i++)
        { result.Diagnostics["DestroyUses" + i] = c.DestroyUses[i]; result.Diagnostics["DestroyWeight" + i] = c.DestroyWeights[i]; }
        for (int i = 0; i < 2; i++)
        { result.Diagnostics["RepairUses" + i] = c.RepairUses[i]; result.Diagnostics["RepairWeight" + i] = c.RepairWeights[i]; }
        return result;
    }
    private static long EvaluationReserve(SearchContext ctx)
        => 15L * ctx.Ins.N * ((ctx.EvaluateNominalOnly ? 1 : ctx.Bank.Count) + 4);
    private static bool CanEvaluate(SearchContext ctx)
        => ctx.CanContinue && ctx.Budget.Available(EvaluationReserve(ctx));
    private static int Compare(SearchContext ctx, Evaluation a, Evaluation b)
    {
        if (ctx.EvaluateNominalOnly)
        { int nominal = a.NomCmax.CompareTo(b.NomCmax); return nominal != 0 ? nominal : a.Empty.CompareTo(b.Empty); }
        if (a.Feasible != b.Feasible) return a.Feasible ? -1 : 1;
        if (!a.Feasible)
        { int violation = a.Violation.CompareTo(b.Violation); if (violation != 0) return violation; }
        int z = a.Risk.CompareTo(b.Risk); if (z != 0) return z;
        z = a.CvarCmax.CompareTo(b.CvarCmax); if (z != 0) return z;
        z = a.NomCmax.CompareTo(b.NomCmax); return z != 0 ? z : a.Empty.CompareTo(b.Empty);
    }
    private static double Merit(SearchContext ctx, Evaluation e)
        => ctx.EvaluateNominalOnly ? e.NomCmax : e.Risk + (e.Feasible ? 0 : 1e6 * (1 + e.Violation));
    private static Individual Initial(SearchContext ctx, bool trace, Counters c)
    {
        // The common reference is always retained, even if the search budget is tiny.
        var fallback = new Individual(ctx.Reference.Clone(), ctx.ReferenceEval);
        ctx.RecordBest(fallback.E);
        if (!CanEvaluate(ctx) || !ctx.Budget.Propose()) return fallback;
        var e = ctx.Evaluate(fallback.S, trace);
        if (e == null || !e.Complete) return fallback;
        c.FullCandidates++;
        var initial = new Individual(fallback.S, e); ctx.RecordBest(e); return initial;
    }
    private static void Consider(SearchContext ctx, Individual candidate, ref Individual best)
    {
        if (candidate == null || candidate.E == null || !candidate.E.Complete) return;
        if (Compare(ctx, candidate.E, best.E) < 0) best = candidate;
        ctx.RecordBest(best.E);
    }
    private static Individual Evaluate(SearchContext ctx, Schedule s, bool trace, Counters c)
    {
        if (s == null || !CanEvaluate(ctx) || !ctx.Budget.Propose()) return null;
        var e = ctx.Evaluate(s, trace);
        if (e == null || !e.Complete) return null;
        c.FullCandidates++; return new Individual(s, e);
    }
    private static int Weighted(Random random, IReadOnlyList<double> weights)
    {
        double sum = 0; for (int i = 0; i < weights.Count; i++) sum += Math.Max(0, weights[i]);
        if (sum <= 0 || !double.IsFinite(sum)) return random.Next(weights.Count);
        double r = random.NextDouble() * sum;
        for (int i = 0; i < weights.Count; i++) if ((r -= Math.Max(0, weights[i])) <= 0) return i;
        return weights.Count - 1;
    }
    private static int TailTask(Evaluation e, Sensitivity sensitivity, int n, Random random)
    {
        var values = sensitivity?.TaskTail ?? e.TaskTail;
        return values == null || values.Length != n ? random.Next(n) : Weighted(random, values);
    }
    private static Individual Genetic(SearchContext ctx, SearchConfig cfg, Random random, Counters c)
    {
        var best = Initial(ctx, false, c); var population = new List<Individual> { best };
        int size = Math.Max(4, cfg.Population);
        while (population.Count < size && CanEvaluate(ctx))
        {
            Schedule s = population.Count < 4
                ? Model.InitialSchedule(ctx.Ins, random.Next())
                : Moves.RandomMutation(ctx.Ins, population[random.Next(population.Count)].S, random, true);
            var x = Evaluate(ctx, s, false, c); if (x == null) continue;
            population.Add(x); Consider(ctx, x, ref best);
        }
        Individual Tournament()
        {
            var x = population[random.Next(population.Count)];
            for (int i = 1; i < 3; i++)
            { var y = population[random.Next(population.Count)]; if (Compare(ctx, y.E, x.E) < 0) x = y; }
            return x;
        }
        while (CanEvaluate(ctx))
        {
            population = population.OrderBy(x => x, Comparer<Individual>.Create((a, b) => Compare(ctx, a.E, b.E))).ToList();
            // Leave at least one offspring slot even for the minimum supported
            // population; otherwise an all-elite generation consumes no budget.
            var next = population.Take(Math.Min(size - 1, Math.Min(4, population.Count))).ToList();
            var generationKeys = next.Select(x => x.S.Key()).ToHashSet();
            while (next.Count < size && CanEvaluate(ctx))
            {
                var s = Moves.Crossover(ctx.Ins, Tournament().S, Tournament().S, random);
                if (random.NextDouble() < cfg.MutationProbability)
                    s = Moves.RandomMutation(ctx.Ins, s, random, random.NextDouble() < .3) ?? s;
                if (!generationKeys.Add(s.Key()))
                { if (!ctx.Budget.Propose()) break; continue; }
                var x = Evaluate(ctx, s, false, c); if (x == null) continue;
                next.Add(x); Consider(ctx, x, ref best);
            }
            if (next.Count == 0) break;
            population = next; c.CompletedRounds++;
        }
        return best;
    }
    private static List<int> RemoveSet(SearchContext ctx, Individual current, int count, int op, Random random)
    {
        var tasks = Enumerable.Range(0, ctx.Ins.N).ToArray();
        if (op == 0) return tasks.OrderBy(_ => random.Next()).Take(count).ToList();
        if (op == 1)
        {
            int seed = TailTask(current.E, null, ctx.Ins.N, random);
            int agv = Moves.Locate(current.S.A, seed).Resource;
            return tasks.OrderByDescending(t =>
                (ctx.Ins.Tasks[t].Y == ctx.Ins.Tasks[seed].Y ? 2 : 0) +
                (ctx.Ins.Tasks[t].Q == ctx.Ins.Tasks[seed].Q ? 1 : 0) +
                (Array.IndexOf(current.S.A[agv], t) >= 0 ? 1 : 0) + .5 * random.NextDouble()).Take(count).ToList();
        }
        return tasks.OrderByDescending(t => (current.E.TaskTail != null ? current.E.TaskTail[t] : 1) *
                     (.8 + .4 * random.NextDouble())).Take(count).ToList();
    }
    private static Individual AdaptiveLns(SearchContext ctx, SearchConfig cfg, Random random, Counters c)
    {
        var best = Initial(ctx, false, c); var current = best;
        double temperature = cfg.InitialTemperature * Math.Max(1, Math.Abs(Merit(ctx, current.E)));
        while (CanEvaluate(ctx))
        {
            int destroy = Weighted(random, c.DestroyWeights), repair = Weighted(random, c.RepairWeights);
            c.DestroyUses[destroy]++; c.RepairUses[repair]++;
            int count = Math.Min(ctx.Ins.N - 1, Math.Max(2, (int)Math.Ceiling(cfg.RemovalFraction * ctx.Ins.N)));
            var pending = RemoveSet(ctx, current, count, destroy, random).ToHashSet();
            var working = current; var oldBest = best;
            while (pending.Count > 0 && CanEvaluate(ctx))
            {
                var taskChoices = pending.OrderBy(_ => random.Next()).Take(repair == 0 ? 1 : 3).ToArray();
                int selectedTask = taskChoices[0]; Individual selected = null;
                double largestRegret = double.NegativeInfinity;
                foreach (int task in taskChoices)
                {
                    var trials = new List<Individual>();
                    for (int trial = 0; trial < Math.Max(2, cfg.RepairTrials) && CanEvaluate(ctx); trial++)
                    {
                        var s = Moves.RepairProposal(ctx.Ins, working.S, pending, task, random);
                        if (s == null) { if (!ctx.Budget.Propose()) break; continue; }
                        if (s.Key() == working.S.Key()) { if (!ctx.Budget.Propose()) break; continue; }
                        c.RepairLookaheads++;
                        var x = Evaluate(ctx, s, false, c); if (x == null) continue;
                        trials.Add(x); Consider(ctx, x, ref best);
                    }
                    if (trials.Count == 0) continue;
                    trials.Sort((a, b) => Compare(ctx, a.E, b.E));
                    double regret = trials.Count > 1 ? Merit(ctx, trials[1].E) - Merit(ctx, trials[0].E) : 0;
                    if (selected == null || regret > largestRegret ||
                        (regret == largestRegret && Compare(ctx, trials[0].E, selected.E) < 0))
                    { selected = trials[0]; selectedTask = task; largestRegret = regret; }
                }
                // A failed repair leaves its last complete plan unchanged. No partial
                // chain is submitted to the objective, even at budget exhaustion.
                if (selected != null) working = selected;
                pending.Remove(selectedTask);
            }
            bool improvement = Compare(ctx, working.E, current.E) < 0;
            double delta = Merit(ctx, working.E) - Merit(ctx, current.E);
            bool changed = working.S.Key() != current.S.Key();
            bool accept = changed && (improvement || random.NextDouble() < Math.Exp(-Math.Max(0, delta) / Math.Max(1e-9, temperature)));
            if (accept) { current = working; c.Accepted++; }
            double reward = Compare(ctx, best.E, oldBest.E) < 0 ? 5 : improvement ? 2 : accept ? 1 : 0;
            // Per-use reaction guarantees actual adaptation under finite budgets.
            double reaction = Math.Clamp(cfg.Reaction, .001, 1);
            c.DestroyWeights[destroy] = (1 - reaction) * c.DestroyWeights[destroy] + reaction * (.05 + reward);
            c.RepairWeights[repair] = (1 - reaction) * c.RepairWeights[repair] + reaction * (.05 + reward);
            c.AdaptiveUpdates++; c.CompletedRounds++; temperature *= .995;
        }
        return best;
    }
    private static bool IsAblation(SearchConfig cfg, string name) => string.Equals(cfg.Ablation, name, StringComparison.OrdinalIgnoreCase);
    private static int[] ActiveAncestors(SearchContext ctx, Individual current, int tail, bool yard)
    {
        var graph = current.E.Graph; var times = current.E.Times;
        if (graph == null || times == null || times.Length == 0) return Moves.DirectPredecessors(current.S, tail).ToArray();
        if (!ctx.Budget.Available(2L * graph.Nodes)) return Array.Empty<int>();
        int ready = 10 * tail + (yard ? 6 : 1), arrival = 10 * tail + (yard ? 5 : 2);
        int scenario = 0;
        for (int k = 1; k < times.Length; k++)
            if (times[k][ready] - times[k][arrival] > times[scenario][ready] - times[scenario][arrival]) scenario = k;
        var t = times[scenario]; var frame = ctx.Bank.Frames[scenario];
        var seen = new bool[graph.Nodes]; var tasks = new HashSet<int>(); var queue = new Stack<int>(); queue.Push(ready);
        while (queue.Count > 0)
        {
            int node = queue.Pop(); if (node == graph.Source || seen[node]) continue;
            seen[node] = true; int task = node / 10; if (task != tail) tasks.Add(task);
            foreach (var edge in new[] { (graph.P1[node], graph.W1[node]), (graph.P2[node], graph.W2[node]) })
            {
                if (edge.Item1 < 0) continue; ctx.Budget.Charge(1);
                if (Math.Abs(t[edge.Item1] + frame[edge.Item2] - t[node]) <= 1e-8 * Math.Max(1, Math.Abs(t[node])))
                    queue.Push(edge.Item1);
            }
        }
        return tasks.OrderBy(x => x).ToArray();
    }
    private static List<(int First, int Second, int Layer)> CriticalArcs(SearchContext ctx, Individual current, Random random)
    {
        var result = new List<(int, int, int)>(); var graph = current.E.Graph; var times = current.E.Times;
        if (graph == null || times == null || times.Length == 0 || !ctx.Budget.Available(2L * graph.Nodes)) return result;
        // Conventional makespan-critical blocks. The full risk objective, not
        // makespan, ranks the resulting complete neighbors.
        var cmax = times.Select(t => Enumerable.Range(0, ctx.Ins.N).Max(i => t[10 * i + 9])).ToArray();
        int scenario = Weighted(random, Kernel.TailWeights(cmax));
        var t = times[scenario]; var frame = ctx.Bank.Frames[scenario];
        int node = Enumerable.Range(0, ctx.Ins.N).OrderByDescending(i => t[10 * i + 9]).First() * 10 + 9;
        while (node != graph.Source)
        {
            int parent = -1; double value = double.NegativeInfinity;
            foreach (var edge in new[] { (graph.P1[node], graph.W1[node]), (graph.P2[node], graph.W2[node]) })
            {
                if (edge.Item1 < 0) continue; ctx.Budget.Charge(1);
                double v = t[edge.Item1] + frame[edge.Item2];
                if (v > value || (v == value && random.Next(2) == 0)) { value = v; parent = edge.Item1; }
            }
            if (parent < 0 || parent == graph.Source) break;
            int eventIndex = node % 10;
            if (eventIndex is 0 or 2 or 6)
                result.Add((parent / 10, node / 10, eventIndex == 0 ? 0 : eventIndex == 2 ? 1 : 2));
            node = parent;
        }
        return result;
    }
    private static Individual Tabu(SearchContext ctx, SearchConfig cfg, Random random, Counters c, bool critical)
    {
        var best = Initial(ctx, true, c); var current = best;
        if (current.E.Times == null || current.E.Graph == null) return best;
        var tabu = new Dictionary<string, int>(); int iteration = 0;
        while (CanEvaluate(ctx))
        {
            iteration++; Sensitivity sensitivity = null;
            var criticalArcs = new List<(int First, int Second, int Layer)>();
            if (critical) criticalArcs = CriticalArcs(ctx, current, random);
            else { sensitivity = ctx.Differentiate(current.E); if (sensitivity == null) break; }
            var ancestorCache = new Dictionary<(int, bool), int[]>();
            var seen = new HashSet<string> { current.S.Key() }; var candidates = new List<Candidate>();
            int pool = Math.Max(1, cfg.Pool);
            for (int attempt = 0; attempt < 4 * pool && candidates.Count < pool && CanEvaluate(ctx); attempt++)
            {
                if (!ctx.Budget.Propose()) break;
                Schedule schedule;
                if (critical)
                {
                    if (criticalArcs.Count > 0)
                    {
                        var arc = criticalArcs[random.Next(criticalArcs.Count)];
                        if (random.NextDouble() < .5) schedule = Moves.Swap(ctx.Ins, current.S, arc.Layer, arc.First, arc.Second);
                        else schedule = Moves.MoveTask(ctx.Ins, current.S, arc.Layer, random.Next(2) == 0 ? arc.First : arc.Second, random);
                    }
                    else schedule = Moves.RandomMutation(ctx.Ins, current.S, random);
                    c.SingleCandidates++;
                }
                else if (random.NextDouble() > cfg.GuidedProbability)
                {
                    bool single = IsAblation(cfg, "single-chain") || random.NextDouble() < .5;
                    schedule = Moves.RandomMutation(ctx.Ins, current.S, random, !single);
                    if (single) c.SingleCandidates++; else c.JointCandidates++;
                }
                else
                {
                    int tail = TailTask(current.E, sensitivity, ctx.Ins.N, random);
                    double q = sensitivity.TaskQTail?[tail] ?? 0, y = sensitivity.TaskYTail?[tail] ?? 0;
                    bool yard = q + y > 0 ? random.NextDouble() < y / (q + y) : random.Next(2) == 0;
                    int[] upstream;
                    if (IsAblation(cfg, "tail-only")) upstream = Moves.DirectPredecessors(current.S, tail).ToArray();
                    else
                    {
                        if (!ancestorCache.TryGetValue((tail, yard), out upstream))
                        { upstream = ActiveAncestors(ctx, current, tail, yard); ancestorCache[(tail, yard)] = upstream; }
                        c.UpstreamSelections++;
                    }
                    int blocker = upstream.Length == 0 ? tail : upstream[Weighted(random,
                        upstream.Select(i => IsAblation(cfg, "tail-only") ? 1 :
                            Math.Abs(sensitivity.TaskInfluence?[i] ?? 1)).ToArray())];
                    bool single = IsAblation(cfg, "single-chain") || random.NextDouble() < .5;
                    schedule = Moves.Joint(ctx.Ins, current.S, tail, blocker, yard, random, single);
                    if (single) c.SingleCandidates++; else c.JointCandidates++;
                }
                if (schedule == null) continue;
                string key = schedule.Key(); if (!seen.Add(key)) continue;
                var graph = ctx.Build(schedule); if (graph == null) continue;
                double score;
                if (critical || IsAblation(cfg, "no-residual")) score = random.NextDouble();
                else
                { score = ctx.ScoreCandidate(graph, current.E, sensitivity); c.ResidualScores++; if (!double.IsFinite(score)) break; }
                candidates.Add(new Candidate { S = schedule, G = graph, Key = key, Score = score, Index = candidates.Count });
                c.PoolCandidates++;
            }
            // A sampled empty neighborhood is not a proof that no move exists.
            // Continue under the same work/proposal/time limits.
            if (candidates.Count == 0) { c.EmptyNeighborhoodRounds++; continue; }
            var ranked = candidates.OrderBy(x => x.Score).ThenBy(x => x.Index);
            int shortlist = critical ? candidates.Count : Math.Max(1, cfg.Shortlist);
            Individual chosen = null;
            foreach (var candidate in ranked.Take(shortlist))
            {
                if (!CanEvaluate(ctx)) break;
                var e = ctx.Evaluate(candidate.S, candidate.G, true); if (e == null || !e.Complete) continue;
                c.FullCandidates++; var x = new Individual(candidate.S, e);
                bool aspiration = Compare(ctx, e, best.E) < 0;
                Consider(ctx, x, ref best); // Preserve the last evaluated improvement.
                if (tabu.TryGetValue(candidate.Key, out int until) && until > iteration && !aspiration)
                { c.TabuRejected++; continue; }
                if (chosen == null || Compare(ctx, e, chosen.E) < 0)
                { chosen = x; }
            }
            // All shortlisted states may still be tabu. Advance the iteration so
            // finite tenures can expire instead of terminating the whole search.
            if (chosen == null) { c.AllTabuRounds++; continue; }
            tabu[current.S.Key()] = iteration + Math.Max(1, cfg.Tenure);
            current = chosen; c.Accepted++; c.CompletedRounds++;
            if (iteration % 20 == 0)
                foreach (var key in tabu.Where(x => x.Value <= iteration).Select(x => x.Key).ToArray()) tabu.Remove(key);
        }
        return best;
    }
}
