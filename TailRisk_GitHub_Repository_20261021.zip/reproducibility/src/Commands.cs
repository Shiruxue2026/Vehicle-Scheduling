using System.Security.Cryptography;
using System.Diagnostics;
namespace TailRisk;

public sealed class ReferenceRecord {
    public string InstanceId;
    public Schedule Schedule;
    public double Cmax,Empty,Seconds;
    public long Work;
    public int[] Seeds;
    public int CandidateRuns;
}
public static class Commands {
    public static readonly int[] Sizes={24,48,96,192};
    public static string Repro(string root)=>Path.Combine(root,"reproducibility");
    public static string Data(string root,string split)=>Path.Combine(Repro(root),"data",split);
    public static string Results(string root,string phase)=>Path.Combine(Repro(root),"results",phase);
    static int Int(Dictionary<string,string> o,string k,int d)=>int.Parse(o.GetValueOrDefault(k,d.ToString()));
    public static SearchConfig Copy(SearchConfig x)=>System.Text.Json.JsonSerializer.Deserialize<SearchConfig>(System.Text.Json.JsonSerializer.Serialize(x,JsonIO.Compact),JsonIO.Options);
    public static string ReferencePath(string root,Instance ins)=>Path.Combine(Data(root,ins.Split),ins.Id+"_reference.json");
    public static List<Instance> Instances(string root,string split,int first,int last,int[] sizes=null)=> (sizes??Sizes).SelectMany(n=>Enumerable.Range(first,last-first+1).Select(i=>LoadInstance(root,n,i,split))).ToList();
    public static Instance LoadInstance(string root,int n,int i,string split){string path=Path.Combine(Data(root,split),$"{split}_N{n}_I{i:00}.json");if(File.Exists(path))return JsonIO.Read<Instance>(path);throw new FileNotFoundException("Prepare instances first",path);}
    static ReferenceRecord BuildReference(Instance ins,string outdir){
        var watch=Stopwatch.StartNew();var bank=Model.MakeBank(ins,0,0,0);Schedule best=null;Evaluation be=null;
        for(int construction=0;construction<4;construction++){
            int[] order=construction switch{0=>Enumerable.Range(0,ins.N).ToArray(),1=>Enumerable.Range(0,ins.N).OrderBy(i=>ins.Tasks[i].Q).ThenBy(i=>ins.Tasks[i].Y).ToArray(),2=>Enumerable.Range(0,ins.N).OrderBy(i=>ins.Tasks[i].Y).ThenBy(i=>ins.Tasks[i].Q).ToArray(),_=>Enumerable.Range(0,ins.N).OrderBy(i=>ins.Tasks[i].PQ+ins.Tasks[i].PY+ins.Loaded(i)).ToArray()};
            int[] aa=new int[ins.N];for(int j=0;j<order.Length;j++)aa[order[j]]=j%ins.An;
            var s=Model.Priority(ins,order,aa);var e=Kernel.Nominal(ins,s);if(be==null||e.NomCmax<be.NomCmax||(e.NomCmax==be.NomCmax&&e.Empty<be.Empty)){best=s;be=e;}
        }
        var initial=best.Clone();long work=0;var seeds=Enumerable.Range(1,5).Select(k=>Model.Seed($"anchor|{ins.Id}|{k}")).ToArray();
        for(int k=0;k<5;k++){
            var ctx=SearchContext.Create(ins,bank,initial,36L*ins.N*(2000L+100L*ins.N),0,true);
            var r=Solvers.Run(ctx,new SearchConfig{Id="reference-ga",Method="GA",Population=32,MutationProbability=.5},seeds[k]);r.Phase="reference";work+=r.Work;
            JsonIO.Save(Path.Combine(outdir,ins.Id+$"_anchor{k+1}.json"),r);
            if(r.Evaluation.NomCmax<be.NomCmax||(r.Evaluation.NomCmax==be.NomCmax&&r.Evaluation.Empty<be.Empty)){best=r.Schedule;be=r.Evaluation;}
        }
        return new(){InstanceId=ins.Id,Schedule=best,Cmax=be.NomCmax,Empty=be.Empty,Seconds=watch.Elapsed.TotalSeconds,Work=work,Seeds=seeds,CandidateRuns=9};
    }
    public static void Prepare(string root,Dictionary<string,string> options){
        string split=options.GetValueOrDefault("split","development");int count=Int(options,"instances",split=="test"?30:10),workers=Int(options,"workers",4);
        if(split=="test")VerifyFreeze(root);
        var jobs=Sizes.SelectMany(n=>Enumerable.Range(1,count).Select(i=>(n,i))).ToArray();int done=0;
        Parallel.ForEach(jobs,new ParallelOptions{MaxDegreeOfParallelism=workers},job=>{
            var ins=Model.Generate(job.n,job.i,split);string path=Path.Combine(Data(root,split),ins.Id+".json");
            if(!File.Exists(path))JsonIO.Save(path,ins);else {var saved=JsonIO.Read<Instance>(path);if(System.Text.Json.JsonSerializer.Serialize(ins,JsonIO.Compact)!=System.Text.Json.JsonSerializer.Serialize(saved,JsonIO.Compact))throw new InvalidOperationException("Archived instance differs from deterministic generator: "+ins.Id);ins=saved;}
            string rp=ReferencePath(root,ins);if(!File.Exists(rp))JsonIO.Save(rp,BuildReference(ins,Path.Combine(Results(root,"reference"),"runs")));
            Console.WriteLine($"prepared {Interlocked.Increment(ref done)}/{jobs.Length}: {ins.Id}");
        });
    }
    public static List<SearchConfig> Grid(){
        var list=new List<SearchConfig>();
        int[][] ts={new[]{128,24,7,80},new[]{64,16,7,80},new[]{128,16,7,80},new[]{128,32,7,80},new[]{128,24,12,80},new[]{128,24,7,60},new[]{256,24,7,80},new[]{128,48,7,80}};
        for(int i=0;i<ts.Length;i++)list.Add(new(){Id=$"TS-JS_c{i:00}",Method="TS-JS",Pool=ts[i][0],Shortlist=ts[i][1],Tenure=ts[i][2],GuidedProbability=ts[i][3]/100.0});
        int k=0;foreach(int pop in new[]{16,32,64,96})foreach(double mutation in new[]{.25,.5})list.Add(new(){Id=$"GA_c{k++:00}",Method="GA",Population=pop,MutationProbability=mutation});
        k=0;foreach(double removal in new[]{.04,.08,.12,.16})foreach(double reaction in new[]{.1,.3})list.Add(new(){Id=$"ALNS_c{k++:00}",Method="ALNS",RemovalFraction=removal,Reaction=reaction});
        k=0;foreach(int pool in new[]{16,32,64,128})foreach(int tenure in new[]{7,12})list.Add(new(){Id=$"CB-TS_c{k++:00}",Method="CB-TS",Pool=pool,Tenure=tenure});
        return list;
    }
    public static void RunJobs(string root,string phase,List<Instance> instances,List<SearchConfig> configs,int seeds,int workers,double fraction=1,Dictionary<int,double> seconds=null,bool nominal=false,int trainingCount=64){
        var manifest=RunIntegrity.EnsureRunSet(root,phase,instances,configs,seeds,fraction,seconds,nominal,trainingCount);
        string outdir=Path.Combine(Results(root,phase),"runs");Directory.CreateDirectory(outdir);int done=0,total=instances.Count*configs.Count*seeds;
        Parallel.ForEach(instances,new ParallelOptions{MaxDegreeOfParallelism=workers},ins=>{
            var bank=Model.MakeBank(ins,trainingCount,.2,Model.Seed($"train|{ins.Id}"));var reference=JsonIO.Read<ReferenceRecord>(ReferencePath(root,ins));
            foreach(var cfg in configs)for(int k=1;k<=seeds;k++){
                int seed=Model.Seed($"algorithm|{ins.Id}|{k}");string path=Path.Combine(outdir,$"{ins.Id}_{cfg.Id}_S{k}.json");
                if(!File.Exists(path)){
                    double timeLimit=seconds?.GetValueOrDefault(ins.N)??0;
                    if(timeLimit>0){GC.Collect();GC.WaitForPendingFinalizers();}
                    var ctx=SearchContext.Create(ins,bank,reference.Schedule,timeLimit>0?long.MaxValue/4:(long)(SearchContext.MainBudget(ins.N)*fraction),timeLimit,nominal);
                    var result=Solvers.Run(ctx,cfg,seed);result.Phase=phase;
                    if(!result.Evaluation.Feasible||!result.Evaluation.Complete)throw new InvalidOperationException("Solver failed to return feasible incumbent");
                    RunIntegrity.SaveCompletedRun(manifest,result,path);
                }else RunIntegrity.ValidateExistingRun(manifest,path);
                Console.WriteLine($"{phase}: {Interlocked.Increment(ref done)}/{total} completed {ins.Id}/{cfg.Id}/S{k}");
            }
        });
        int verified=RunIntegrity.CheckComplete(manifest);
        JsonIO.Save(Path.Combine(Results(root,phase),"completion.json"),new{Phase=phase,Expected=total,Files=verified,FinishedUtc=DateTime.UtcNow.ToString("O")});
    }
    public static void Develop(string root,Dictionary<string,string> options){
        int round=Int(options,"round",1);if(round<1||round>3)throw new ArgumentException("At most three development rounds");
        string stage=options.GetValueOrDefault("stage","tune"),phase=$"dev_r{round}_{stage}";
        if(File.Exists(Path.Combine(Repro(root),"configs","freeze.json")))throw new InvalidOperationException("Development closed by freeze");
        if(stage=="tune"){
            string cfgpath=Path.Combine(Repro(root),"configs",$"grid_r{round}.json");var cfg=File.Exists(cfgpath)?JsonIO.Read<List<SearchConfig>>(cfgpath):Grid();if(!File.Exists(cfgpath))JsonIO.Save(cfgpath,cfg);
            RunJobs(root,phase,Instances(root,"development",1,5),cfg,2,Int(options,"workers",4),.5);
        }else{
            var cfg=JsonIO.Read<List<SearchConfig>>(Path.Combine(Repro(root),"configs",$"shortlist_r{round}.json"));
            RunJobs(root,phase,Instances(root,"development",6,10),cfg,5,Int(options,"workers",4));
        }
    }
    public static void Select(string root,Dictionary<string,string> options){
        int round=Int(options,"round",1);string stage=options.GetValueOrDefault("stage","tune");
        RunIntegrity.VerifyRunSet(root,$"dev_r{round}_{stage}");
        var runs=Directory.GetFiles(Path.Combine(Results(root,$"dev_r{round}_{stage}"),"runs"),"*.json").Select(JsonIO.Read<RunResult>).ToList();
        var grid=JsonIO.Read<List<SearchConfig>>(Path.Combine(Repro(root),"configs",$"grid_r{round}.json"));
        var independent=new Dictionary<(string,int),Dictionary<string,string>>();
        if(stage!="tune"){
            string replay=Path.Combine(Results(root,$"dev_r{round}_{stage}"),"replay_plan.csv");
            if(!File.Exists(replay))throw new InvalidOperationException("Replay the development selection plans before choosing final configurations");
            var lines=File.ReadAllLines(replay);var headers=lines[0].Split(',');
            foreach(string line in lines.Skip(1)){var values=line.Split(',');var row=headers.Select((h,j)=>(h,j)).ToDictionary(x=>x.h,x=>values[x.j]);if(double.Parse(row["CV"])==.2&&double.Parse(row["Rho"])==0)independent[(row["InstanceId"]+"|"+row["ConfigId"],int.Parse(row["Seed"]))]=row;}
        }
        double Score(RunResult x)=>stage=="tune"?x.Evaluation.Risk/x.ReferenceCmax:double.Parse(independent[(x.InstanceId+"|"+x.ConfigId,x.Seed)]["WaitCVaR"])/x.ReferenceCmax;
        double Guard(RunResult x){if(stage=="tune")return 0;var row=independent[(x.InstanceId+"|"+x.ConfigId,x.Seed)];return(double.Parse(row["CmaxCVaR"])-double.Parse(row["ReferenceReplayCvarCmax"]))/x.ReferenceCmax;}
        var ranking=runs.GroupBy(x=>new{x.Method,x.ConfigId}).Select(g=>new{g.Key.Method,g.Key.ConfigId,Count=g.Count(),Score=g.GroupBy(x=>x.InstanceId).Average(h=>h.Average(Score)),GuardExcess=Math.Max(0,g.GroupBy(x=>x.InstanceId).Average(h=>h.Average(Guard))-.01),Eligible=g.GroupBy(x=>x.InstanceId).Average(h=>h.Average(Guard))<=.01,Seconds=g.Average(x=>x.Seconds),Work=g.Average(x=>(double)x.Work)}).OrderBy(x=>x.Method).ThenBy(x=>x.GuardExcess).ThenBy(x=>x.Score).ThenBy(x=>x.ConfigId,StringComparer.Ordinal).ToList();
        JsonIO.Save(Path.Combine(Results(root,$"dev_r{round}_{stage}"),"ranking.json"),ranking);
        var selected=ranking.GroupBy(x=>x.Method).SelectMany(g=>g.Take(stage=="tune"?2:1)).Select(x=>grid.Single(c=>c.Id==x.ConfigId)).ToList();
        JsonIO.Save(Path.Combine(Repro(root),"configs",stage=="tune"?$"shortlist_r{round}.json":"selected.json"),selected);
        if(stage!="tune")JsonIO.Save(Path.Combine(Repro(root),"configs","selection_audit.json"),new{Stage=stage,Round=round,Rule="Training risk shortlists two configurations per method; independent development CV=.20 replay selects the final configuration. Feasible guard first, then normalized waiting CVaR, then ordinal configuration id.",FallbackMethods=ranking.GroupBy(x=>x.Method).Where(g=>!g.Any(x=>x.Eligible)).Select(g=>g.Key).ToArray(),Fallback="If every candidate exceeds the development mean completion-risk margin, select the smallest excess, explicitly retain that failure, and do not claim development guard compliance."});
        Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(ranking,JsonIO.Options));
    }
    public static List<SearchConfig> Selected(string root)=>JsonIO.Read<List<SearchConfig>>(Path.Combine(Repro(root),"configs","selected.json"));
    static Dictionary<string,string> HashFiles(string root){
        var repro=Repro(root);var files=Directory.GetFiles(Path.Combine(repro,"src"),"*.cs").Append(Path.Combine(repro,"TailRisk.csproj")).Concat(new[]{"selected.json","timing.json","protocol.json","selection_audit.json"}.Select(f=>Path.Combine(repro,"configs",f))).Concat(new[]{"analyze.py","package_audit.py","test_analysis.py","paper_assets.py","development_summary.py","requirements.txt","run_analysis.py"}.Select(f=>Path.Combine(root,"analysis",f)));
        return files.ToDictionary(f=>Path.GetRelativePath(root,f).Replace('\\','/'),f=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(f))).ToLowerInvariant());
    }
    public static void Freeze(string root,Dictionary<string,string> options){
        string path=Path.Combine(Repro(root),"configs","freeze.json");if(File.Exists(path))throw new InvalidOperationException("Already frozen");
        PreFreezeAudit.Verify(root);
        JsonIO.Save(Path.Combine(Repro(root),"configs","protocol.json"),new{Version="tailrisk-v3.0",FrozenUtc=DateTime.UtcNow.ToString("O"),Sizes,InstancesPerSize=30,AlgorithmSeeds=5,TrainCount=64,TrainCV=.20,TestScenariosPerCV=1000,TestCV=new[]{.10,.20},Primary="TS-JS versus ALNS at CV=0.20, joint task-scenario CVaR95, instance-unit inference",Target=.05,CmaxMargin=.01,EmptyMargin=.01,Work="15N(32768+1024N)",Generator="fixed QC/YC service points; [0,8]x[0,4]; L1 travel; loaded speed1 empty speed1.5; all active resources nonempty",TimingCalibration="three development instances per large size x two paired seeds; median of method median single-core times, ceiling 5s and clamped96:10..120,192:20..240",BootstrapSeed=202610101});
        JsonIO.Save(path,HashFiles(root));
        Console.WriteLine("Frozen source, selected configurations, timing budgets and analysis.");
    }
    public static void VerifyFreeze(string root){var expected=JsonIO.Read<Dictionary<string,string>>(Path.Combine(Repro(root),"configs","freeze.json"));var actual=HashFiles(root);if(!actual.Keys.ToHashSet().SetEquals(expected.Keys))throw new InvalidOperationException("Frozen source file set changed");foreach(var p in expected)if(actual[p.Key]!=p.Value)throw new InvalidOperationException("Frozen file changed: "+p.Key);}
    public static void MainStudy(string root,Dictionary<string,string> options){VerifyFreeze(root);RunJobs(root,"main",Instances(root,"test",1,30),Selected(root),5,Int(options,"workers",4));}
    public static void TrainingSensitivity(string root,Dictionary<string,string> options){
        if(File.Exists(Path.Combine(Repro(root),"configs","freeze.json")))throw new InvalidOperationException("Development closed by freeze");
        foreach(int k in new[]{32,128})RunJobs(root,$"dev_trainingK{k}",Instances(root,"development",6,10),Selected(root),2,Int(options,"workers",4),trainingCount:k);
    }
    public static void Ablation(string root,Dictionary<string,string> options){VerifyFreeze(root);var original=Selected(root).Single(x=>x.Method=="TS-JS");var configs=new List<SearchConfig>();foreach(string a in new[]{"tail-only","no-residual","single-chain"}){var cfg=Copy(original);cfg.Ablation=a;cfg.Id="TS-JS_"+a;cfg.Method="TS-JS";configs.Add(cfg);}RunJobs(root,"ablation",Instances(root,"test",1,10,new[]{96,192}),configs,5,Int(options,"workers",4));}
    // Both entry points enforce Windows/Linux before accessing affinity. The
    // analyzer does not retain that guard across the restoration finally block.
#pragma warning disable CA1416
    public static void Calibrate(string root,Dictionary<string,string> options){
        if(!OperatingSystem.IsWindows()&&!OperatingSystem.IsLinux())throw new PlatformNotSupportedException("CPU-affinity timing requires Windows or Linux");
        using var process=Process.GetCurrentProcess();var old=process.ProcessorAffinity;process.ProcessorAffinity=(nint)1;
        string startedUtc=DateTime.UtcNow.ToString("O");
        try{WarmSearch();RunJobs(root,"calibration",Instances(root,"development",6,8,new[]{96,192}),Selected(root),2,1);
            JsonIO.Save(Path.Combine(Results(root,"calibration"),"calibration_environment.json"),new{Workers=1,ProcessorAffinity=(long)process.ProcessorAffinity,WarmupCompleted=true,NoConcurrentStudyExperiments=true,Exclusivity="Named mutex prevents concurrent study CLI experiment commands; operating-system and unrelated application activity are not disabled",StartedUtc=startedUtc,FinishedUtc=DateTime.UtcNow.ToString("O"),Machine=Environment.MachineName});
        }finally{process.ProcessorAffinity=old;}
        var runs=Directory.GetFiles(Path.Combine(Results(root,"calibration"),"runs"),"*.json").Select(JsonIO.Read<RunResult>).ToArray();
        double Median(IEnumerable<double> a){var z=a.Order().ToArray();return(z[(z.Length-1)/2]+z[z.Length/2])/2;}
        var timing=new Dictionary<int,double>();foreach(int n in new[]{96,192}){double t=Median(runs.Where(x=>x.N==n).GroupBy(x=>x.Method).Select(g=>Median(g.Select(x=>x.Seconds))));timing[n]=Math.Clamp(5*Math.Ceiling(t/5),n==96?10:20,n==96?120:240);}
        JsonIO.Save(Path.Combine(Repro(root),"configs","timing.json"),timing);Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(timing));
    }
    public static void Timing(string root,Dictionary<string,string> options){if(!OperatingSystem.IsWindows()&&!OperatingSystem.IsLinux())throw new PlatformNotSupportedException("CPU-affinity timing requires Windows or Linux");VerifyFreeze(root);using var process=Process.GetCurrentProcess();var old=process.ProcessorAffinity;process.ProcessorAffinity=(nint)1;try{WarmSearch();RunJobs(root,"timing",Instances(root,"test",1,10,new[]{96,192}),Selected(root),5,1,100,JsonIO.Read<Dictionary<int,double>>(Path.Combine(Repro(root),"configs","timing.json")));}finally{process.ProcessorAffinity=old;}}
#pragma warning restore CA1416
    static void WarmSearch(){
        var ins=Model.Generate(24,1,"timing-warmup");var bank=Model.MakeBank(ins,64,.2,19);var reference=Model.InitialSchedule(ins,19);
        foreach(string method in new[]{"TS-JS","GA","ALNS","CB-TS"})Solvers.Run(SearchContext.Create(ins,bank,reference,SearchContext.MainBudget(24)/10),new SearchConfig{Id="warmup",Method=method},12345);
        GC.Collect();GC.WaitForPendingFinalizers();
    }
    public static void Smoke(string root){
        var ins=Model.Generate(24,1,"smoke");var bank=Model.MakeBank(ins,64,.2,Model.Seed("smoke-train"));var reference=Model.InitialSchedule(ins,19);string dir=Path.Combine(root,"reports","smoke");
        foreach(string method in new[]{"TS-JS","GA","ALNS","CB-TS"}){var cfg=new SearchConfig{Method=method,Id="smoke-"+method};var c=SearchContext.Create(ins,bank,reference,SearchContext.MainBudget(24)/10);var run=Solvers.Run(c,cfg,12345);JsonIO.Save(Path.Combine(dir,method+".json"),run);Console.WriteLine($"{method}: risk={run.Evaluation.Risk:F6} ref={c.ReferenceEval.Risk:F6} feasible={run.Evaluation.Feasible} work={run.Work}/{run.Limit} seconds={run.Seconds:F3}");}
    }
}
