namespace TailRisk;

public static class Kernel {
    public static Graph Build(Instance ins,Schedule s,out long visits){
        visits=0;int n=ins.N;
        if(s==null||s.Q==null||s.A==null||s.Y==null||s.Q.Length!=ins.Qn||s.A.Length!=ins.An||s.Y.Length!=ins.Yn)return null;
        foreach(var group in new[]{s.Q,s.A,s.Y}){var seen=new bool[n];foreach(var chain in group){if(chain==null||chain.Length==0)return null;foreach(int i in chain){if(i<0||i>=n||seen[i])return null;seen[i]=true;}}if(seen.Any(x=>!x))return null;}
        for(int q=0;q<s.Q.Length;q++)foreach(int i in s.Q[q])if(ins.Tasks[i].Q!=q)return null;
        for(int y=0;y<s.Y.Length;y++)foreach(int i in s.Y[y])if(ins.Tasks[i].Y!=y)return null;
        int nodes=10*n+1,source=10*n,zero=5*n+n*n+ins.An*n;
        var g=new Graph{N=n,Nodes=nodes,Source=source,P1=Enumerable.Repeat(-1,nodes).ToArray(),P2=Enumerable.Repeat(-1,nodes).ToArray(),W1=new int[nodes],W2=new int[nodes],Topo=new int[nodes]};
        int[] head=Enumerable.Repeat(-1,nodes).ToArray(),to=new int[12*n],next=new int[12*n],degree=new int[nodes];int count=0;
        void edge(int u,int v,int w){if(g.P1[v]<0){g.P1[v]=u;g.W1[v]=w;}else if(g.P2[v]<0){g.P2[v]=u;g.W2[v]=w;}else throw new InvalidOperationException("Too many parents");to[count]=v;next[count]=head[u];head[u]=count++;degree[v]++;}
        for(int i=0;i<n;i++){int b=10*i;edge(b,b+1,i);edge(b+1,b+3,zero);edge(b+2,b+3,zero);edge(b+3,b+4,n+i);edge(b+4,b+5,4*n+i);edge(b+5,b+7,zero);edge(b+6,b+7,zero);edge(b+7,b+8,3*n+i);edge(b+8,b+9,2*n+i);}
        foreach(var seq in s.Q)for(int p=0;p<seq.Length;p++)edge(p==0?source:10*seq[p-1]+4,10*seq[p],zero);
        for(int a=0;a<s.A.Length;a++){var seq=s.A[a];for(int p=0;p<seq.Length;p++)edge(p==0?source:10*seq[p-1]+8,10*seq[p]+2,p==0?5*n+n*n+a*n+seq[p]:5*n+seq[p-1]*n+seq[p]);}
        foreach(var seq in s.Y)for(int p=0;p<seq.Length;p++)edge(p==0?source:10*seq[p-1]+9,10*seq[p]+6,zero);
        visits=count;int[] queue=new int[nodes];int front=0,back=0,done=0;for(int v=0;v<nodes;v++)if(degree[v]==0)queue[back++]=v;
        while(front<back){int u=queue[front++];g.Topo[done++]=u;for(int e=head[u];e>=0;e=next[e]){visits++;if(--degree[to[e]]==0)queue[back++]=to[e];}}
        if(done!=nodes)return null;g.EdgeCount=count;g.BuildVisits=visits;return g;
    }
    public static void Forward(Graph g,double[] frame,double[] t){
        t[g.Source]=0;
        foreach(int v in g.Topo){int u=g.P1[v];if(u<0)continue;double a=t[u]+frame[g.W1[v]];int u2=g.P2[v];if(u2>=0)a=Math.Max(a,t[u2]+frame[g.W2[v]]);t[v]=a;}
    }
    public static double Cmax(Graph g,double[] t){double c=0;for(int i=0;i<g.N;i++)c=Math.Max(c,t[10*i+9]);return c;}
    public static double Wait(double[] t,int i){int b=10*i;return Math.Max(0,t[b+1]-t[b+2])+Math.Max(0,t[b+6]-t[b+5]);}
    public static double Empty(Instance ins,Schedule s){double d=0;for(int a=0;a<s.A.Length;a++){var z=s.A[a];if(z.Length==0)continue;d+=ins.Initial(a,z[0]);for(int p=1;p<z.Length;p++)d+=ins.Empty(z[p-1],z[p]);}return d;}
    public static double Select(double[] a,int k){
        int left=0,right=a.Length-1;
        while(left<right){double pivot=a[(left+right)/2];int i=left,j=right;while(i<=j){while(a[i]<pivot)i++;while(a[j]>pivot)j--;if(i<=j){(a[i],a[j])=(a[j],a[i]);i++;j--;}}if(k<=j)right=j;else if(k>=i)left=i;else break;}
        return a[k];
    }
    public static double Threshold(double[] a,double beta=.95){if(a.Length==0||beta<0||beta>=1)throw new ArgumentException("CVaR domain");return Select((double[])a.Clone(),Math.Min(a.Length-1,(int)Math.Floor(beta*a.Length)));}
    public static double Cvar(double[] a,double beta=.95){double eta=Threshold(a,beta),excess=0;foreach(double v in a)if(v>eta)excess+=v-eta;return eta+excess/((1-beta)*a.Length);}
    public static double[] TailWeights(double[] a,double beta=.95){double eta=Threshold(a,beta),mass=(1-beta)*a.Length;int above=0,equal=0;foreach(double v in a){if(v>eta)above++;else if(v==eta)equal++;}double boundary=Math.Max(0,mass-above)/Math.Max(1,equal)/mass;return a.Select(v=>v>eta?1/mass:v==eta?boundary:0).ToArray();}
    public static Evaluation Nominal(Instance ins,Schedule s,Graph g=null){g??=Build(ins,s,out _);if(g==null)return null;var t=new double[g.Nodes];Forward(g,Model.NominalFrame(ins),t);var w=Enumerable.Range(0,ins.N).Select(i=>Wait(t,i)).ToArray();return new(){Complete=true,Feasible=true,NomCmax=Cmax(g,t),CvarCmax=Cmax(g,t),Empty=Empty(ins,s),Risk=Cvar(w),Violation=0,Graph=g,Times=new[]{t},WaitSamples=w};}
}
