using System.Globalization;
using System.IO.Compression;
namespace TailRisk;

public static class Replay {
    public static readonly string[] MetricNames={"Cmax","WaitMean","WaitP95","QAgvWaitMean","QAgvWaitP95","YAgvWaitMean","YAgvWaitP95","QCraneWaitMean","QCraneWaitP95","YCraneWaitMean","YCraneWaitP95","QOccupancyMean","QOccupancyP95","QOccupancyMax","YOccupancyMean","YOccupancyP95","YOccupancyMax","BothOccupancyMean","BothOccupancyP95","BothOccupancyMax","PhaseMean","GTVMean"};
    static double[] Values(OperationalMetrics m)=>new[]{m.Cmax,m.WaitMean,m.WaitP95,m.QAgvWaitMean,m.QAgvWaitP95,m.YAgvWaitMean,m.YAgvWaitP95,m.QCraneWaitMean,m.QCraneWaitP95,m.YCraneWaitMean,m.YCraneWaitP95,m.QOccupancyMean,m.QOccupancyP95,m.QOccupancyMax,m.YOccupancyMean,m.YOccupancyP95,m.YOccupancyMax,m.BothOccupancyMean,m.BothOccupancyP95,m.BothOccupancyMax,m.PhaseMean,m.GTVMean};
    static string F(double v)=>v.ToString("R",CultureInfo.InvariantCulture);
    static string Sha(string path)=>Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
    static string Digest(object value)=>Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(value,JsonIO.Compact)))).ToLowerInvariant();
    sealed class Accumulator {
        public RunResult Run;public Graph Graph;public string PlanId;
        public double[] W,QW,YW,QCW,YCW,C,Sums=new double[MetricNames.Length];public int Exceeded;
        public Accumulator(RunResult r,Graph g,int reps,int n,string id){Run=r;Graph=g;PlanId=id;W=new double[n*reps];QW=new double[n*reps];YW=new double[n*reps];QCW=new double[n*reps];YCW=new double[n*reps];C=new double[reps];}
        public double[] Add(OperationalMetrics m,int rep,int n){Array.Copy(m.W,0,W,rep*n,n);Array.Copy(m.QW,0,QW,rep*n,n);Array.Copy(m.YW,0,YW,rep*n,n);Array.Copy(m.QCW,0,QCW,rep*n,n);Array.Copy(m.YCW,0,YCW,rep*n,n);C[rep]=m.Cmax;if(m.Cmax>1.01*Run.ReferenceCmax+1e-9*Math.Max(1,Run.ReferenceCmax))Exceeded++;var values=Values(m);for(int j=0;j<values.Length;j++)Sums[j]+=values[j];return values;}
        public Dictionary<string,string> Row(double cv,double rho,int reps,string phase){
            var r=Run;var x=new Dictionary<string,string>{["InstanceId"]=r.InstanceId,["N"]=r.N.ToString(),["Phase"]=phase,["Method"]=r.Method,["ConfigId"]=r.ConfigId,["Seed"]=r.Seed.ToString(),["ScheduleId"]=r.ScheduleId,["CV"]=F(cv),["Rho"]=F(rho),["Scenarios"]=reps.ToString(),["ReferenceCmax"]=F(r.ReferenceCmax),["ReferenceEmpty"]=F(r.ReferenceEmpty),["NominalCmax"]=F(r.Evaluation.NomCmax),["Empty"]=F(r.Evaluation.Empty),["WaitCVaR"]=F(Kernel.Cvar(W)),["WaitMean"]=F(W.Average()),["WaitP95"]=F(Operations.P95(W)),["QAgvWaitMean"]=F(QW.Average()),["QAgvWaitP95"]=F(Operations.P95(QW)),["YAgvWaitMean"]=F(YW.Average()),["YAgvWaitP95"]=F(Operations.P95(YW)),["QCraneWaitMean"]=F(QCW.Average()),["QCraneWaitP95"]=F(Operations.P95(QCW)),["YCraneWaitMean"]=F(YCW.Average()),["YCraneWaitP95"]=F(Operations.P95(YCW)),["CmaxMean"]=F(C.Average()),["CmaxCVaR"]=F(Kernel.Cvar(C)),["CapExceedance"]=F((double)Exceeded/reps),["RelativeCmaxChange"]=F(100*(C.Average()/r.Evaluation.NomCmax-1))};
            for(int j=11;j<MetricNames.Length;j++)x[MetricNames[j]]=F(Sums[j]/reps);
            if(reps>=500){int n=W.Length/reps;foreach(int prefix in new[]{250,500}){x[$"WaitCVaRFirst{prefix}"]=F(Kernel.Cvar(W[..(prefix*n)]));x[$"CmaxCVaRFirst{prefix}"]=F(Kernel.Cvar(C[..prefix]));}}
            return x;
        }
    }
    public static void Run(string root,Dictionary<string,string> options){
        string phase=options.GetValueOrDefault("phase","main");int reps=int.Parse(options.GetValueOrDefault("scenarios","1000")),workers=int.Parse(options.GetValueOrDefault("workers","3"));
        bool formal=new[]{"main","ablation","timing","correlated"}.Contains(phase);if(formal){Commands.VerifyFreeze(root);if(reps!=1000)throw new ArgumentException("Formal protocol requires 1000 replay scenarios");}
        double rho=phase=="correlated"?.5:double.Parse(options.GetValueOrDefault("rho","0"));
        double[] cvs=options.ContainsKey("cv")?new[]{double.Parse(options["cv"])}:phase=="correlated"?new[]{.2}:new[]{.1,.2};
        if(formal&&(rho!=(phase=="correlated"?.5:0)||!cvs.SequenceEqual(phase=="correlated"?new[]{.2}:new[]{.1,.2})))throw new ArgumentException("Formal replay CV/rho conditions are frozen by protocol");
        if(reps<=0||cvs.Any(cv=>cv<=0)||rho<0||rho>=1)throw new ArgumentException("Invalid replay conditions");
        string source=phase=="correlated"?"main":phase;
        RunIntegrity.VerifyRunSet(root,source);
        var files=Directory.GetFiles(Path.Combine(Commands.Results(root,source),"runs"),"*.json").Order().ToArray();
        var rows=files.Select(f=>(Path:f,Run:JsonIO.Read<RunResult>(f))).Where(x=>phase!="correlated"||(x.Run.N>=96&&int.Parse(x.Run.InstanceId[^2..])<=10)).ToList();
        var groups=rows.GroupBy(x=>x.Run.InstanceId).ToArray();int done=0,total=groups.Length*cvs.Length;
        string outdir=Commands.Results(root,phase),parts=Path.Combine(outdir,"replay");Directory.CreateDirectory(parts);
        var coreFiles=new[]{"Contracts.cs","Model.cs","Kernel.cs","Operations.cs","Replay.cs"};
        var inputFiles=groups.SelectMany(g=>{string split=g.Key.StartsWith("test_")?"test":"development";return new[]{Path.Combine(Commands.Data(root,split),g.Key+".json"),Path.Combine(Commands.Data(root,split),g.Key+"_reference.json")};}).Order(StringComparer.Ordinal).ToArray();
        var runSet=new{Phase=phase,Scenarios=reps,CV=cvs,Rho=rho,Core=coreFiles.ToDictionary(f=>f,f=>Sha(Path.Combine(Commands.Repro(root),"src",f))),Inputs=inputFiles.ToDictionary(f=>Path.GetRelativePath(root,f),Sha),Plans=rows.OrderBy(x=>x.Path,StringComparer.Ordinal).ToDictionary(x=>Path.GetFileName(x.Path),x=>Sha(x.Path))};
        string runSetPath=Path.Combine(parts,"runset.json"),runSetHash=Digest(runSet);
        if(File.Exists(runSetPath)){var saved=JsonIO.Read<Dictionary<string,string>>(runSetPath);if(saved["Digest"]!=runSetHash)throw new InvalidOperationException("Replay runset changed; archive affected results and restart explicitly");}
        else {if(Directory.GetFiles(parts,"*_summary.csv").Length>0)throw new InvalidOperationException("Unmanifested replay outputs cannot be resumed");JsonIO.Save(runSetPath,new Dictionary<string,string>{{"Digest",runSetHash},{"Specification",System.Text.Json.JsonSerializer.Serialize(runSet,JsonIO.Compact)}});}
        Parallel.ForEach(groups,new ParallelOptions{MaxDegreeOfParallelism=workers},group=>{
            var first=group.First().Run;string split=group.Key.StartsWith("test_")?"test":"development";
            var ins=JsonIO.Read<Instance>(Path.Combine(Commands.Data(root,split),group.Key+".json"));var nominal=Model.NominalFrame(ins);
            foreach(double cv in cvs){
                string stem=$"{ins.Id}_cv{cv*100:00}_rho{rho*100:00}",summary=Path.Combine(parts,stem+"_summary.csv"),rawpath=Path.Combine(parts,stem+".csv.gz");
                string manifestPath=Path.Combine(parts,stem+"_manifest.json"),referencePath=Path.Combine(parts,stem+"_reference.json");
                bool complete=File.Exists(manifestPath);
                if(complete){
                    var saved=JsonIO.Read<Dictionary<string,string>>(manifestPath);
                    if(saved["RunSetDigest"]!=runSetHash||!File.Exists(summary)||!File.Exists(rawpath)||!File.Exists(referencePath)||saved["RawSha256"]!=Sha(rawpath)||saved["SummarySha256"]!=Sha(summary)||saved["ReferenceSha256"]!=Sha(referencePath))throw new InvalidOperationException("Replay checkpoint mismatch: "+stem);
                }
                if(!complete){
                    var acc=group.Select(x=>new Accumulator(x.Run,Kernel.Build(ins,x.Run.Schedule,out _),reps,ins.N,Path.GetFileNameWithoutExtension(x.Path))).ToArray();if(acc.Any(x=>x.Graph==null))throw new InvalidOperationException("Invalid archived schedule");
                    int seed=Model.Seed($"replay|{ins.Id}|cv{cv:F2}|rho{rho:F2}");
                    var reference=JsonIO.Read<ReferenceRecord>(Commands.ReferencePath(root,ins));
                    var referenceGraph=Kernel.Build(ins,reference.Schedule,out _);var referenceCmax=new double[reps];
                    using(var stream=File.Create(rawpath+".tmp"))using(var compressed=new GZipStream(stream,CompressionLevel.Fastest))using(var writer=new StreamWriter(compressed)){
                        writer.WriteLine("PlanId,Scenario,"+string.Join(",",MetricNames));var t=new double[10*ins.N+1];
                        for(int rep=0;rep<reps;rep++){
                            var frame=Model.Perturb(nominal,cv,seed,rep,rho);
                            Kernel.Forward(referenceGraph,frame,t);referenceCmax[rep]=Kernel.Cmax(referenceGraph,t);
                            foreach(var a in acc){Kernel.Forward(a.Graph,frame,t);var metrics=Operations.Measure(ins,a.Run.Schedule,t);var values=a.Add(metrics,rep,ins.N);writer.WriteLine(a.PlanId+","+rep+","+string.Join(",",values.Select(F)));}
                        }
                    }
                    File.Move(rawpath+".tmp",rawpath,true);var summaries=acc.Select(a=>a.Row(cv,rho,reps,phase)).ToList();
                    foreach(var row in summaries)row["ReferenceReplayCvarCmax"]=F(Kernel.Cvar(referenceCmax));
                    WriteCsv(summary,summaries);
                    JsonIO.Save(referencePath,new{InstanceId=ins.Id,ScenarioSeed=seed,CV=cv,Rho=rho,Cmax=referenceCmax});
                    JsonIO.Save(manifestPath,new Dictionary<string,string>{{"RunSetDigest",runSetHash},{"Instance",ins.Id},{"Phase",phase},{"CV",F(cv)},{"Rho",F(rho)},{"Scenarios",reps.ToString()},{"ScenarioSeed",seed.ToString()},{"Plans",acc.Length.ToString()},{"Decodings",((long)acc.Length*reps).ToString()},{"InputVersion",ins.Version},{"RawSha256",Sha(rawpath)},{"SummarySha256",Sha(summary)},{"ReferenceSha256",Sha(referencePath)}});
                }
                Console.WriteLine($"replay {phase}: {Interlocked.Increment(ref done)}/{total} completed {stem}");
            }
        });
        var expectedParts=groups.SelectMany(g=>cvs.Select(cv=>$"{g.Key}_cv{cv*100:00}_rho{rho*100:00}_summary.csv")).Order(StringComparer.Ordinal).ToArray();
        if(!Directory.GetFiles(parts,"*_summary.csv").Select(Path.GetFileName).Order(StringComparer.Ordinal).SequenceEqual(expectedParts))throw new InvalidOperationException("Unexpected replay summary files");
        var all=new List<string>();foreach(string name in expectedParts){var lines=File.ReadAllLines(Path.Combine(parts,name));if(all.Count==0)all.Add(lines[0]);else if(all[0]!=lines[0])throw new InvalidOperationException("Inconsistent CSV schema");all.AddRange(lines.Skip(1));}
        if(all.Count-1!=rows.Count*cvs.Length)throw new InvalidOperationException("Replay row count incomplete");
        File.WriteAllLines(Path.Combine(outdir,"replay_plan.csv"),all);JsonIO.Save(Path.Combine(outdir,"replay_completion.json"),new{Phase=phase,PlanConditionRows=all.Count-1,ScenariosPerPlan=reps,TotalDecodings=(long)(all.Count-1)*reps,FinishedUtc=DateTime.UtcNow.ToString("O")});
    }
    public static void WriteCsv(string path,List<Dictionary<string,string>> rows){if(rows.Count==0)throw new ArgumentException("Empty CSV");var keys=rows[0].Keys.ToArray();var lines=new List<string>{string.Join(",",keys)};lines.AddRange(rows.Select(row=>string.Join(",",keys.Select(k=>row[k]))));File.WriteAllLines(path+".tmp",lines);File.Move(path+".tmp",path,true);}
}
