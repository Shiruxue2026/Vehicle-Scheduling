using System.Globalization;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace TailRisk;

public sealed class PreFreezeAuditReport {
    public string Status="running",StartedUtc=DateTime.UtcNow.ToString("O"),FinishedUtc,SelectionPhase,Error;
    public int SelectionRound;
    public string[] DevelopmentGuardFallbackMethods=Array.Empty<string>();
    public List<object> Checks=new();
    public SortedDictionary<string,string> ArtifactSha256=new(StringComparer.Ordinal);
}

/// <summary>Completeness gate before scientific protocol freezing; no effect-size acceptance gate.</summary>
public static class PreFreezeAudit {
    static readonly int[] Sizes={24,48,96,192};
    static readonly string[] Methods={"ALNS","CB-TS","GA","TS-JS"};
    static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException("Pre-freeze audit: "+message);}
    static string Json<T>(T value)=>JsonSerializer.Serialize(value,JsonIO.Compact);
    static string Digest(string value)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value))).ToLowerInvariant();
    static string Sha(string path){using var file=File.OpenRead(path);return Convert.ToHexString(SHA256.HashData(file)).ToLowerInvariant();}
    static string PhasePath(string root,string phase)=>Path.Combine(root,"reproducibility","results",phase);
    static string ConfigPath(string root,string name)=>Path.Combine(root,"reproducibility","configs",name);
    static JsonDocument Read(string path)=>JsonDocument.Parse(File.ReadAllText(path));
    static double Number(string value){Require(double.TryParse(value,NumberStyles.Float,CultureInfo.InvariantCulture,out double number)&&double.IsFinite(number),"invalid numeric CSV value");return number;}
    static int Integer(string value){Require(int.TryParse(value,NumberStyles.Integer,CultureInfo.InvariantCulture,out int number),"invalid integer CSV value");return number;}
    static bool Near(double a,double b)=>double.IsFinite(a)&&double.IsFinite(b)&&Math.Abs(a-b)<=1e-9*Math.Max(1,Math.Max(Math.Abs(a),Math.Abs(b)));
    static void RecordFile(PreFreezeAuditReport report,string root,string path){Require(File.Exists(path),"required artifact missing: "+path);report.ArtifactSha256[Path.GetRelativePath(root,path).Replace('\\','/')]=Sha(path);}
    static string ConfigText(IEnumerable<SearchConfig> configurations)=>Json(configurations.OrderBy(x=>x.Id,StringComparer.Ordinal).ToArray());
    static string[] Ids(int[] sizes,int first,int last)=>sizes.SelectMany(n=>Enumerable.Range(first,last-first+1).Select(i=>$"development_N{n}_I{i:00}")).Order(StringComparer.Ordinal).ToArray();
    static string Key(string instance,string config,int seed)=>instance+"|"+config+"|"+seed.ToString(CultureInfo.InvariantCulture);
    static string ConditionKey(string instance,string config,int seed,double cv)=>Key(instance,config,seed)+"|"+cv.ToString("R",CultureInfo.InvariantCulture);
    static void ConfigSet(IReadOnlyList<SearchConfig> configs,int perMethod,string label){
        Require(configs.Count==4*perMethod&&configs.Select(c=>c.Id).Distinct().Count()==configs.Count,label+" configuration count/IDs");
        Require(configs.Select(c=>c.Method).Distinct().Order(StringComparer.Ordinal).SequenceEqual(Methods),label+" method set");
        Require(configs.GroupBy(c=>c.Method).All(g=>g.Count()==perMethod),label+" configurations per method");
    }
    static RunSetManifest Runs(string root,string phase,string[] instances,IReadOnlyList<SearchConfig> configs,int seeds,int k,double fraction,int count,PreFreezeAuditReport report){
        var manifest=RunIntegrity.VerifyRunSet(root,phase);var spec=manifest.Specification;
        Require(spec.Runs.Count==count&&spec.Inputs.Count==instances.Length,phase+" run/instance count");
        Require(spec.Inputs.Select(x=>x.InstanceId).Order(StringComparer.Ordinal).SequenceEqual(instances),phase+" exact development instance set");
        Require(spec.TrainingCount==k&&!spec.NominalOnly&&spec.TrainingCV==.20&&spec.TrainingRho==0,phase+" training protocol");
        Require(ConfigText(spec.Configurations)==ConfigText(configs),phase+" full configuration settings");
        var expected=new HashSet<string>(StringComparer.Ordinal);
        foreach(string instance in instances)foreach(var cfg in configs)for(int s=1;s<=seeds;s++)expected.Add(Key(instance,cfg.Id,Model.Seed($"algorithm|{instance}|{s}")));
        Require(spec.Runs.Select(r=>Key(r.InstanceId,r.ConfigId,r.Seed)).ToHashSet(StringComparer.Ordinal).SetEquals(expected),phase+" exact paired seed/configuration cells");
        foreach(var input in spec.Inputs){
            Require(input.TrainingSeed==Model.Seed($"train|{input.InstanceId}"),phase+" training seed rule");
            Require(manifest.Instances[input.InstanceId].Split=="development",phase+" contains non-development input");
        }
        foreach(var run in spec.Runs){
            Require(run.TimeLimit==0&&run.Limit==(long)(SearchContext.MainBudget(manifest.Inputs[run.InstanceId].N)*fraction),phase+" work/time budget");
            Require(run.SeedIndex>=1&&run.SeedIndex<=seeds&&run.Seed==Model.Seed($"algorithm|{run.InstanceId}|{run.SeedIndex}"),phase+" seed-index identity");
        }
        string completionPath=Path.Combine(PhasePath(root,phase),"completion.json");using(var completion=Read(completionPath)){
            Require(completion.RootElement.GetProperty("Expected").GetInt32()==count&&completion.RootElement.GetProperty("Files").GetInt32()==count&&completion.RootElement.GetProperty("Phase").GetString()==phase,phase+" completion record");
        }
        RecordFile(report,root,Path.Combine(PhasePath(root,phase),"runset_manifest.json"));RecordFile(report,root,completionPath);
        report.Checks.Add(new{Check="optimization_run_set",Phase=phase,Plans=count,Instances=instances.Length,TrainingScenarios=k,Status="passed"});return manifest;
    }
    static List<Dictionary<string,string>> Csv(string path){
        var lines=File.ReadAllLines(path);Require(lines.Length>=2,"empty CSV: "+path);var headers=lines[0].Split(',');
        Require(headers.Distinct().Count()==headers.Length,"duplicate CSV column: "+path);
        var result=new List<Dictionary<string,string>>(lines.Length-1);
        foreach(string line in lines.Skip(1)){var cells=line.Split(',');Require(cells.Length==headers.Length,"CSV column count: "+path);result.Add(headers.Select((h,i)=>(h,i)).ToDictionary(p=>p.h,p=>cells[p.i],StringComparer.Ordinal));}
        return result;
    }
    static void Replay(string root,RunSetManifest manifest,double[] cvs,int expectedRows,PreFreezeAuditReport report){
        string phase=manifest.Specification.Phase,dir=PhasePath(root,phase),parts=Path.Combine(dir,"replay"),runsetPath=Path.Combine(parts,"runset.json");
        var runset=JsonIO.Read<Dictionary<string,string>>(runsetPath);Require(runset["Digest"]==Digest(runset["Specification"]),phase+" replay specification digest");
        using var specDocument=JsonDocument.Parse(runset["Specification"]);var spec=specDocument.RootElement;
        Require(spec.GetProperty("Phase").GetString()==phase&&spec.GetProperty("Scenarios").GetInt32()==1000&&spec.GetProperty("Rho").GetDouble()==0,phase+" replay condition/scenario count");
        Require(spec.GetProperty("CV").EnumerateArray().Select(x=>x.GetDouble()).SequenceEqual(cvs),phase+" replay CV set");
        var core=spec.GetProperty("Core");string[] coreNames={"Contracts.cs","Model.cs","Kernel.cs","Operations.cs","Replay.cs"};
        Require(core.EnumerateObject().Select(x=>x.Name).ToHashSet(StringComparer.Ordinal).SetEquals(coreNames),phase+" replay source set");
        foreach(string name in coreNames)Require(core.GetProperty(name).GetString()==Sha(Path.Combine(root,"reproducibility","src",name)),phase+" replay source changed: "+name);
        var expectedInputs=manifest.Specification.Inputs.SelectMany(x=>new[]{x.InstancePath,x.ReferencePath}).Select(x=>x.Replace('\\','/')).ToHashSet(StringComparer.Ordinal);
        var inputs=spec.GetProperty("Inputs").EnumerateObject().ToArray();Require(inputs.Select(x=>x.Name.Replace('\\','/')).ToHashSet(StringComparer.Ordinal).SetEquals(expectedInputs),phase+" replay input set");
        foreach(var input in inputs)Require(input.Value.GetString()==Sha(Path.Combine(root,input.Name)),phase+" replay input hash");
        var plans=spec.GetProperty("Plans").EnumerateObject().ToArray();Require(plans.Select(x=>x.Name).ToHashSet(StringComparer.Ordinal).SetEquals(manifest.Expected.Keys),phase+" replay plan set");
        var archived=new Dictionary<string,RunResult>(StringComparer.Ordinal);
        foreach(var plan in plans){string path=Path.Combine(dir,"runs",plan.Name);Require(plan.Value.GetString()==Sha(path),phase+" replay plan hash");var run=JsonIO.Read<RunResult>(path);archived.Add(Key(run.InstanceId,run.ConfigId,run.Seed),run);}
        string mergedPath=Path.Combine(dir,"replay_plan.csv");var rows=Csv(mergedPath);Require(rows.Count==expectedRows&&expectedRows==archived.Count*cvs.Length,phase+" replay plan-condition count");
        var expectedKeys=archived.Values.SelectMany(x=>cvs.Select(cv=>ConditionKey(x.InstanceId,x.ConfigId,x.Seed,cv))).ToHashSet(StringComparer.Ordinal);var seen=new HashSet<string>(StringComparer.Ordinal);
        foreach(var row in rows){
            double cv=Number(row["CV"]);string key=Key(row["InstanceId"],row["ConfigId"],Integer(row["Seed"]));Require(archived.TryGetValue(key,out var run),phase+" unknown replay plan");
            Require(seen.Add(ConditionKey(run.InstanceId,run.ConfigId,run.Seed,cv)),phase+" duplicate replay row");
            Require(row["Phase"]==phase&&row["Method"]==run.Method&&row["ScheduleId"]==run.ScheduleId&&Integer(row["N"])==run.N&&Integer(row["Scenarios"])==1000&&Number(row["Rho"])==0,phase+" replay identity/condition mismatch");
            Require(Near(Number(row["ReferenceCmax"]),run.ReferenceCmax)&&Near(Number(row["ReferenceEmpty"]),run.ReferenceEmpty)&&Near(Number(row["NominalCmax"]),run.Evaluation.NomCmax)&&Near(Number(row["Empty"]),run.Evaluation.Empty),phase+" replay reference/nominal values");
            foreach(string metric in new[]{"WaitCVaR","WaitMean","WaitP95","CmaxCVaR","CmaxMean","ReferenceReplayCvarCmax","CapExceedance"})Number(row[metric]);
        }
        Require(seen.SetEquals(expectedKeys),phase+" missing/extra replay plan-condition cells");
        var expectedSummaries=new List<string>();var concatenated=new List<string>();long rawRows=0;
        foreach(var input in manifest.Specification.Inputs.OrderBy(x=>x.InstanceId,StringComparer.Ordinal))foreach(double cv in cvs){
            string stem=$"{input.InstanceId}_cv{cv*100:00}_rho00",chunkPath=Path.Combine(parts,stem+"_manifest.json"),summary=Path.Combine(parts,stem+"_summary.csv"),raw=Path.Combine(parts,stem+".csv.gz"),reference=Path.Combine(parts,stem+"_reference.json");
            var chunk=JsonIO.Read<Dictionary<string,string>>(chunkPath);var chunkRuns=manifest.Specification.Runs.Where(x=>x.InstanceId==input.InstanceId).ToArray();
            int scenarioSeed=Model.Seed("replay|"+input.InstanceId+"|cv"+cv.ToString("F2",CultureInfo.InvariantCulture)+"|rho0.00");
            Require(scenarioSeed!=input.TrainingSeed,phase+" training/replay seed collision");
            Require(chunk["RunSetDigest"]==runset["Digest"]&&chunk["Instance"]==input.InstanceId&&chunk["Phase"]==phase&&Number(chunk["CV"])==cv&&Number(chunk["Rho"])==0&&Integer(chunk["Scenarios"])==1000&&Integer(chunk["ScenarioSeed"])==scenarioSeed&&Integer(chunk["Plans"])==chunkRuns.Length&&long.Parse(chunk["Decodings"],CultureInfo.InvariantCulture)==1000L*chunkRuns.Length,phase+" replay chunk metadata: "+stem);
            Require(chunk["SummarySha256"]==Sha(summary)&&chunk["RawSha256"]==Sha(raw)&&chunk["ReferenceSha256"]==Sha(reference),phase+" replay chunk checksum: "+stem);
            using(var referenceJson=Read(reference)){
                var r=referenceJson.RootElement;Require(r.GetProperty("InstanceId").GetString()==input.InstanceId&&r.GetProperty("ScenarioSeed").GetInt32()==scenarioSeed&&r.GetProperty("CV").GetDouble()==cv&&r.GetProperty("Rho").GetDouble()==0,phase+" reference replay identity");
                var samples=r.GetProperty("Cmax").EnumerateArray().Select(x=>x.GetDouble()).ToArray();Require(samples.Length==1000&&samples.All(x=>double.IsFinite(x)&&x>0),phase+" reference replay scenarios");
                double referenceRisk=Kernel.Cvar(samples);foreach(var row in rows.Where(x=>x["InstanceId"]==input.InstanceId&&Number(x["CV"])==cv))Require(Near(Number(row["ReferenceReplayCvarCmax"]),referenceRisk),phase+" reference replay risk scalar");
            }
            // Count each actual gzip plan/scenario pair, not only its manifest declaration.
            var planIndex=chunkRuns.Select((x,i)=>(Name:Path.GetFileNameWithoutExtension(x.FileName),Index:i)).ToDictionary(x=>x.Name,x=>x.Index,StringComparer.Ordinal);
            var rawSeen=new bool[1000*planIndex.Count];int count=0;
            using(var file=File.OpenRead(raw))using(var gzip=new GZipStream(file,CompressionMode.Decompress))using(var reader=new StreamReader(gzip)){
                Require(reader.ReadLine()=="PlanId,Scenario,"+string.Join(",",TailRisk.Replay.MetricNames),phase+" raw replay header");string line;
                while((line=reader.ReadLine())!=null){int first=line.IndexOf(','),second=first<0?-1:line.IndexOf(',',first+1);Require(first>0&&second>first,phase+" malformed raw replay row");Require(planIndex.TryGetValue(line[..first],out int p),phase+" unknown raw replay plan");int s=Integer(line[(first+1)..second]);Require(s>=0&&s<1000&&!rawSeen[p*1000+s],phase+" duplicate/out-of-range raw scenario");rawSeen[p*1000+s]=true;count++;}
            }
            Require(count==rawSeen.Length,phase+" incomplete raw plan/scenario set");rawRows+=count;
            expectedSummaries.Add(Path.GetFileName(summary));var lines=File.ReadAllLines(summary);Require(lines.Length==chunkRuns.Length+1,phase+" chunk summary count");
            if(concatenated.Count==0)concatenated.Add(lines[0]);else Require(concatenated[0]==lines[0],phase+" inconsistent summary header");concatenated.AddRange(lines.Skip(1));
            RecordFile(report,root,chunkPath);
        }
        Require(Directory.GetFiles(parts,"*_summary.csv").Select(Path.GetFileName).ToHashSet(StringComparer.Ordinal).SetEquals(expectedSummaries),phase+" extra/missing chunk summaries");
        // Replay concatenates ordinal filenames (rather than CV iteration ordering).
        var recombined=new List<string>();foreach(string name in expectedSummaries.Order(StringComparer.Ordinal)){var lines=File.ReadAllLines(Path.Combine(parts,name));if(recombined.Count==0)recombined.Add(lines[0]);recombined.AddRange(lines.Skip(1));}
        Require(File.ReadAllLines(mergedPath).SequenceEqual(recombined),phase+" merged replay differs from verified chunks");
        string completionPath=Path.Combine(dir,"replay_completion.json");using(var complete=Read(completionPath)){
            var c=complete.RootElement;Require(c.GetProperty("Phase").GetString()==phase&&c.GetProperty("PlanConditionRows").GetInt32()==expectedRows&&c.GetProperty("ScenariosPerPlan").GetInt32()==1000&&c.GetProperty("TotalDecodings").GetInt64()==rawRows,phase+" replay completion record");
        }
        RecordFile(report,root,runsetPath);RecordFile(report,root,mergedPath);RecordFile(report,root,completionPath);
        report.Checks.Add(new{Check="independent_development_replay",Phase=phase,PlanConditionRows=expectedRows,ScenariosPerCondition=1000,ActualRawRows=rawRows,CV=cvs,Status="passed"});
    }
    static void Calibration(string root,IReadOnlyList<SearchConfig> selected,PreFreezeAuditReport report){
        var manifest=Runs(root,"calibration",Ids(new[]{96,192},6,8),selected,2,64,1,48,report);
        string environmentPath=Path.Combine(PhasePath(root,"calibration"),"calibration_environment.json");using(var environment=Read(environmentPath)){
            var e=environment.RootElement;Require(e.GetProperty("Workers").GetInt32()==1&&e.GetProperty("ProcessorAffinity").GetInt64()==1&&e.GetProperty("WarmupCompleted").GetBoolean()&&e.GetProperty("NoConcurrentStudyExperiments").GetBoolean(),"calibration execution environment evidence");
            Require(DateTimeOffset.TryParse(e.GetProperty("StartedUtc").GetString(),CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out var started)&&DateTimeOffset.TryParse(e.GetProperty("FinishedUtc").GetString(),CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out var finished)&&finished>=started,"calibration environment timestamps");
        }
        string timingPath=ConfigPath(root,"timing.json");var timing=JsonIO.Read<Dictionary<int,double>>(timingPath);Require(timing.Keys.ToHashSet().SetEquals(new[]{96,192}),"timing size set");
        var runs=manifest.Specification.Runs.Select(x=>JsonIO.Read<RunResult>(Path.Combine(manifest.DirectoryPath,"runs",x.FileName))).ToArray();
        double Median(IEnumerable<double> values){var sorted=values.Order().ToArray();return(sorted[(sorted.Length-1)/2]+sorted[sorted.Length/2])/2;}
        foreach(int n in new[]{96,192}){
            double expected=Math.Clamp(5*Math.Ceiling(Median(runs.Where(x=>x.N==n).GroupBy(x=>x.Method).Select(g=>Median(g.Select(x=>x.Seconds))))/5),n==96?10:20,n==96?120:240);
            Require(double.IsFinite(timing[n])&&timing[n]%5==0&&timing[n]==expected,"timing median/ceil/clamp rule for N="+n);
        }
        RecordFile(report,root,environmentPath);RecordFile(report,root,timingPath);report.Checks.Add(new{Check="single_cpu_calibration",Runs=48,Timing=timing,ConcurrencyEvidence="Recorded study-level precondition; not a claim that the host had no other operating-system processes.",Status="passed"});
    }
    static void ValidationArtifacts(string root,PreFreezeAuditReport report){
        string path=Path.Combine(root,"reports","validation","validation.json");using(var validation=Read(path)){
            var v=validation.RootElement;bool passed=(v.TryGetProperty("Status",out var status)&&string.Equals(status.GetString(),"passed",StringComparison.OrdinalIgnoreCase))||(v.TryGetProperty("Passed",out var flag)&&flag.ValueKind==JsonValueKind.True);
            Require(passed,"independent validation did not pass");var checks=v.GetProperty("Checks").EnumerateArray().ToArray();Require(checks.Length>0&&checks.All(x=>!x.TryGetProperty("Status",out var s)||string.Equals(s.GetString(),"passed",StringComparison.OrdinalIgnoreCase)),"validation has incomplete/failed checks");
        }
        RecordFile(report,root,path);
        string exactDir=Path.Combine(root,"reports","exact");var expected=new HashSet<string>(StringComparer.Ordinal);
        for(int n=4;n<=6;n++)for(int i=1;i<=2;i++){
            string name=$"exact_n{n}_i{i}.json";expected.Add(name);string exactPath=Path.Combine(exactDir,name);using var exact=Read(exactPath);var e=exact.RootElement;
            var ins=e.GetProperty("Instance").Deserialize<Instance>(JsonIO.Options);Require(ins.N==n&&ins.Id==$"exact_N{n}_I{i:00}"&&ins.Qn==2&&ins.An==2&&ins.Yn==2,"exact audit instance identity");
            Require(e.GetProperty("TrainingScenarios").GetInt32()==64&&e.GetProperty("TrainingCV").GetDouble()==.2&&e.GetProperty("Candidates").GetInt64()>0&&e.GetProperty("EventFeasible").GetInt64()>0&&e.GetProperty("AllConstraintsFeasible").GetInt64()>0,"incomplete exact enumeration record");
            var full=e.GetProperty("FullPlan").Deserialize<Schedule>(JsonIO.Options);Require(Kernel.Build(ins,full,out _)!=null&&double.IsFinite(e.GetProperty("FullRisk").GetDouble()),"exact full-domain optimum missing");
            if(e.GetProperty("PriorityAllConstraintsFeasible").GetInt64()>0)Require(Kernel.Build(ins,e.GetProperty("PriorityPlan").Deserialize<Schedule>(JsonIO.Options),out _)!=null&&double.IsFinite(e.GetProperty("PriorityRisk").GetDouble()),"exact restricted-domain optimum missing");
            // Empty restricted domains are legitimate and are never rejected for poor performance.
            RecordFile(report,root,exactPath);
        }
        Require(Directory.GetFiles(exactDir,"exact_n*_i*.json").Select(Path.GetFileName).ToHashSet(StringComparer.Ordinal).SetEquals(expected),"exact audit case set");
        string summary=Path.Combine(exactDir,"exact_summary.csv");Require(File.ReadAllLines(summary).Length==7,"exact summary incomplete");RecordFile(report,root,summary);
        foreach(string name in new[]{"analyze.py","package_audit.py","test_analysis.py"}){string script=Path.Combine(root,"analysis",name);Require(File.Exists(script)&&new FileInfo(script).Length>0,"analysis script missing: "+name);RecordFile(report,root,script);}
        report.Checks.Add(new{Check="independent_validation_exact_and_analysis_artifacts",ExactCases=6,Status="passed"});
    }
    public static PreFreezeAuditReport Verify(string root){
        root=Path.GetFullPath(root);var report=new PreFreezeAuditReport();string reportPath=Path.Combine(root,"reports","prefreeze_audit.json");
        try{
            Require(!File.Exists(ConfigPath(root,"freeze.json")),"protocol is already frozen");
            string testDir=Path.Combine(root,"reproducibility","data","test");Require(!Directory.Exists(testDir)||Directory.GetFiles(testDir,"test_*.json").Length==0,"confirmation inputs exist before this pre-freeze check");
            string selectionAuditPath=ConfigPath(root,"selection_audit.json");using(var selectionAudit=Read(selectionAuditPath)){
                var a=selectionAudit.RootElement;int round=a.GetProperty("Round").GetInt32();Require(round>=1&&round<=3,"selection round outside the development allowance");string stage=a.GetProperty("Stage").GetString();Require(!string.IsNullOrEmpty(stage)&&stage.All(c=>char.IsAsciiLetterOrDigit(c)||c=='_'||c=='-'),"selection stage identifier");
                string phase=stage.StartsWith("dev_",StringComparison.Ordinal)?stage:stage.StartsWith($"r{round}_",StringComparison.Ordinal)?"dev_"+stage:$"dev_r{round}_"+stage;
                Require(phase.StartsWith($"dev_r{round}_",StringComparison.Ordinal)&&phase!=$"dev_r{round}_tune","selection stage/round mismatch");report.SelectionRound=round;report.SelectionPhase=phase;
                if(a.TryGetProperty("FallbackMethods",out var fallback))report.DevelopmentGuardFallbackMethods=fallback.EnumerateArray().Select(x=>x.GetString()).ToArray();
            }
            int r=report.SelectionRound;string gridPath=ConfigPath(root,$"grid_r{r}.json"),shortlistPath=ConfigPath(root,$"shortlist_r{r}.json"),selectedPath=ConfigPath(root,"selected.json");
            var grid=JsonIO.Read<List<SearchConfig>>(gridPath);var shortlist=JsonIO.Read<List<SearchConfig>>(shortlistPath);var selected=JsonIO.Read<List<SearchConfig>>(selectedPath);
            ConfigSet(grid,8,"development grid");ConfigSet(shortlist,2,"shortlist");ConfigSet(selected,1,"selected");
            foreach(var c in shortlist)Require(grid.Any(x=>x.Id==c.Id&&Json(x)==Json(c)),"shortlist configuration not in current grid: "+c.Id);
            foreach(var c in selected)Require(shortlist.Any(x=>x.Id==c.Id&&Json(x)==Json(c)),"selected configuration not in shortlist: "+c.Id);
            foreach(string file in new[]{selectionAuditPath,gridPath,shortlistPath,selectedPath})RecordFile(report,root,file);
            Runs(root,$"dev_r{r}_tune",Ids(Sizes,1,5),grid,2,64,.5,1280,report);
            var selection=Runs(root,report.SelectionPhase,Ids(Sizes,6,10),shortlist,5,64,1,800,report);Replay(root,selection,new[]{.10,.20},1600,report);
            foreach(int k in new[]{32,128}){var training=Runs(root,$"dev_trainingK{k}",Ids(Sizes,6,10),selected,2,k,1,160,report);Replay(root,training,new[]{.20},160,report);}
            Calibration(root,selected,report);ValidationArtifacts(root,report);
            report.Status="passed";report.Checks.Add(new{Check="scientific_outcome_independence",Rule="Completeness and reproducibility only. Low improvement, development guard fallback, or an empty restricted exact domain does not fail this gate.",Status="passed"});return report;
        }catch(Exception error){report.Status="failed";report.Error=error.ToString();throw;}
        finally{report.FinishedUtc=DateTime.UtcNow.ToString("O");JsonIO.Save(reportPath,report);}
    }
}
