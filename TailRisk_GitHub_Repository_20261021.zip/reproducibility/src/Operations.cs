namespace TailRisk;

public sealed class OperationalMetrics {
    public double Cmax, WaitMean, WaitP95, QAgvWaitMean,QAgvWaitP95,YAgvWaitMean,YAgvWaitP95,QCraneWaitMean,QCraneWaitP95,YCraneWaitMean,YCraneWaitP95;
    public double QOccupancyMean,QOccupancyP95,QOccupancyMax,YOccupancyMean,YOccupancyP95,YOccupancyMax,BothOccupancyMean,BothOccupancyP95,BothOccupancyMax,PhaseMean,GTVMean;
    public double[] W,QW,YW,QCW,YCW;
}
public static class Operations {
    public static double P95(double[] values)=>Kernel.Select((double[])values.Clone(),Math.Max(0,(int)Math.Ceiling(.95*values.Length)-1));
    public static (double Mean,double P95,double Max) Occupancy(List<(double Time,int Delta)> events,double end){
        if(events.Count==0)return(0,0,0);events.Sort((a,b)=>a.Time.CompareTo(b.Time));
        var durations=new Dictionary<int,double>();int count=0,max=0,p=0;double last=0,area=0;
        while(p<events.Count){double time=events[p].Time,dt=time-last;if(dt>0){durations[count]=durations.GetValueOrDefault(count)+dt;area+=count*dt;max=Math.Max(max,count);}while(p<events.Count&&events[p].Time==time)count+=events[p++].Delta;last=time;}
        if(end>last)durations[count]=durations.GetValueOrDefault(count)+end-last;
        double target=.95*end,acc=0,quantile=0;foreach(var pair in durations.OrderBy(x=>x.Key)){acc+=pair.Value;if(acc+1e-10>=target){quantile=pair.Key;break;}}
        return(area/end,quantile,max);
    }
    public static OperationalMetrics Measure(Instance ins,Schedule schedule,double[] t){
        int n=ins.N;var m=new OperationalMetrics{W=new double[n],QW=new double[n],YW=new double[n],QCW=new double[n],YCW=new double[n]};
        var qe=new List<(double,int)>();var ye=new List<(double,int)>();var gq=new double[n];var gy=new double[n];
        for(int i=0;i<n;i++){int b=10*i;gq[i]=t[b+2]-t[b+1];gy[i]=t[b+5]-t[b+6];m.QW[i]=Math.Max(0,-gq[i]);m.YW[i]=Math.Max(0,-gy[i]);m.QCW[i]=Math.Max(0,gq[i]);m.YCW[i]=Math.Max(0,gy[i]);m.W[i]=m.QW[i]+m.YW[i];m.Cmax=Math.Max(m.Cmax,t[b+9]);m.PhaseMean+=(Math.Abs(gq[i])+Math.Abs(gy[i]))/(2*n);if(m.QW[i]>0){qe.Add((t[b+2],1));qe.Add((t[b+3],-1));}if(m.YW[i]>0){ye.Add((t[b+5],1));ye.Add((t[b+7],-1));}}
        m.WaitMean=m.W.Average();m.WaitP95=P95(m.W);m.QAgvWaitMean=m.QW.Average();m.YAgvWaitMean=m.YW.Average();m.QCraneWaitMean=m.QCW.Average();m.YCraneWaitMean=m.YCW.Average();m.QAgvWaitP95=P95(m.QW);m.YAgvWaitP95=P95(m.YW);m.QCraneWaitP95=P95(m.QCW);m.YCraneWaitP95=P95(m.YCW);
        foreach(var chain in schedule.Q)for(int j=1;j<chain.Length;j++)m.GTVMean+=Math.Abs(gq[chain[j]]-gq[chain[j-1]]);
        foreach(var chain in schedule.Y)for(int j=1;j<chain.Length;j++)m.GTVMean+=Math.Abs(gy[chain[j]]-gy[chain[j-1]]);
        m.GTVMean/=2*n-ins.Qn-ins.Yn;
        (m.QOccupancyMean,m.QOccupancyP95,m.QOccupancyMax)=Occupancy(qe,m.Cmax);
        (m.YOccupancyMean,m.YOccupancyP95,m.YOccupancyMax)=Occupancy(ye,m.Cmax);
        (m.BothOccupancyMean,m.BothOccupancyP95,m.BothOccupancyMax)=Occupancy(qe.Concat(ye).ToList(),m.Cmax);
        return m;
    }
}
