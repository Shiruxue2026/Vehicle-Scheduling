# Experiment data release — 2026-10-21

This release accompanies the frozen `tailrisk-v3.0` synthetic crane–vehicle scheduling study.

The full-data ZIP contains all valid archived development and confirmation inputs, schedules, source, settings, provenance, plan summaries and compressed scenario-level results. There are 8,520,000 plan–scenario rows in 420 compressed CSV blocks, comprising 6,600,000 confirmation and 1,920,000 development replays. Reference replay arrays are additional supporting data. Main, ablation, equal-time and correlated-stress results are all included; reused schedules are identified in the data dictionary.

The repository ZIP omits only the raw compressed scenario CSV blocks. Restore them with `python scripts/restore_release.py PATH_TO_FULL_ZIP`, or extract the full ZIP into an empty directory. Verify every data and code file with `python scripts/verify_data.py --require-raw`; outer archive SHA-256 values are in `SHA256SUMS.txt` attached to this release.

Original scientific files and the 25-file freeze are unchanged. Packaging adds documentation, inventory and integrity helpers. A hostname was removed from a separately named public calibration metadata record. No numerical field was modified.

This is a research data/code release, not a claim of journal acceptance. Read the sampling and metric definitions before reusing the results. Code/data licensing and publication metadata must be confirmed by the authors.
