# GitHub 上传说明

本次只准备本地文件，没有创建 GitHub 仓库或上传数据。

## 上传方式

1. 在 GitHub 新建仓库。解压 `TailRisk_GitHub_Repository_20261021.zip`，用 GitHub Desktop 将解压后的内容提交并推送。仓库根目录应直接显示 `README.md`、`analysis/`、`reproducibility/` 和 `scripts/`。
2. 新建一个 Release，例如标签 `data-2026-10-21`。将 `TailRisk_Experiment_Data_Full_20261021.zip` 作为 Release 附件上传，同时附上外层 `SHA256SUMS.txt`。
3. Release 说明可使用仓库中的 `RELEASE_NOTES.md`。将真实下载链接补到仓库 README 的下载说明处。
4. 发布前由作者选择代码和数据许可证，并核实引用信息。本包未擅自增加开放授权、DOI、录用信息或仓库地址。

普通仓库使用小包的**解压内容**；完整大包作为 Release 附件，不要提交进普通 Git 历史。GitHub 官方说明：普通 Git 阻止超过 100 MiB 的单文件，网页直接上传单文件上限为 25 MiB；每个 Release 附件须小于 2 GiB。

- https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github
- https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases

## 校验与使用

在 PowerShell 中核对下载 ZIP 的 SHA-256，与 `SHA256SUMS.txt` 对应值一致：

```powershell
Get-FileHash -Algorithm SHA256 "C:/Downloads/TailRisk_Experiment_Data_Full_20261021.zip"
```

进入解压后的仓库目录，执行：

```powershell
python scripts/verify_data.py
python scripts/restore_release.py "C:/Downloads/TailRisk_Experiment_Data_Full_20261021.zip"
python scripts/verify_data.py --require-raw
```

也可将完整大包直接解压到一个新目录；它包含小包内容及原始压缩回放块，无须另外合并。保留 `.gitattributes`，避免 Git 自动转换换行符导致原冻结校验失败。`.gitignore` 已排除原始大块数据和构建缓存。

仓库保留所有有效开发和确认实验，包括不利于算法的结果；没有改动数值或选择性删去比较。420 个 `.csv.gz` 保存的是**情景级指标**，不是每项任务等待数组；任务级指标可依靠实例、完整资源链、情景种子和源码重建。各统计口径见 `DATA_DICTIONARY.md`。

原研究目录与此前投稿材料均保留。本包只排除无关投稿文档、本机运行环境文件及已宣布失效的开发记录；唯一公开元数据脱敏是移除校准记录中的电脑主机名，详见 `PACKAGING_NOTES.md`。
