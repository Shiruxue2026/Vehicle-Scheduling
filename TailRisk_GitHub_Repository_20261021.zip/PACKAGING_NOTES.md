# Packaging provenance and scope

Packaging date: 2026-10-21. This data-only distribution is derived from the completed `tailrisk-v3.0` study. The original study directory and previously prepared manuscript files were not edited.

## Unchanged scientific records

All selected instance inputs, nominal references, optimization results, frozen settings, source files, replay data, provenance receipts and analysis outputs are copied byte for byte. `DATA_MANIFEST.json` records exact bytes and SHA-256 for each delivered file. The separate original `reproducibility/configs/freeze.json` is retained unchanged and verifies 25 frozen scientific files. No values were rounded, improved, replaced or selectively removed for this distribution.

The small repository and complete data release differ only by the presence of 420 `reproducibility/results/**/replay/*.csv.gz` blocks. The complete release also includes the same documentation, code, input files and summaries as the small repository. Raw CSV blocks store scenario-level operational metrics; complete task-level arrays can be reconstructed using the supplied plans, inputs, scenario seeds and event evaluator.

## One explicit public metadata redaction

Original metadata: `reproducibility/results/calibration/calibration_environment.json`.

Original SHA-256: `fd711b626e91ef1bd276ae79850de2269d4ca75feb1c5084cafb160b81bee060`.

Public replacement: `reports/calibration_environment_public.json`.

Only the `Machine` field (the local computer hostname) is omitted. The remaining fields are preserved semantically; JSON formatting is regenerated. The original file remains untouched in the private study archive. It is not one of the 25 frozen files and contains no experimental measurements. Hardware, operating-system, concurrency and affinity information needed to interpret timing remains in `reports/environment.json` and the public calibration record.

## Excluded material

The data repository excludes submission correspondence, author fact-check forms, manuscript and supplementary TeX/PDF files, compiled binaries, package caches, local absolute-path reproduction logs and prior research projects. Original paper-asset scripts are retained to preserve the freeze, but this data-only package does not contain the manuscript formatting pipeline or promise to build a paper PDF.

An initial partial tuning execution contained a work-accounting defect and a tabu empty-neighborhood stopping defect. Its 837 records were invalidated before configuration ranking and are not valid study observations. They remain in the original private audit archive and are not included in this valid-data release. The corrected tuning set uses the same grid and development data. This exclusion is based on the documented correctness audit, not performance. Valid unfavorable comparisons and ablations remain in the package.

Some historical report links point to fuller audit or manuscript files outside this data-only scope. The included development-change note, frozen protocol, exact-case records, validation fixtures and independent archive-audit reports establish the relevant context. The original frozen `analysis/package_audit.py` is preserved; `analysis/package_audit_v1_1.py` is the documented manifest-integer compatibility amendment used by the reproduction helper. See `reports/postfreeze_audit_amendment.md`.

## Added distribution files

README, data dictionary, inventory, upload guide, release notes, this note, checksum/restore/analysis helpers, `.gitignore` and `.gitattributes` were added for distribution. These do not change the experimental model, methods, selected settings, tests or statistical rules. The package adds no license, DOI, publication status or repository URL on behalf of the authors.
