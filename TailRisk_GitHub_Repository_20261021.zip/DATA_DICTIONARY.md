# Experiment data dictionary

This document describes the valid archived data for the Tail-Sensitivity-Guided Joint Search (TS-JS) study. It distinguishes independent instances, optimization runs, plan-condition summaries, and scenario replays. All numerical results are from synthetic scheduling instances; they are not measurements from an operating terminal. The data use the model's consistent distance and time units, without a calibrated conversion to a particular terminal.

## Directory hierarchy

| Path | Content and role |
| --- | --- |
| `reproducibility/data/development/` | 40 development instance JSON files and their 40 frozen reference schedules. |
| `reproducibility/data/test/` | 120 independent confirmation instance JSON files and their 120 frozen reference schedules. |
| `reproducibility/configs/` | Protocol, development grids and shortlist, configuration-selection audit, selected configurations, timing limits, and freeze records. |
| `reproducibility/results/<phase>/runs/` | One complete optimization-run JSON record per run, including its returned resource chains. |
| `reproducibility/results/<phase>/provenance/` | Session records and per-run receipts binding source, assembly, specification, schedule, and result hashes. |
| `reproducibility/results/<phase>/replay/` | Per-instance and perturbation-condition raw scenario summaries, plan summaries, reference makespans, and integrity manifests. |
| `reproducibility/results/<phase>/replay_plan.csv` | Combined plan-condition summaries for that phase. |
| `reproducibility/results/<phase>/replay_completion.json` | Completed plan-condition and replay counts. |
| `reproducibility/results/reference/` | Reference-schedule preprocessing runs; these are not confirmatory algorithm-comparison runs. |
| `reproducibility/src/` | C# model, algorithms, event replay, validation, and integrity code used to interpret and regenerate the data. |
| `analysis/results/{main,ablation,timing,correlated}/` | Derived analysis tables and figures; these duplicate information derived from the archived runs and are not additional observations. |
| `reports/exact/` | Six exact small-instance audit records and their summary. |
| `reports/validation/` | Archived correctness-validation reports. |
| `reports/package_audit_*.json` | Archived package-audit results. |

The public package also includes selected protocol and audit documentation. It excludes invalidated results from the valid numerical dataset. Development records remain separately identified and must not be pooled into the independent confirmation sample.

## Verified counts and reuse rules

There are four main instance sizes, `N = 24, 48, 96, 192`. The confirmation set contains 30 independent instances per size. The development set contains 10 per size. Each input has one companion `_reference.json` file: 160 inputs and 160 reference records in total.

| Valid formal phase | New optimization plans | Plan-condition summary rows | Scenarios per row | Actual plan-scenario replays | Raw `.csv.gz` chunks |
| --- | ---: | ---: | ---: | ---: | ---: |
| `main` | 2,400 | 4,800 | 1,000 | 4,800,000 | 240 |
| `ablation` | 300 | 600 | 1,000 | 600,000 | 40 |
| `timing` | 400 | 800 | 1,000 | 800,000 | 40 |
| `correlated` | 0; reuses 400 main plans | 400 | 1,000 | 400,000 | 20 |
| **Formal total** | **3,100** | **6,600** | **1,000** | **6,600,000** | **340** |

- Main plans cover 120 instances, four algorithms, and five algorithm seeds.
- Ablation adds three TS-JS variants on the first 10 confirmation instances at each of `N = 96` and `N = 192`, with five seeds. The 100 full TS-JS comparator plans are reused from `main`; their ordinary independent-perturbation replay is not counted a second time.
- Timing adds four algorithms on the same 20 large instances with five seeds. These are separate optimization runs under the frozen time limits.
- Correlated stress tests reuse the 400 corresponding main plans on those 20 instances. They add a new perturbation condition and replay records, not newly optimized schedules.
- The exact audit has two cases at each of `N = 4, 5, 6`. These six cases are separate correctness/encoding audits, not members of the 120-instance confirmation sample.

| Valid development phase | Optimization plans | Held-out plan-condition rows | Actual plan-scenario replays | Raw `.csv.gz` chunks |
| --- | ---: | ---: | ---: | ---: |
| `dev_r1_tune` | 1,280 | 0 | 0 | 0 |
| `dev_r1_selection` | 800 | 1,600 | 1,600,000 | 40 |
| `dev_trainingK32` | 160 | 160 | 160,000 | 20 |
| `dev_trainingK128` | 160 | 160 | 160,000 | 20 |
| **Development total** | **2,400** | **1,920** | **1,920,000** | **80** |

There are also 48 calibration runs and 800 nominal reference-preprocessing runs (five per input). They are not additional held-out scenario replays. Across formal and development replay data, the archive contains **420 raw gzip chunks and 8,520,000 plan-scenario replay rows**, comprising **6,600,000 formal** and **1,920,000 development** replays. These counts exclude optimizer-internal training evaluations and companion reference-schedule replays.

## Identifiers, seeds, and pairing

| Field or identifier | Meaning |
| --- | --- |
| `InstanceId` / input `Id` | Stable instance identifier, for example `test_N24_I01`. The identifier distinguishes split, task count, and instance index. |
| `Split` | Input generation split; development and confirmation instances are separate. |
| `Version` / `InputVersion` | Generator version. The archived input version is `geometry-v3.0`. |
| Input `Seed` | Seed used to generate that instance. |
| Run `Seed` | Algorithm random seed. It is distinct from the instance and perturbation seeds. |
| `Phase` | Experimental phase, such as `main`, `ablation`, `timing`, or `correlated`. |
| `Method` | Implemented optimizer identifier. |
| `ConfigId` | Frozen or development configuration identifier; join it to the relevant configuration JSON. |
| `ScheduleId` | Identifier of the returned resource-chain schedule. Separate runs can return the same schedule; retain their run identities. |
| Raw `PlanId` | Optimization-run filename stem. Join it to the corresponding JSON in `runs/`; for `correlated`, the source is `main/runs/`. |
| `Scenario` | Zero-based replay index within a chunk. |
| `ScenarioSeed` | Shared perturbation seed recorded in the chunk manifest and companion reference file. |
| `CV` | Marginal coefficient of variation of perturbed durations: 0.10 or 0.20 in formal replay. |
| `Rho` | Correlation parameter of the underlying normal/log-duration disturbances: 0 for independent replay and 0.5 for correlated stress replay. It is not the Pearson correlation of the resulting lognormal durations. |

The replay seed is deterministically derived from instance ID, CV, and Rho. All methods and all algorithm seeds for a given instance and perturbation condition use the same scenario frames. The scenario sequence must not be regenerated independently for each method when reconstructing paired comparisons. The archived manifests and source code define the exact seed derivation and generator behavior.

## Instance and schedule JSON

| Field | Definition |
| --- | --- |
| `N` | Number of transport tasks. |
| `Qn`, `An`, `Yn` | Numbers of active quay cranes, AGVs, and yard cranes. |
| `Tasks[i].Id` | Zero-based task identifier. |
| `Tasks[i].Q`, `Tasks[i].Y` | Fixed QC and YC assignments for the task. |
| `PQ`, `HQ`, `PY`, `HY` | QC preparation, quay handover, yard placement, and yard handover durations. |
| `Qx`, `Yx`, `Ax` | Horizontal coordinates of QCs, YCs, and initial AGV positions. |
| `Width`, `Depth` | Synthetic rectangular-layout dimensions. |
| `LoadedSpeed`, `EmptySpeed` | Loaded and empty AGV speeds; the model uses 1 and 1.5. |
| `Schedule.Q` | Array of QC task chains; the array position is the resource ID and each inner array is its service order. |
| `Schedule.A` | Array of AGV task chains, jointly defining AGV assignment and task order. |
| `Schedule.Y` | Array of YC task chains. |

Each task occurs exactly once in each resource layer. QC and YC memberships agree with the fixed task assignments. Active resources are nonempty. Resource chains are independent: there is no requirement that all layers share one global task permutation. A cyclic event graph is infeasible. Empty travel includes the initial AGV approach to its first QC task as well as travel between successive assigned tasks.

## Optimization-run JSON

| Field | Definition |
| --- | --- |
| `TrainingScenarios` | Number of common training scenarios used in objective and risk-constraint evaluation; formal runs use 64. |
| `Proposals` | Number of candidate proposals charged against the proposal cap. |
| `Evaluations`, `ValidGraphs`, `FeasibleEvaluations` | Archived search counters; use the code for their precise increment points. |
| `Work`, `Limit` | Used and allowed deterministic event-work budget. Work is not a count of candidate schedules or whole scenario banks. |
| `Seconds`, `TimeLimit` | Observed elapsed search time and configured time limit in seconds. |
| `StopReason` | Recorded stopping condition. |
| `ReferenceCmax`, `ReferenceEmpty` | Frozen reference schedule's nominal completion time and empty-travel time. |
| `ReferenceCvarCmax` | Frozen reference schedule's completion-time CVaR95 under the shared training scenarios. |
| `Evaluation.Complete` | Whether the returned evaluation was completed. |
| `Evaluation.Feasible` | Whether the returned schedule satisfies the model and frozen efficiency/risk constraints. |
| `Evaluation.Risk` | Training CVaR95 of task cumulative AGV waiting, pooled over tasks and training scenarios. This is not held-out `WaitCVaR`. |
| `Evaluation.CvarCmax` | Training CVaR95 of scenario completion times. |
| `Evaluation.NomCmax`, `Evaluation.Empty` | Returned plan's nominal completion time and empty-travel time. |
| `Evaluation.Violation` | Aggregate feasibility-violation value used by the search. |
| `Evaluation.TaskTail` | Per-task contribution to training waiting CVaR, summing tail weight times waiting loss over training scenarios. |
| `Checkpoints` | Budget-position records with `Fraction`, `Risk`, `Seconds`, and `Work`. |
| `Diagnostics` | Method-specific diagnostic counters or values. |

The returned plan is the best fully evaluated feasible plan retained by that run. `Evaluation.Risk` is a training quantity and must not be substituted for independent replay performance. The definitions in this table describe risk-aware comparison runs; nominal reference-preprocessing runs instead use nominal completion time as their search objective, and their `TaskTail` values are nominal task waits.

## Replay files and integrity records

A replay chunk has the stem `<InstanceId>_cv<percent>_rho<percent>` and the following companions:

| Suffix | Contents |
| --- | --- |
| `.csv.gz` | One row for each plan and scenario, with 22 scenario-level operational metrics. |
| `_summary.csv` | One row per plan at that CV/Rho, aggregating all replay scenarios. |
| `_reference.json` | `InstanceId`, `ScenarioSeed`, `CV`, `Rho`, and the `Cmax` array for paired replay of the frozen reference plan. |
| `_manifest.json` | `RunSetDigest`, instance/phase/condition, scenario and plan counts, `Decodings`, seed, input version, and SHA256 values for raw, summary, and reference files. |
| `runset.json` | Runset digest and serialized specification binding the core code, inputs, references, and source plan files. |

The raw CSV header starts with `PlanId,Scenario`, followed by `Cmax`, `WaitMean`, `WaitP95`, the eight AGV/crane interface wait fields, the nine occupancy fields, `PhaseMean`, and `GTVMean`. Each raw row describes **one scenario**. For example, its `WaitP95` is across tasks within that scenario. In contrast, `_summary.csv` and `replay_plan.csv` compute wait P95 across all task-scenario samples.

Raw chunks do not store every task's event times or individual waiting loss. Those values are reconstructable from the archived instance, schedule, scenario seed, and frozen event-replay code. In particular, pooled `WaitCVaR` cannot be recovered by averaging the raw per-scenario `WaitP95` values.

Provenance session records contain `Id`, `StartedUtc`, `AssemblyHash`, `Runtime`, `Architecture`, and `AllSource` relative-path hashes. Per-run receipts contain `Schema`, `SpecificationHash`, `FileHash`, `ScheduleHash`, `SessionId`, `AssemblyHash`, and `SavedUtc`. Preserve these records and numerical files byte-for-byte when verifying original hashes. Hashes establish byte-level consistency; they do not by themselves establish scientific correctness.

## Plan-condition summary metrics

For task `i` and scenario `w`, let `QW[i,w]` and `YW[i,w]` be nonnegative AGV waiting at quay and yard handovers. The cumulative task loss is `W[i,w] = QW[i,w] + YW[i,w]`.

For `m` samples, CVaR95 is the empirical upper-tail mean defined by minimizing `eta + sum(max(x - eta, 0)) / (0.05 m)`. The code assigns fractional mass at the tail boundary, with boundary mass shared among tied values. CVaR95 is not the 95th percentile. P95 uses the nearest-rank empirical percentile, with rank `ceil(0.95 m)`.

| Summary field | Definition |
| --- | --- |
| `Scenarios` | Number of replay scenarios in the summary, 1,000 for formal replay. |
| `NominalCmax`, `Empty` | Nominal metrics for the optimized plan, copied from its completed run evaluation. |
| `WaitCVaR` | CVaR95 across all `N × Scenarios` cumulative task waits `W`. |
| `WaitMean`, `WaitP95` | Mean and P95 of the same pooled cumulative task-wait samples. |
| `QAgvWaitMean`, `QAgvWaitP95` | Pooled task-scenario AGV waiting at the quay interface. |
| `YAgvWaitMean`, `YAgvWaitP95` | Pooled task-scenario AGV waiting at the yard interface. |
| `QCraneWaitMean`, `QCraneWaitP95` | Pooled task-scenario QC waiting for the AGV at handover. |
| `YCraneWaitMean`, `YCraneWaitP95` | Pooled task-scenario YC waiting for the AGV at handover. |
| `CmaxMean`, `CmaxCVaR` | Mean and CVaR95 across scenario completion times, with one completion-time sample per scenario. |
| `CapExceedance` | Fraction of scenario completion times exceeding `1.01 × ReferenceCmax`, subject to the code's floating-point tolerance. Values are proportions, not percentages. |
| `RelativeCmaxChange` | `100 × (CmaxMean / NominalCmax - 1)`. Already expressed as a percentage; the denominator is the optimized plan's own nominal completion time. |
| `ReferenceReplayCvarCmax` | CVaR95 of the paired reference schedule's replay completion times. |
| `WaitCVaRFirst250`, `WaitCVaRFirst500` | Pooled task-wait CVaR95 from the first 250 or 500 replay scenarios. |
| `CmaxCVaRFirst250`, `CmaxCVaRFirst500` | Completion-time CVaR95 from those corresponding replay prefixes. |
| `PhaseMean` | Scenario-average mean absolute signed phase difference across both task handover interfaces. |
| `GTVMean` | Scenario-average absolute phase change across adjacent tasks on the QC and YC chains, divided by `2N - Qn - Yn`. |

### Waiting occupancy

`QOccupancy*`, `YOccupancy*`, and `BothOccupancy*` describe the number of AGVs currently waiting at the quay interface, yard interface, or either interface. Each scenario's observation interval is `[0, Cmax]`.

- `Mean` is the time-weighted mean waiting count (area under the waiting-count curve divided by scenario `Cmax`).
- `P95` is the time-weighted 95th percentile of that count within the scenario.
- `Max` is the maximum count over positive-duration intervals within the scenario.

The plan-condition summary averages each of these scenario metrics over the replay scenarios. Consequently, summary occupancy P95 and Max values can be fractional: they are averages of within-scenario quantiles/maxima, not a pooled global occupancy quantile or maximum. Waiting occupancy is a metric of the stated event model; it does not establish real-terminal queue stability.

## Analysis tables and inferential unit

`analysis/results/<phase>/instance_metrics.csv` identifies `N`, `InstanceId`, `Label`, `CV`, `Rho`, `ReferenceCmax`, `ReferenceEmpty`, the aggregated metric fields, `SearchSeeds`, and `SourcePhase`. `Label` is the analysis comparison label. `SearchSeeds` records the number of algorithm seeds aggregated. `SourcePhase` documents reuse of source runs, including full TS-JS ablation comparators and main plans used for stress tests.

Plan-level CVaR is calculated first; the five algorithm-seed values are then averaged within an instance. The independent unit of inference is the instance. Tasks, algorithm seeds, and replay scenarios are not independent instance replicates. Follow the archived statistical protocol for stratification, paired bootstrap, and secondary-comparison corrections. Do not count repeated appearances in derived tables or reused experiment phases as additional independent data.
